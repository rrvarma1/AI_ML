# RBI Step-6 Chunks

`chunks.jsonl` contains leaf nodes for BM25/vector indexing. `node_hierarchy.jsonl` preserves all LlamaIndex nodes for parent-child retrieval. `docling_documents/` stores lossless Docling JSON and page-marked Markdown.
