<!-- RBI_PAGE:1 -->

<!-- image -->

PRuTe

R

OF

## भारतीय �रज़वर् ब�क RESERVE BANK OF INDIA

## [www.rbi.org.in](http://www.rbi.org.in/)

## RBI/FIDD/2018-19/64 Master Direction FIDD.CO.FSD.BC No.9/05.10.001/2018-19                  October 17, 2018

The Chairman/Managing Director/Chief Executive Officer All scheduled commercial banks

(including Small Finance Banks and excluding Regional Rural Banks)

Madam / Sir,

Master Direction - Reserve Bank of India (Relief Measures by Banks in Areas affected by Natural Calamities) Directions 2018 - SCBs

Please refer to our 'Master Direction FIDD.No.FSD.BC.8/05.10.001/2017-18 dated July 3, 2017' incorporating guidelines issued to banks in regard to matters relating to relief measures to be provided in areas affected by natural calamity.

This Master Direction consolidates all the guidelines issued on the subject till date. The list of circulars compiled into this Master Direction is given in the Appendix.

Please acknowledge receipt.

Yours faithfully,

(G. P. Borah)

Chief General Manager-in-Charge

<!-- RBI_PAGE:2 -->

## Reserve Bank of India (Relief Measures by Banks in Areas Affected by Natural Calamities) Directions, 2018

In  exercise  of  the  powers  conferred  under  Sections  21  and  35A  of  the  Banking Regulation Act, 1949, the Reserve Bank of India being satisfied that it is necessary and  expedient  in  the  public  interest  so  to  do,  hereby,  issues  the  Directions hereinafter specified.

## CHAPTER I PRELIMINARY

## 1.1 Short Title and Commencement.

(a) These Directions shall be called the Reserve Bank of India (Relief Measures by Banks in Areas Affected by Natural Calamities) Directions, 2018.

(b) These Directions shall come into effect on the day they are placed on the official website of the Reserve Bank of India.

## 1.2. Applicability

The  provisions  of  these  Directions  shall  apply  to  Scheduled  Commercial  Banks {including Small Finance Banks (SFBs) and excluding Regional Rural Banks(RRBs)} licensed to operate in India by Reserve Bank of India.

## CHAPTER II BACKGROUND

2.1 Periodic occurrence of a natural calamity takes a heavy toll on human life and cause wide- spread damage to economic pursuits in one or the other parts of the country. The devastation caused by a natural calamity calls for massive rehabilitation effort from all agencies. The  Central, State and  Local Authorities draw  up programmes on economic rehabilitation for the people affected by the occurrence of a  natural  calamity.  The  developmental  role  assigned  to  the  commercial  banks including small finance banks warrant their active support in reviving the economic activities of those affected by the occurrence of a natural calamity.

2.2 In terms of the National Disaster Management Framework, there are two funds constituted  viz.  National  Disaster  Response  Fund  (NDRF)  and  State  Disaster Response  Fund  (SDRF)  for  providing  relief  in  the  affected  areas.  The  NDRF framework  currently  recognizes  twelve  types  of  natural  calamities  viz.  cyclone, drought,  earthquake,  fire,  flood,  tsunami,  hailstorm,  landslide,  avalanche,  cloud burst, pest attack and cold wave/frost. The Ministry of Agriculture is the nodal point for four of the calamities i.e. drought, hailstorms, pest attack and cold wave/frost and for the remaining eight, the Ministry of Home Affairs is the nodal ministry to make the necessary administrative arrangements. A slew of measures for relief are undertaken  by  the  Sovereign  (Central/State  Government)  from  time  to  time  to provide relief to the affected people including, inter alia, provision for input subsidies and financial assistance to farmers including small and marginal farmers.

<!-- RBI_PAGE:3 -->

2.3 The  role  of  the  scheduled  commercial  banks  including  small  finance  banks (SFBs)  is  to  provide  relief  measure  through  rescheduling  of  existing  loans  and sanctioning fresh loans as per the emerging requirement of the borrowers. To enable banks  to  take  a  uniform  and  concerted  action  expeditiously,  these  directions  are issued covering four aspects viz. Institutional Framework (Chapter III), Restructuring of  Existing  Loans  (Chapter  IV),  Providing  Fresh  Loans  (Chapter  V)  and  Other Ancillary Relief Measures (Chapter VI).

## CHAPTER III INSTITUTIONAL FRAMEWORK

## 3.1 Establishing Policy/Procedures for dealing with Natural Calamities

The  area,  time  of  occurrence  and  intensity  of  a  natural  calamity  cannot  be anticipated.  It  is  therefore,  imperative  that  banks  have  a blueprint  of  action duly approved by the Board of Directors for such eventualities so that the required relief and assistance are provided with utmost speed and without any loss of time. Further, all  Divisional/Zonal  Offices  and  branches  of  scheduled  commercial/small  finance banks  shall  be  familiar  with  these  standing  instructions.  The  standing  instructions shall  immediately  come  to  force  after  the  district/state  authorities  put  in  place  the requisite  declaration.  It  is  essential  that  these  instructions  shall  also  be  made available  to  the  State  Government  authorities  and  the  District  Collector  so  that  all concerned  are  aware  about  the  action  that  shall be  taken  by  the  concerned authorities in the affected area.

## 3.2 Discretionary Powers to Divisional / Zonal Manager of banks

The Divisional/Zonal Managers of scheduled commercial/SF banks may be vested with certain discretionary powers to avoid the need to seek fresh approval from their Head  Office/Controlling  Office  regarding  the  line  of  action  decided  by  the  District Consultative Committee/State Level Bankers' Committee. Some of the areas, among others  where  such  discretionary  powers  are  vital  may  be  the  adoption  of  scale  of finance, need  based  restructuring  of  loans ,  extension  of  loan  period,  margin, security, sanction of new loan keeping in view the total liability of the borrower arising out of the old loan where the asset financed was damaged or lost as a result of the natural calamity and the new loan to be financed for creation/repair of such asset(s).

<!-- RBI_PAGE:4 -->

## 3.3  Meeting  of  State  Level  Bankers'  Committee  (SLBC)/District  Consultative Committee (DCC)

3.3.1 In the event of occurrence of a natural calamity which covers a larger part of a State, the State Level Bankers' Committee convener bank shall convene a special SLBC  meeting immediately. The committee, in collaboration with the State Government Authorities shall evolve a coordinated action plan for implementing the relief  programme.  If  the  calamity  has  affected  only  a  small  part  of  the  state/few districts,  the  convener  of  the  District  Consultative  Committee  of  the  affected district(s) shall convene a meeting immediately. In the special SLBC/DCC meeting, the  position  of  the  affected  areas  may  be  assessed  so  as  to  ensure  speedy formulation and implementation of suitable relief measures.

3.3.2 In the areas where the calamity is severe, the relief measure(s) implemented shall  be  reviewed  periodically  through  a  specially  constituted  Task  Force/SubCommittee by way of weekly/fortnightly meetings as decided by the SLBC/DCC.

## 3.4 Scope

The Master Directions shall apply be applicable to farmers/loanees who have been affected by a natural calamity as declared by the State Government/Authorities  and  are  willing to avail the benefits under  the guidelines.

## 3.5 Declaration of Natural Calamity

3.5.1  It  is  recognised  that  declaration  of  a  natural  calamity  is  the  domain  of  the Central/  State  Governments.  The  inputs  received  from  the  State  Governments revealed  that  there  is  no  uniform  procedure  being  followed  for  declaration  of  a natural  calamity  and  issue  of  declarations/certificates.  The  declarations/certificates are  called  by  different  names  such  as  Annewari,  Paisewari,  Girdawari,  etc.  in different States. Nevertheless, the common thread to extend relief measure towards agricultural  loans  including  rescheduling  of  loans  by  banks,  is  that the  crop  loss assessed should be 33% or more. For assessing this loss, while some States are conducting crop cutting experiments to determine the loss in crop yield, some others are relying on the eye estimates/visual impressions.

3.5.2 In extreme situations such as wide-spread floods, when it is largely evident that most of the standing crops have been damaged and/or land and other assets have suffered a wide-spread damage, the matter shall be deliberated by State Government/District Authorities in a specially convened SLBC/DCC meeting where the concerned Government functionary/District Collector shall explain the reasons for not  estimating  'Annewari'  (percentage  of  crop  loss  -  by  whatever  name  called)

<!-- RBI_PAGE:5 -->

through  crop  cutting  experiments  and  that  the  decision  to  provide  relief  for  the affected populace needs to be taken based on the eye estimate/visual impressions.

3.5.3 In both the cases, however, SLBC/DCC shall satisfy themselves fully that the crop loss has been 33% or more before acting on these pronouncements.

## CHAPTER IV RESTRUCTURING OF EXISTING LOANS

In  the  event  of  a  natural  calamity,  the  repaying  capacity  of  the  people  may  get severely affected due to the disruption of their economic activities and loss/damage of economic assets. Therefore, relief in loan repayment by restructuring the existing loan may become necessary.

## 4.1. Agriculture Loans: Short-term Production Credit (Crop Loans)

4.1.1 All short-term loans except those which are overdue at the time of occurrence of the natural calamity shall be eligible for restructuring. The principal amount of the short-term loan as well as interest due for repayment in the year of occurrence of the natural calamity shall be converted into term loan.

4.1.2  The  repayment  period  of  the  restructured  loan  may  vary  depending  on  the severity of the calamity, the impact on loss/damage of economic assets and distress it  caused.  A  maximum  repayment  period  of  up  to  two  years  (including  the moratorium period of one year) shall be allowed if the loss is between 33% and 50%. If the crop loss is 50% or more, repayment period may be extended upto a maximum of five years (including the one year moratorium period).

4.1.3 In all restructured loan accounts, moratorium period of at least one year shall be  considered.  Banks  may  not  insist  on  additional  collateral  security  for  such restructured loans.

## 4.2 Agriculture Loans: Long term (Investment) Credit

4.2.1  The  existing  term  loan  instalments  shall  be  rescheduled  keeping  in  view  the repaying capacity of the borrower and the nature of natural calamity viz.

4.2.1.1 In a natural calamity where only crop of that year is damaged and productive assets are not damaged, banks shall reschedule the payment of instalment during the  year  of  natural  calamity  and  extend  the  loan  period  by  one  year.  Under  this arrangement the instalments defaulted wilfully in earlier years shall not be eligible for rescheduling.  The  banks  may  also  have  to  postpone  payment  of  interest  by borrowers.

<!-- RBI_PAGE:6 -->

4.2.1.2  In  a  natural  calamity  where  the  productive  assets  are  partially  or  totally damaged  and  borrowers  are  in  need  of  a  new  loan,  the  rescheduling  by  way  of extension  of  loan  period  shall  be  determined  on  the  basis  of  overall  repaying capacity of the borrower vis-a-vis total liability (old term loan, restructured crop loan, if any, and the fresh crop/term loan being given) less the subsidies received from the Government  Agencies  and  compensation  available  under  the  insurance  schemes etc. While the total repayment period for the restructured/fresh term loan may differ on case-to-case basis, generally it shall not exceed a period of five years.

## 4.3 Other Loans

4.3.1 Depending on the severity of a natural calamity, SLBC/DCC shall take a view as to whether a general rescheduling of all other loans (i.e. besides the agriculture loans)  such  as  loans  granted  for  allied  activities,  loans  to  rural  artisans,  traders, micro/small industrial units or in case of extreme situations, medium enterprises are required. If such a decision is taken, while recovery of all the loans be postponed by the specified period, banks may assess the requirement of the individual borrowers in  each case and depending on the nature of her/his account, repayment capacity and the need for fresh loans, appropriate decisions shall be taken by the individual banks.

4.3.2 The primary consideration for extending credit to any unit for its rehabilitation shall be based on the viability of the venture as assessed by the bank.

## 4.4 Asset Classification

The asset classification status of the restructured loans shall be as under:

4.4.1 The restructured portion of the short term as well as long-term loans may be treated as current dues and need not be classified as NPA. The asset classification of  these  term  loans  would  thereafter  be  governed  by  the  revised  terms  and conditions.  Nevertheless,  banks  are  required  to  make  higher  provisions  for  the restructured  standard  advances  as  prescribed  by  the  Department  of  Banking Regulation 1 from time to time. Further, interest income from such restructured accounts classified as 'standard assets' will be recognized as per the norms prescribed in the DBR guidelines.

4.4.2. The asset classification for the remaining dues, that does not form a part of the restructured  portion,  shall continue  to  be  governed  by  the  original  terms  and conditions  of  its  sanction.  Consequently,  the  dues  from  the  borrower  shall  be classified  by  the  lending  bank  under  different  asset  classification  categories  viz. standard, sub-standard, doubtful and loss.

1 Master Circular-Prudential Norms on Income Recognition, Asset Classification and Provisioning pertaining to Advances

<!-- RBI_PAGE:7 -->

4.4.3.  Additional  finance,  if  any,  shall  be  treated  as  'standard  asset'  and  its  future asset classification will be governed by the terms and conditions of its sanction.

4.4.4. With the objective to ensure that banks are proactive in extending relief to the affected persons, the benefit of asset classification of the restructured account as on the date of natural calamity shall be available only if the restructuring is completed within a period of three months from the date of declaration of the natural calamity by the Government. In the event of extreme calamity, when the SLBC/DCC is of the view  that  this  period  shall  not  be  sufficient  for  the  banks  to  reschedule  all  the affected loans, it  shall  approach the Chief General Manager, Reserve Bank of India, Financial Inclusion and Development  Department,  Central Office, Mumbai through  the  concerned  Regional  Director  of  RBI.  The  request  shall detail  the  reasons  for  not  completing  the  exercise  within  the  stipulated timeframe  and  outcome  anticipated  from  such  an  extension.  Such  requests along  with  the  specific  recommendations  of  the  Regional  Director  shall  be considered on the merit of each case.

4.4.5 The accounts that are restructured for the second time or more on account of recurrence of natural calamities shall retain the same asset classification category on each  restructuring.  Accordingly,  for  a  restructured  standard  asset,  the  subsequent restructuring necessitated on account of a natural calamity shall not be treated as second  restructuring,  i.e.,  the  standard  asset  classification  shall be  maintained. However, all other restructuring norms shall apply.

## 4.5 Utilization of Insurance Proceeds

4.5.1  While  the  above  measures  relating  to  rescheduling  of  loans  are  intended  to provide relief to the farmers, the insurance proceeds shall, ideally compensate the losses.  In  terms  of  orders  issued  by  the  Ministry  of  Agriculture, Department  of Agriculture,  Cooperation  and  Farmers  Welfare,  the  Pradhan  Mantri  Fasal  Bima Yojana  (PMFBY)  has  replaced  the  existing  schemes  of  National  Agricultural Insurance  Scheme  (NAIS)  &amp;  Modified  National  Agricultural  Insurance  Scheme (MNAIS)  with  effect  from  Kharif  2016. Under  the  Prime  Minister  Fasal  Bima Yojana (PMFBY), all Seasonal Agricultural Operations (SAO) loans for notified crops in notified areas are to be compulsorily provided insurance cover for all stages of the crop cycle including post-harvest risks in specified instances 2 . Farmers' details are required to be entered by banks in the unified portal for crop insurance which is available at www.agri-insurance.gov.in in order to facilitate assessment of coverage of crops insured, premiums deducted, etc.

2 Operational guidelines - PMFBY issued by Ministry of Agriculture &amp; Farmers' Welfare

<!-- RBI_PAGE:8 -->

4.5.2 While restructuring loans in an area affected by a natural calamity, banks shall also take into account the insurance proceeds, if any, receivable from an insurance company.  The  insurance  proceeds  shall  be  adjusted  towards  the  'restructured accounts' in cases where fresh loans have been granted to the borrower. However, banks  shall act  with  empathy  and  consider  restructuring  and  granting  fresh  loans without  waiting  for  the  receipt  of  the  insurance  claim  in  cases  where  there  is reasonable certainty of receiving the claim.

## CHAPTER V PROVIDING FRESH LOANS

## 5.1 Sanctioning of Fresh Loans

5.1.1  Once  the  decision  to  reschedule  loans  is  taken  by  SLBC/DCC,  pending conversion  of  short-term  loans,  banks  shall  grant  fresh  crop  loan  to  the  affected farmers based on the scale of finance of the crop and the cultivation area as per the extant guidelines 3 .

5.1.2 The bank assistance in agriculture and allied activities (poultry, fishery, animal husbandry, etc.) may also be needed for long term loans for a variety of purposes such  as  repair  of  existing  economic  asset(s)  and/or  acquisition  of  new  asset(s). Similarly, rural artisans, self-employed persons, micro and small industrial units, etc. in the areas affected by a natural calamity may require fresh credit to sustain their livelihood. Banks shall assess the need and decide on the quantum of loans to be granted  to  the  affected  borrowers  taking  into  consideration,  amongst  others,  the credit requirement and due procedure for sanctioning fresh loans.

5.1.3.  Banks  shall  also  grant  consumption  loan  up  to      ₹.  10,000/-  to  existing borrowers  without  any  collateral.  The  limit  may,  however,  be  enhanced  beyond ₹.10,000/- at the bank's discretion.

## 5.2 Terms and Conditions

## 5.2.1 Guarantee, Security and Margin

5.2.1.1 Credit shall not be denied for want of a personal guarantee alone. Where the bank's  existing  security  has  been  eroded  because  of  damage  or  destruction  by floods,  assistance  shall  not  be  denied  merely  for  want  of  additional  fresh  security. The fresh loan shall be granted even if the value of security (existing as well as the asset  to  be  acquired  from  the  new  loan)  is  less  than  the  loan  amount.  For  fresh loans, banks shall take a sympathetic view.

3 Master Circular-Kisan Credit Card (KCC) Scheme

<!-- RBI_PAGE:9 -->

5.2.1.2 Where the crop loan (which has been converted into term loan) was earlier sanctioned against personal security/hypothecation of crop and the borrower is not able to offer charge/mortgage of land as security for the converted loan, she/he shall not be denied conversion facility merely on the ground of his/her inability to furnish land as security. If the borrower has already availed a term loan against mortgage/charge on land, the bank shall be content with a second charge for the converted  term  loan.  Banks  shall  not  insist  on  third  party  guarantee  for  providing conversion facility.

5.2.1.3  Where  land  is  taken  as  security,  in  the  absence  of  original  title  record,  a certificate  issued  by  the  Revenue  Department  officials  shall  be  accepted  for financing to farmers who have lost proof of their title such as title deed or registration certificate issued to registered share-croppers. In the areas covered by the Sixth Schedule of the Constitution, whereby the land is owned by the community, certificate issued by community authorities may be accepted.

5.2.1.4  Margin  requirements  may  be  waived  or  the  grant/subsidy  given  by  the concerned State Government shall be considered for margin security.

## 5.3 Rate of Interest

5.3.1The rate of interest shall be in accordance with the Master Directions - Reserve Bank of India (Interest Rate on Loans and Advances) Directions. Within the area of their discretion, however, banks shall take a sympathetic view of the difficulties of the borrowers  and  extend  a  concessional  treatment  to  calamity-affected  people.  In respect  of  default  in  current  dues,  no  penal  interest  shall  be  charged.  The  banks shall also suitably defer the compounding of interest charges. Banks shall not levy penal interest and consider waiving penal interest, if any, already charged in regard to  the  loans  converted/rescheduled.  Depending  on  the  nature  and  severity  of  the natural  calamity,  the  SLBC/DCC  shall  take  a  view  on  the  interest  rate  concession that could be extended to borrowers so that there is uniformity in approach among banks in providing relief.

5.3.2 As  notified  by  the  Government  of  India 4 from  time  to  time,  to  provide relief  to  farmers  availing  short  term  crop  loans  and  affected  by  a  natural calamity,  an  interest  subvention  of  2  percent  per  annum  shall  be  made available  to  banks  for  the  first  year  on  the  restructured  loan  amount.  Such restructured loans shall attract normal rate of interest from the second year onwards.

4 Subject to inclusion in the Interest Subvention Scheme on short term crop loans

<!-- RBI_PAGE:10 -->

## CHAPTER VI OTHER ANCILLARY MEASURES

## 6.1 Relaxation on Know Your Customer (KYC) Norms

It  needs to be recognized that many persons displaced or adversely affected by a major calamity may not have access to their identification and personal records. In such cases, a basic saving bank deposit account on the basis of photograph along with  signature  or  thumb  impression  rendered  in  front  of  the  bank  official  shall  be opened. The above instruction shall be applicable to cases where the balance in the account does not exceed ₹ 50,000/- or the amount of relief granted (if higher) or the total  credit  in  the  account  does  not  exceed  ₹  1,00,000/-  or  the  amount  of  relief granted, if higher in a year.

## 6.2 Providing access to Banking Service

6.2.1  Banks  may  operate  its  natural  calamity  affected  branches  from  temporary premises under advice to the concerned Regional Office of RBI. For continuing the temporary  premise  beyond  30  days,  banks  may  obtain  specific  approval  from  the concerned Regional  Office  of  RBI.  Banks  may  also  make  arrangements  to  render banking  services  in  the  affected  areas  by  setting  up  satellite  offices,  extension counters or mobile banking facilities etc. under intimation to RBI.

6.2.2  To  meet  the  immediate  cash  requirements  of  the  affected  people,  due importance shall be given towards restoring the ATMs or other alternate arrangements shall be provided to avail such facilities.

6.2.3  Other  measures  that  banks  may  initiate  at  their  discretion  to  alleviate  the condition  of  the  affected  people  could  be  waiving  of  ATM  fees,  increasing  ATM withdrawal limits; waiving of fees towards overdraft/early withdrawal penalty on time deposits/late fee for credit card/other loan instalment payments etc. and giving option to credit card holders to convert their outstanding balance to EMIs repayable in 1-2 years. Besides, all charges debited to the farm loan account other than the regular interest may be waived considering the hardship caused to the affected people.

## CHAPTER VII RIOTS AND DISTURBANCES: APPLICABILITY OF THE GUIDELINES

## Applicability of the guidelines in case of riots and disturbances

7.1 Whenever RBI advises the banks to extend rehabilitation assistance to the riot/ disturbance affected persons, the aforesaid guidelines shall broadly be followed by banks for the purpose. It shall, however, be ensured that only genuine persons, duly identified by the State Administration as having been affected by the riot/ disturbance are  provided  assistance  as  per  the  guidelines. In  the  event  of  large  scale  riots where most parts of the State/Area are affected and the State Administration is not in a position to identify the riot/disturbance affected persons and subject to SLBC's specific decision, the onus of identifying 'genuine persons' will rest with banks.

<!-- RBI_PAGE:11 -->

7.2.  The  issuance  of  advice  to  the  banks  by  Reserve  Bank  of  India  on  receipt  of request/ information from State Government and thereafter issue of instructions by banks to their branches generally results in delay in extending the assistance to riotaffected  people.  With  a  view  to  ensure  quick  relief  to  the  affected  persons,  it  has been decided that the District Collector, on occurrence of the riot/ disturbance, may ask  the  Lead  Bank  Officer  to  convene  a  meeting  of  the  DCC,  if  necessary  and submit a report to the DCC on the extent of damage caused to life and property in the area affected by the riot/disturbance. If the DCC is satisfied that there has been extensive loss to life and property on account of the riot/ disturbance, the relief as per  the  above  guidelines  shall be  extended  to  the  people  affected  by  the  riot/ disturbance. In cases where there is no District Consultative Committee, the District Collector  may request the convener of the State Level Bankers' Committee of the State  to  convene  a  meeting  of  the  bankers  to  consider  extension  of  relief  to  the affected  persons.  The  report  submitted  by  the  District  Collector  and  the  decision thereon of SLBC/DCC shall be recorded and shall form a part of the minutes of the meeting.  A  copy  of  the  proceedings  of  the  meeting  shall be  forwarded  to  the concerned Regional Office of the Reserve Bank of India.

## CHAPTER VIII

## Natural Calamities Portal: Monthly Reporting

8.1 The Reserve Bank of India has developed a dedicated portal (https://dbie.rbi.org.in/DCP/) for collection and compilation of data on natural calamities  on  a  real  time  basis  through  a  centralized  system.  The  portal provides facility for uploading data files relating to relief measures extended by banks and notification issued by State Government with regard to natural calamities.

8.2 Banks shall upload the actual data on relief measures every month by the 10 th of  the  following  month. In case there is no natural calamity and/or relief measures extended, a 'NIL' statement shall be uploaded.

8.3  The  SLBC  Convener  Bank  shall  upload  the  notification(s)  issued  by State/District  Authorities on declaration of a natural calamity for which relief measures were implemented by SLBC/banks.

<!-- RBI_PAGE:12 -->

## Master Direction - Reserve Bank of India (Relief Measures by Banks in Areas Affected by Natural Calamities) Directions, 2018:

## List of circulars consolidated for the Master Direction

|   Sr. No. | Circular No.                                           | Date       | Subject                                                                                                                     |
|-----------|--------------------------------------------------------|------------|-----------------------------------------------------------------------------------------------------------------------------|
|        1. | RPCD.No.PS.BC.6/PS.126-84                              | 2.8.1984   | Revised guidelines for relief measures by banks in areas affected by natural calamities                                     |
|        2. | RPCD.No.PLFS.BC.38/PS.126-91/92                        | 21.9.1991  | Banks' assistance to persons affected by riots/ communal disturbances, etc.                                                 |
|        3. | RPCD.No.PLFS.BC.59/05.04.02/92-93                      | 6.1.1993   | Guidelines for Relief Measures by banks in areas affected by natural calamities- (Consumption Loans)                        |
|        4. | RPCD.No.PLFS.BC.128/05.04.02/97-98                     | 20.6.1998  | Relief measures to persons affected by natural calamities - Agricultural advances                                           |
|        5. | RPCD.PLFS.BC.No.42/05.02.02/2005-06                    | 1.10.2005  | The Advisory Committee on Flow of credit to Agriculture and related activities from the Banking System                      |
|        6. | FIDD No.FSD.BC.12/05.10.001/2015-16                    | 21.8.2015  | Guidelines for Relief Measures by Banks in Areas Affected by Natural Calamities                                             |
|        7. | FIDD NO.FSD.BC.27/05.10.001/2015-16                    | 30.06.2016 | Guidelines for Relief Measures by Banks in Areas Affected by Natural Calamities- Utilization of Insurance Proceeds          |
|        8. | Master Direction FIDD.CO.FSD.BC No.8/05.10.001/2017-18 | 03.07.2017 | Master Direction - Reserve Bank of India (Relief Measures by banks in areas affected by Natural Calamities) Directions 2017 |
|        9. | FIDD.CO.FSD.BC.No.13/05.10.006/2017-18                 | 03.08.2017 | Natural Calamities Portal - Monthly Reporting System.                                                                       |