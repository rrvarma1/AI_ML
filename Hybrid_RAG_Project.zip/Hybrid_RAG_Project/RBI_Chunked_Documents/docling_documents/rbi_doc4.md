<!-- RBI_PAGE:1 -->

<!-- image -->

75

<!-- image -->

BANK

OF

<!-- image -->

AzadiKa

Amrit Mahotsav

## भारतीय �रज़वर् बैंक \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ RESERVE BANK OF INDIA\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ www.rbi.org.in

RBI/FIDD/2017-2018/56

Master Direction FIDD.MSME &amp; NFS.12/06.02.31/2017-18                                 July 24, 2017

(Updated as on February 09, 2026) (Updated as on July 23, 2025) (Updated as on June 11, 2024) (Updated as on December 28, 2023) (Updated as on July 29, 2022)

(Updated as on April 25, 2018)

The Chairman / Managing Director / Chief Executive Officer All Scheduled Commercial Banks (excluding Regional Rural Banks)

Madam/Dear Sir,

## Master Direction - Lending to Micro, Small &amp; Medium Enterprises (MSME) Sector

The  Reserve  Bank  of  India  has,  from  time  to  time,  issued  a  number  of  instructions  / guidelines to banks relating to lending to the Micro, Small and Medium Enterprises Sector. The  Master  Direction  enclosed  incorporates  the  updated  instructions  /  guidelines  on  the subject.  The  list  of  circulars  consolidated  in  this  Master  Direction  is  indicated  in  the Appendix.

Yours faithfully

(R Giridharan) Chief General Manager

�वत् ती य समावेशन और �वकास �वभाग , के द्र�य कायार्लय , 10 वी मंिजल , के द्र�य कायार्लय भवन , मुंबई 400 001,

टे�लफोन /Tel No: 91-22-22661000 फै क्स /Fax No: 91-22-22621011/22610948/22610943 ई -मेल / Email ID: cgmincfidd@rbi.org.in

<!-- RBI_PAGE:2 -->

## Master Direction - Reserve Bank of India [Lending to Micro, Small &amp; Medium Enterprises (MSME) Sector] - Directions, 2017

In exercise of the powers conferred by Sections 21 and 35 A of the Banking Regulation Act, 1949, the Reserve Bank of India, being satisfied that it is necessary and expedient in the public interest to do so, hereby, issues the Directions hereinafter specified.

## CHAPTER - I

## PRELIMINARY

## 1.1 Short Title and Commencement

- a) These Directions shall be called the Reserve Bank of India [Lending to Micro, Small &amp; Medium Enterprises (MSME) Sector] Directions, 2017.
- b) These  Directions  shall  come  into  effect  on  the  day  they  are  placed  on  the  official website of the Reserve Bank of India.

## 1.2 Applicability

The provisions of these Directions shall apply to all Scheduled Commercial Banks (excluding Regional Rural Banks RRBs).

## 1.3 Definitions/ Clarifications

In  these Directions, unless the context otherwise requires, the terms herein shall bear the meanings assigned to them as below:

- a)  The MSMED Act, 2006 means 'Micro, Small and Medium Enterprises Development (MSMED) Act, 2006' as notified by the Government of India on June 16, 2006 and the amendments, if any, carried out therein by the Government of India from time to time.
- b) 'Micro,  Small  and  Medium  Enterprises'  mean  the  enterprises  as  defined  in  the MSMED  Act,  2006  and  the  amendments,  if  any,  carried  out  therein  by  the Government of India from time to time.
- c) ['Priority Sector' means the sectors specified in the Master Directions - Reserve Bank of India (Priority Sector Lending - Targets and Classification) Directions, 2025 dated March 24, 2025, as updated from time to time.](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12799)
- d) ['Adjusted  Net  Bank  Credit  (ANBC)'  shall  have  the  same  meaning  as  given  in  the Master  Directions  -  Reserve  Bank  of  India  (Priority  Sector  Lending  -  Targets  and Classification) Directions, 2025 dated March 24, 2025, as updated from time to time.](https://www.rbi.org.in/Scripts/BS_ViewMasDirections.aspx?id=12799)

<!-- RBI_PAGE:3 -->

## CHAPTER - II

## 2. Micro, Small and Medium Enterprises Development (MSMED) Act, 2006

2.1  In  terms  of  Gazette  Notification  S.O.  1364  (E)  dated  March  21,  2025,  an enterprise shall be classified as a micro, small or medium enterprise on the basis of the following criteria viz.,

- i. a micro enterprise, where the investment in plant and machinery or equipment does not exceed ₹2.5 crore and turnover does not exceed ₹10 crore ;
- ii. a small enterprise, where the investment in plant and machinery or equipment does not exceed ₹25 crore and turnover does not exceed ₹100 crore ; and
- iii. a medium enterprise, where the investment in plant and machinery or equipment does not exceed ₹125 crore and turnover does not exceed ₹500 crore .

2.2 All the above enterprises are required to register online on the Udyam Registration portal and obtain 'Udyam Registration Certificate'. For PSL purposes banks shall be guided by the classification recorded in the Udyam Registration Certificate (URC).

2.3  Retail  and  Wholesale  trade  are  included  as  MSMEs  for  the  limited  purpose  of  priority sector lending and are allowed to be registered on Udyam Registration Portal.

2.4  The  certificate  issued  on  Udyam  Assist  Portal  (UAP)  to  Informal  Micro  Enterprises (IMEs) shall be treated at par with Udyam Registration Certificate for the purpose of availing Priority Sector Lending benefits. IMEs with an Udyam Assist Certificate shall be treated as micro enterprises for the purpose of PSL classification.

## CHAPTER - III

## 3 Targets / sub-targets for lending to MSME sector

## 3.1 Priority Sector Guidelines for MSME sector

Scheduled  Commercial  Banks  shall  adhere  to  the  targets/sub-targets  for  lending  to  the MSME sector and related aspects as laid down in the Master Directions - Reserve Bank of India (Priority Sector Lending - Targets and Classification) Directions, 2025 dated March 24, 2025, as updated from time to time.

3.2 In terms of the recommendations of the Prime Minister's Task Force on MSMEs, banks are advised to achieve:

- i) 20 per cent year-on-year growth in credit to micro and small enterprises,
2. ii) 10 per cent annual growth in the number of micro enterprise accounts and

<!-- RBI_PAGE:4 -->

- iii)  60  per  cent  of  total  lending  to  MSE  sector  as  of  the  corresponding  quarter  of  the previous year to micro enterprises.

## CHAPTER - IV

## 4. Common guidelines/Instructions for lending to MSME sector

## 4.1 Collateral 1

- (a) Banks are mandated not to accept collateral security in the case of loans up to ₹ 20 lakh extended to units in the MSE sector. Banks are also advised to extend collateralfree loans up to ₹20 lakh to all units financed under the Prime Minister Employment Generation Programme (PMEGP) administered by KVIC.
- (b) Banks may, on the basis of good track record and financial position of the MSE units, increase the limit to dispense with the collateral requirement for loans up to ₹25 lakh as per their internal policy.
- (c) Banks may  avail the benefit  of  Credit  Guarantee  Scheme  cover,  where applicable.
- (d) However, accepting gold and silver as collateral pledged voluntarily by borrowers for  loans  sanctioned  by  the  banks  upto  the  collateral  free  limit,  will  not  be construed as a violation of the above mandate.

## 4.2 Composite loan

A  composite  loan  limit  of ₹ 1  crore  can  be  sanctioned  by  banks  to  enable  the  MSE entrepreneurs  to  avail  of  their  working  capital  and  term  loan  requirement  through  Single Window.

## 4.3 General Credit Card (GCC) Facility

Banks which are eligible to issue credit cards under the Master Direction -Credit Card and Debit card- Issuance and Conduct Directions, dated April 21, 2022 (as updated from time to time),  may  issue  General  Credit  Cards  to  individuals/entities  sanctioned  working  capital facilities for non-farm entrepreneurial activities which are eligible for classification under the priority  sector  guidelines.  The  terms  and  conditions  of  the  credit  facilities  extended  in  the form of  GCC shall be as per the Board approved policies of the banks, within the overall framework laid down by Reserve Bank. Guidelines on collateral free lending for micro and small units issued from time to time shall apply. Banks shall adhere to the instructions on reporting GCC data as issued by RBI from time to time.

1   Modified  vide  Lending  to  Micro,  Small  &amp;  Medium  Enterprises  (MSME)  Sector  (Amendment) Directions, 2026 dated February 09, 2026 and the amendment shall come into force for all loans to MSE borrowers sanctioned or renewed on or after April 01, 2026.

<!-- RBI_PAGE:5 -->

## 4.4 Streamlining flow of credit to Micro and Small Enterprises (MSEs) for facilitating timely and adequate credit flow during their 'Life Cycle'

In  order  to  provide  timely  financial  support  to  Micro  and  Small  enterprises  facing  financial difficulties  during  their  'Life  Cycle',  detailed  guidelines  were  issued  to  banks  vide  circular FIDD.MSME &amp; NFS.BC.No.60/06.02.31/2015-16  dated  August  27,  2015 on  the  captioned subject. In accordance with the guidelines, banks shall review and tune their lending policies to the MSE sector by incorporating therein the following provisions so as to facilitate timely and adequate availability  of  credit  to  viable  MSE  borrowers  especially  during  the  need  of funds in unforeseen circumstances:

- i) To extend standby credit facility in case of term loans.
2. ii) Additional working capital to meet with emergent needs of MSE units.
3. iii)  Mid-term review of the regular working capital limits, where banks are convinced that changes  in  the  demand  pattern  of  MSE  borrowers  require  increasing  the  existing credit limits of the MSEs, every year based on the actual sales of the previous year.
4. iv)  Timeline for credit decisions for loans up to ₹25 lakh to units in the MSE borrowers shall not be more than 14 working days. For loans above the aforementioned limit, timelines shall be as per the Board approved sanction time norms. All credit related information  pertaining  to  MSMEs  including  timelines  for  credit  decisions,  indicative document checklist etc., shall be displayed under a separate tab prominently on the bank's website.

## 4.5 Debt Restructuring Mechanism for MSMEs

- i) Banks  are  advised  to  follow  the  guidelines/instructions  on  debt  restructuring pertaining  to  MSMEs  contained  in  the  'Master  Circular  -  Prudential  norms  on Income Recognition, Asset Classification and Provisioning pertaining to Advances' as updated from time to time.
2. ii) All commercial banks are also advised in terms of our circular RPCD.SME&amp;NFS.BC.No.  102/06.04.01/2008-09  dated  May  4,  2009  to  do  the following:
- a) put in place loan policies governing extension of credit facilities, Restructuring/Rehabilitation  policy  for  revival  of  potentially  viable  sick  units  / enterprises (now read with guidelines on Framework for Revival and Rehabilitation  of  Micro,  Small  and  Medium  Enterprises  issued  on  March  17, 2016) and non- discretionary One Time Settlement scheme for recovery of nonperforming loans for the MSE sector, with the approval of the Board of Directors and
- b)  give wide publicity to the One-Time settlement scheme implemented by them, by  placing  it  on  the  bank's  website  and  through  other  possible  modes  of

<!-- RBI_PAGE:6 -->

dissemination. They may allow reasonable time to the borrowers to submit the application and also make payment of the dues in order to extend the benefits of the scheme to eligible borrowers.

- c) implement recommendations with regard to timely and adequate flow of credit to the MSE sector.

## 4.6 Framework for Revival and Rehabilitation of MSMEs

The  Ministry  of  Micro,  Small  and  Medium  Enterprises,  Government  of  India,  vide  their Gazette  Notification  dated  May  29,  2015  had  notified  a  'Framework  for  Revival  and Rehabilitation  of  Micro,  Small  and  Medium  Enterprises'  to  provide  a  simpler  and  faster mechanism to address the stress in the accounts of MSMEs and to facilitate the promotion and development of MSMEs. After carrying out certain changes in the captioned Framework in consultation with the Government of India, Ministry of MSME so as to make it compatible with  the  existing  regulatory  guidelines  on  'Income  Recognition,  Asset  Classification  and Provisioning pertaining to Advances' issued to banks by RBI, the guidelines on the captioned Framework along with operating instructions were issued to banks on March 17, 2016. The revival  and  rehabilitation  of  MSME  units  having  loan  limits  up  to ₹ 25  crore  would  be undertaken under this Framework. The revised Framework supersedes our earlier Guidelines  on  Rehabilitation  of  Sick  Micro  and  Small  Enterprises  issued  vide  our  circular RPCD.CO.MSME&amp; NFS.BC.40/06.02.31/2012-2013 dated November 1, 2012, except those relating  to  Reliefs  and  Concessions  for  Rehabilitation  of  Potentially  Viable  Units  and  One Time Settlement, mentioned in the said circular.

The salient features of the Framework are as under:

- i) Before a loan account of an MSME turns into a Non-Performing Asset (NPA), banks or  creditors  should  identify  incipient  stress  in  the  account  by  creating  three  subcategories  under  the  Special  Mention  Account  (SMA)  category  as  given  in  the Framework
2. ii) Any MSME borrower may also voluntarily initiate proceedings under this Framework
3. iii)  Committee approach to be adopted for deciding corrective action plan
4. iv)  Timelines have been fixed for taking various decisions under the Framework

## 4.7 Structured Mechanism for monitoring the credit growth to the MSE sector

Banks shall put in place a structured mechanism to monitor the entire gamut of credit related issues pertaining to the MSE sector. Accordingly, banks shall implement the following:

- i) Credit  Proposal  Tracking  System  (CPTS):  Banks  shall  put  in  place  a  CPTS/ equivalent  tracking  mechanism  to  facilitate  central  registration  and  a  system  of  etracking of all MSME loan applications. This mechanism shall automatically generate an acknowledgement of the application, having a unique application serial number for

<!-- RBI_PAGE:7 -->

both  physical  and  online  applications.  Further,  it  shall  also  be  ensured  that  the acknowledgement  and  status of the application is sent automatically to the applicants.

- ii) Indicative check list of documents: Banks shall furnish the MSME borrowers with an indicative checklist of documents required for processing the loan application at the time of applying for the loan.
- iii)  Monitoring  the  loan  application  disposal  process:  Banks  shall  monitor  the  loan application disposal process and pendency beyond sanction time norms at appropriate levels on a quarterly basis. The position in this regard shall be displayed by banks on their websites in the format specified in (Annex I) within one month from the end of the preceding quarter.
- iv)  Reasons for  rejection  of  loan  applications:  Banks  shall,  within  the  Board  approved sanction time norms, convey to the MSME  borrowers in writing the main reason/reasons which, in the opinion of the bank after due consideration, have led to rejection of the loan applications.
- v) Comprehensive Performance MIS: Banks shall implement a system-driven comprehensive performance management information system (MIS) at branches and supervisory levels (region, zone, head office). The Performance should be critically evaluated on a regular basis. The credit flow to the sector shall also be reviewed by the Board of the banks at periodic intervals.

Detailed guidelines were issued to the scheduled commercial banks vide our circular RPCD. MSME&amp;NFS.BC.No.74/06.02.31/2012-13 dated May 9, 2013.

## Chapter - V

## 5. Institutional arrangements

## 5.1 Specialised MSME branches

Public  sector  banks  are  advised  to  open  at  least  one  specialised  branch  in  each  district. Further,  banks  have  been  permitted  to  categorise  their  general  banking  branches  having 60% or more of their advances to MSME sector as specialized MSME branches in order to encourage them to open more specialised MSME branches for providing better service to this sector as a whole. As per the policy package announced by the Government of India for stepping up credit to MSME sector, the public sector banks would ensure specialized MSME branches in identified clusters/centres with preponderance of small enterprises to enable the entrepreneurs  to  have  easy  access  to  the  bank  credit  and  to  equip  bank  personnel  to develop  requisite  expertise.  Though  their  core  competence  will  be  utilized  for  extending finance and other services to MSME sector, they will have operational flexibility to extend finance/render other services to other sectors/borrowers. Banks may take care to train the officials posted in such branches appropriately.

<!-- RBI_PAGE:8 -->

## 5.2 Empowered Committee on MSMEs

As part of the announcement made by the Union Finance Minister, Empowered Committees on  MSMEs  are  constituted  at  the  Regional  Offices  of  Reserve  Bank  of  India,  under  the Chairmanship of the Regional Directors with the representatives of SLBC Convenor, senior level  officers  from  two  banks  having  predominant  share  in  MSME  financing  in  the  state, representative  of  SIDBI  Regional  Office,  the  Director  of  MSME  or  Industries  of  the  State Government,  one or  two  senior  level  representatives  from  the  MSME  Associations  in  the state,  and  a  senior  level  officer  from  SFC/SIDC as  members. The Committee would meet periodically and review the progress in MSME financing as also revival and rehabilitation of stressed Micro, Small and Medium units. It would also coordinate with other banks/financial institutions and the state government in removing bottlenecks, if any, to ensure smooth flow of credit to the sector. The committees may decide the need to have similar committees at cluster/district levels.

## 5.3 Banking Codes and Standards Board of India (BCSBI)

BCSBI in collaboration with the Indian Banks' Association (IBA), Reserve Bank of India (RBI) and  member  banks  had  evolved  the  'Code  of  Bank's  Commitment  to  Micro  and  Small Enterprises' - which set minimum standards of banking practices for member banks to follow when they are dealing with  Micro  and  Small  Enterprises.  The  objective  of  the  Code  is  to promote good banking practices, setting minimum standards for the adherents, increasing transparency,  achieving  higher  operating  standards  and  above  all,  promoting  a  cordial banker-customer  relationship  which  would  foster  confidence  in  the  banking  system.  The Code lays great  emphasis  on  transparency  and  providing  full  information  to  the  customer before  a  product  or  service  is  sold  to  him/her.  Above  all,  member  banks  of  BCSBI  have voluntarily adopted the Code for implementation. While BCSBI has initiated the process of its dissolution, banks may continue to follow their commitments as hitherto under the Code of Bank's Commitment to Micro and Small Enterprises.

## 5.4  Micro  and  Small  Enterprises  Sector  -  The  imperative  of  Financial  Literacy  and consultancy support

Keeping in view the high extent of financial exclusion in the MSME sector, it is imperative for banks that the excluded units are brought within the fold of the formal banking sector. The lack  of  financial  literacy,  operational  skills,  including  accounting  and  finance,  business planning etc. represent formidable challenge for MSE borrowers underscoring the need for facilitation by banks in these critical financial areas. Moreover, MSE enterprises are further handicapped  in  this  regard  by  absence  of  scale  and  size.  To  effectively  and  decisively address  these  handicaps,  scheduled  commercial  banks  were  advised  vide  our  circular RPCD.MSME  &amp;  NFS.BC.No.20/06.02.31/2012-13  dated  August  1,  2012  that  they  could either separately set up special cells at their branches, or vertically integrate this function in the Financial Literacy Centres (FLCs) set up by them, as per their comparative advantage. The  bank  staff  should  also  be  trained  through  customised  training  programs  to  meet  the specific  needs  of  the  sector.  Further,  Financial  Literacy  Centres  operated  by  Scheduled commercial Banks have been advised vide our circular FIDD.FLC.BC.No.22/12.01.018/2016-17  dated  March  2,  2017  to  conduct  target  specific financial literacy camps, where one of the target groups is small entrepreneurs.

<!-- RBI_PAGE:9 -->

## 5.5 Cluster Approach

A  cluster  shall  mean  a  cluster  identified  by  the  Ministry  of  Micro,  Small  and  Medium Enterprises, Government of India or the respective State /UT Governments. SLBC/UTLBC Convenor  banks  shall  display  the  list  of  these  clusters  on  their  portals  and  update  them semi-annually as at end-March and end-September. The updated list of clusters identified by Ministry  of  MSME  may  be  accessed  from  Ministry's  official  website,  while  information  on clusters recognized by State Governments/Union Territories shall be obtained directly from the respective authorities.

i)    The lead bank of a district shall promote 'credit-linkage' in all clusters located within the district.  The  initiatives  under  promotion  of  the  credit-linkage,  shall  include  but  not  be restricted to the following measures:

- Assessing the credit requirements of the MSE units in the clusters and addressing their credit needs directly or facilitating their linkage with other banks operating in the area for credit proposals.
- Creating awareness among the MSE units in the clusters regarding the importance of formal credit linkage through various forums including financial literacy camps.
- Enabling coverage under various skill development initiatives in the district.
- Focused  attention  and  proactive  measures  to  improve  financial  services  in  the underbanked clusters.

ii) The banks shall ensure that the credit needs of clusters are appropriately included in the exercise of preparation of branch/block level plans so that the same can be aggregated by lead  banks  to  form  the  District  Credit  Plan  (DCP)  and  subsequently  by  SLBC  /UTLBC Convenor banks to prepare the Annual Credit Plan (ACP).

- iii) The SLBC /UTLBC Convenor banks shall disclose the credit extended to clusters in the State/UT on their portal every quarter in the prescribed format (Annex II).

## 5.6 Delayed Payment

In  the  Micro,  Small  and  Medium  Enterprises  Development  (MSMED),  Act  2006,  the provisions  of  The  Interest  on  Delayed  Payment  to  Small  Scale  and  Ancillary  Industrial Undertakings Act, 1998, have been strengthened as under:

<!-- RBI_PAGE:10 -->

- i) The buyer has to make payment to the supplier on or before the date agreed upon between  him  and  the  supplier  in  writing  or,  in  case  of  no  agreement,  before  the appointed day. The period agreed upon between the supplier and the buyer shall not exceed  forty-five days  from the date of acceptance  or  the  day  of  deemed acceptance.
2. ii) In case the buyer fails to make payment of the amount to the supplier, he shall be liable to pay compound interest with monthly rests to the supplier on the amount from the appointed day or, on the date agreed on, at three times of the Bank Rate notified by Reserve Bank.
3. iii)  For any goods supplied or services rendered by the supplier, the buyer shall be liable to pay the interest as advised at (ii) above.
4. iv)  In case of dispute with regard to any amount due, a reference shall be made to the Micro and Small Enterprises Facilitation Council, constituted by the respective State Government.

Further,  banks  are  advised  to  fix  sub-limits  within  the  overall  working  capital  limits  to  the large borrowers specifically for meeting the payment obligation in respect of purchases from MSMEs.

## CHAPTER - VI

## 6. Committees on flow of Credit to MSE sector

Scheduled Commercial Banks may be guided by the contents of the following circulars while extending credit to MSE sector:

## 6.1 Report of the Committee to Examine the Adequacy of Institutional Credit to SSI Sector (now MSE) and Related Aspects (Nayak Committee)

All  scheduled  commercial  banks  were  advised  vide  our  circular  RPCD.PLNFS.BC.No. 61/06.0262/2000-01 dated March 2, 2001 to implement the Nayak Committee Recommendations.

## 6.2 Report of the Working Group on Flow of Credit to SSI (now MSE) Sector (Ganguly Committee)

The recommendations of the Committee were communicated to banks for implementation vide circular RPCD.PLNFS.BC.28/06.02.31(WG)/2004-05 dated September 4, 2004.

## 6.3 Working Group on Rehabilitation of Sick SMEs (Chairman: Dr. K.C. Chakrabarty)

Banks  were  advised  vide  circular  dated  RPCD.SME&amp;NFS.BC.No.102/06.04.01/2008-09 dated  May  4,  2009  to  consider  implementation  of  the  recommendations,  inter  alia,  that lending in case of all advances upto ₹ 2 crores may be done on the basis of scoring model.

<!-- RBI_PAGE:11 -->

## 6.4 Prime Minister's Task Force on Micro, Small and Medium Enterprises

A High-Level Task Force was constituted by the Government of India (Chairman: Shri T K A Nair),  in  January  2010,  to  consider  various  issues  raised  by  Micro,  Small  and  Medium Enterprises (MSMEs). The Task Force recommended several measures having a bearing on the functioning of MSMEs, viz., credit, marketing, labour, exit policy, infrastructure/technology/skill development and taxation. The comprehensive recommendations  cover  measures  that  need  immediate  action  as  well  as  medium  term institutional measures along with legal and regulatory structures and recommendations for North- Eastern States and Jammu &amp; Kashmir.

Banks are urged to keep in view the recommendations made by the Task Force and take effective  steps  to  increase  the  flow  of  credit  to  the  MSE  sector,  particularly  to  the  micro enterprises. A circular was issued to all scheduled commercial banks vide RPCD.SME&amp;NFS BC.No. 90/06.02.31/2009-10 dated June 29, 2010 advising implementation of the recommendations of the Prime Minister's Task Force on MSMEs.

## 6.5 [********] 2

[2   Deleted  vide  Lending  to  Micro,  Small  &amp;  Medium  Enterprises  (MSME)  Sector  (Amendment) Directions, 2026 dated February 09, 2026](https://rbi.org.in/Scripts/NotificationUser.aspx?Id=13290&Mode=0)

<!-- RBI_PAGE:12 -->

## Annex -I

From: ………………………….                                                                                                                             To: …………………………….

## MSME ACCOUNTS -Format for reporting of Applications received/sanctioned/rejected for the Quarter ended  JUNE / SEPT / DEC / MAR …………..

No. of A/Cs in actuals &amp; Amount in ₹ Crore Annex -II

| Sector                                                                                      | Micro Enterprises   | Micro Enterprises   | Micro Enterprises   | Micro Enterprises   | Small Enterprises   | Small Enterprises   | Small Enterprises   | Small Enterprises   | Medium Enterprises   | Medium Enterprises   | Medium Enterprises   | Medium Enterprises   | Medium Enterprises   | Total MSME   | Total MSME    | Total MSME   |
|---------------------------------------------------------------------------------------------|---------------------|---------------------|---------------------|---------------------|---------------------|---------------------|---------------------|---------------------|----------------------|----------------------|----------------------|----------------------|----------------------|--------------|---------------|--------------|
| Sector                                                                                      | FB                  | FB                  | NFB                 | NFB                 | FB                  | FB                  | NFB                 | NFB                 | FB                   | FB                   | NFB                  | NFB                  | NFB                  | FB           | NFB           | NFB          |
| Sector                                                                                      | APPLICATION S       | AM T                | APPLICATION S       | AM T                | APPLICATION S       | AM T                | APPLICATION S       | AM T                | APPLICATION S        | AM T                 | APPLICATION S        | AM T                 | APPLICATION S        | AM T         | APPLICATI ONS | A MT         |
| Applications pending at the beginning of Quarter                                            |                     |                     |                     |                     |                     |                     |                     |                     |                      |                      |                      |                      |                      |              |               |              |
| Applications pending beyond bank prescribed sanction time norms at the beginning of Quarter |                     |                     |                     |                     |                     |                     |                     |                     |                      |                      |                      |                      |                      |              |               |              |
| Applications received During the Quarter                                                    |                     |                     |                     |                     |                     |                     |                     |                     |                      |                      |                      |                      |                      |              |               |              |
| Applications sanctioned during the Quarter                                                  |                     |                     |                     |                     |                     |                     |                     |                     |                      |                      |                      |                      |                      |              |               |              |
| Out of sanctions made, Disbursed during the Quarter (inclusive of previous sanctions)       |                     |                     |                     |                     |                     |                     |                     |                     |                      |                      |                      |                      |                      |              |               |              |
| Applications rejected during the Quarter                                                    |                     |                     |                     |                     |                     |                     |                     |                     |                      |                      |                      |                      |                      |              |               |              |
| Applications pending at the end of the Quarter                                              |                     |                     |                     |                     |                     |                     |                     |                     |                      |                      |                      |                      |                      |              |               |              |
| Applications pending beyond bank prescribed sanction time norms at the end of Quarter       |                     |                     |                     |                     |                     |                     |                     |                     |                      |                      |                      |                      |                      |              |               |              |

<!-- RBI_PAGE:13 -->

<!-- image -->

Data on Credit extended to MSME clusters in the State/UT of .........for the QE…....

(No. in Actual, Amount O/s in ₹ Crore)

Sr. No.

District

Lead

Bank

Name of

the

Cluster

Sector (Textiles,

Engineering

works, etc)

Total No.

of MSME

units in the

cluster

No of credit

linked

MSME units

in the

cluster

Credit outstanding at the end of the

quarter to the credit linked MSME

units

1

2

3

4

5

6

7

8

1

2

3

4

5

6

7

8

9

10

<!-- RBI_PAGE:14 -->

## List of Circulars consolidated by the Master Direction

|   SI. No. | Circular No.                                | Date              | Subject                                                                                                                                      | Paragraph No.   |
|-----------|---------------------------------------------|-------------------|----------------------------------------------------------------------------------------------------------------------------------------------|-----------------|
|         1 | FIDD.MSME & NFS.BC.No.12 /06.02.31/2025-26  | February 09, 2026 | Lending to Micro, Small & Medium Enterprises (MSME) Sector (Amendment) Directions, 2026                                                      | 4.1             |
|         2 | FIDD.CO.FSD.BC.No.08 /05.05.010/2025-26     | July 11, 2025     | Lending Against Gold and Silver Collateral - Voluntary Pledge of Gold and Silver as Collateral for Agriculture and MSME Loans                | 4.1             |
|         3 | FIDD.CO.PSD.BC.13/04.0 9.001/2024-25        | March 24, 2025    | Reserve Bank of India (Priority Sector Lending - Targets and Classification) Directions, 2025                                                | 1.3, 3.1        |
|         4 | FIDD.MSME & NFS.BC.No.13 /06.02.31/2023-24  | December 28, 2023 | Classification of MSMEs                                                                                                                      | 2.2             |
|         5 | FIDD.MSME & NFS.BC.No.09/06.02.31/2 023-24  | May 09, 2023      | Formalisation of Informal Micro Enterprises on Udyam Assist Platform                                                                         | 2.4             |
|         6 | FIDD.MSME & NFS.BC.No.06/06.02.31/2 023-24  | April 25, 2023    | General Credit Card (GCC) Facility - Review                                                                                                  | 4.3             |
|         7 | FIDD.MSME & NFS.BC.No.13/06.02.31/2 021-22  | July 7, 2021      | New Definition of Micro, Small and Medium Enterprises - Addition of Retail and Wholesale Trade                                               | 2.3             |
|         8 | FIDD.MSME & NFS. BC. No. 4/06.02.31/2020-21 | August 21, 2020   | New Definition of Micro, Small and Medium Enterprises - clarifications                                                                       | 2.2             |
|         9 | FIDD.FLC.BC.No.22/12.01 .018/2016-17        | March 2, 2017     | Financial Literacy by FLCs (Financial Literacy Centres) and rural branches - Policy Review                                                   | 5.4             |
|        10 | FIDD.MSME&NFS.BC.No. 21/06.02.31/2015-16    | March 17, 2016    | Framework for Revival and Rehabilitation of Micro, Small and Medium Enterprises (MSMEs)                                                      | 4.6             |
|        11 | FIDD.MSME&NFS.BC.No. 60/06.02.31/2015-16    | August 27, 2015   | Streamlining flow of credit to Micro and Small Enterprises (MSEs) for facilitating timely and adequate credit flow during their 'Life Cycle' | 4.4             |
|        12 | RPCD.MSME&NFS.BC.No .74/06.02.31/2012-13    | May 9, 2013       | Structured Mechanism for monitoring the credit growth to the MSE sector                                                                      | 4.7             |

## Appendix

<!-- RBI_PAGE:15 -->

|   13 | RPCD.CO.MSME&NFS.B C.40/06.02.31/2012-2013   | November 1, 2012   | Guidelines for Rehabilitation of Sick Micro and Small Enterprises                                                                              | 4.6      |
|------|----------------------------------------------|--------------------|------------------------------------------------------------------------------------------------------------------------------------------------|----------|
|   14 | RPCD.MSME&NFS.BC.No .20/06.02.31/2012-13     | August 1, 2012     | Micro and Small Enterprises Sector - The imperative of Financial Literacy and consultancy support                                              | 5.4      |
|   15 | RPCD.MSME&NFS.BC.No .53/06.02.31/2011-12     | January 4, 2012    | Issue of Acknowledgement of Loan Applications to MSME borrowers                                                                                | 4.7      |
|   16 | RPCD.SME&NFS.No.90/0 6.02.31/2009-10         | June 29, 2010      | Recommendations of the Prime Minister's High Level Task Force on MSMEs                                                                         | 3.2, 6.4 |
|   17 | RPCD.SME&NFS.BC.No.7 9/06.02.31/2009-10      | May 6, 2010        | Working Group to Review the Credit Guarantee Scheme for Micro and Small Enterprises (MSEs) - Collateral free loans to MSEs                     | 6.5      |
|   18 | RPCD.SME&NFS.No.9470 /06.02.31 (P)/2009-10   | March 11, 2010     | Sanction of Composite Loans to the Micro and Small Enterprises (MSE) sector                                                                    | 4.2      |
|   19 | RPCD.SME&NFS.No.1365 7/06.02.31(P)/2008-09   | June 18, 2009      | Collateral free loans to the units financed under PMEGP                                                                                        | 4.1      |
|   20 | RPCD.SME&NFS.BC.No.1 02/06.04.01/2008-09     | May 4, 2009        | Credit delivery to the Micro and Small Enterprises Sector                                                                                      | 6.3      |
|   21 | RPCD.PLNFS.BC.No.63/0 6.02.31/2006-07        | April 4, 2007      | Credit flow to Micro, Small and Medium Enterprises Sector - Enactment of the Micro, Small and Medium Enterprises Development (MSMED), Act 2006 | 5.6      |
|   22 | RPCD.PLNFS.BC.28/06.0 2.31(WG)/ 2004-05      | September 4, 2004  | Working Group on Flow of Credit to SSI sector                                                                                                  | 6.2      |
|   23 | RPCD.PLNFS.BC.39/06.0 2.80/2003-04           | November 3, 2003   | Credit facilities for SSIs - Collateral Free Loans                                                                                             | 4.1      |
|   24 | DBOD.No.BL.BC.74/22.01. 001/2002             | March 11, 2002     | Conversion of General Banking Branches to Specialised SSI Branches                                                                             | 5.1      |
|   25 | RPCD.No.PLNFS.BC.61/0 6.0262/2000-01         | March 2, 2001      | Implementation of Nayak Committee Recommendations-Progress made by banks-Study of specialized SSI branches                                     | 6.1      |
|   26 | IECD.No.5/08.12.01/2000- 01                  | October 16, 2000   | Flow of Credit to SSI Sector- Decision of the Group of Ministers                                                                               | 5.6      |