<!-- RBI_PAGE:1 -->

<!-- image -->

## HTRd Ryd \_RESERVE BANK OF INDIA

www.rbi.org.in

RBI/2018-19/10 FIDD.CO.FSD.BC.No.6/05.05.010/2018-19                                                                  July 4, 2018

The Chairman / Managing Director /Chief Executive Officer All Scheduled Commercial Banks (including Small Finance Banks and excluding RRBs)

Madam/Sir,

## Master Circular - Kisan Credit Card (KCC) Scheme

The Reserve Bank of India has issued guidelines on Kisan Credit Card (KCC) scheme from time to  time.  This  Master Circular consolidates the relevant guidelines issued by the Bank on Kisan Credit Card scheme upto June 30, 2018 as listed in the Appendix.

2. The Master Circular has been placed on the RBI website http://www.rbi.org.in.

Yours faithfully,

(Sonali Sen Gupta) Chief General Manager

Encl: As above

<!-- RBI_PAGE:2 -->

## Master Circular on the Kisan Credit Card (KCC) Scheme

## 1 Introduction

The Kisan Credit Card (KCC) scheme was introduced in 1998 for issue of Kisan Credit Cards to farmers on the basis of their holdings for uniform adoption by the banks so that farmers may use them to readily purchase agriculture inputs such as seeds, fertilizers, pesticides etc. and  draw  cash  for  their  production  needs.  The  scheme  was  further  extended  for  the investment credit requirement of farmers viz. allied and non-farm activities in the year 2004. The scheme was further revisited in 2012 by a working Group under the Chairmanship of Shri T.  M.  Bhasin,  CMD, Indian Bank with a view to simplify the scheme and facilitate issue of Electronic Kisan Credit Cards. The  scheme  provides  broad  guidelines  to banks  for operationalizing the KCC scheme. Implementing banks will have the discretion to adopt the same to suit institution/location specific requirements.

## 2 Applicability of the Scheme

The Kisan Credit Card Scheme detailed in the ensuing paragraphs is to be implemented by Commercial Banks, RRBs, Small Finance Banks and Cooperatives.

## 3 Objective / Purpose

The Kisan Credit Card scheme aims at providing adequate and timely credit support from the banking system under a single window with flexible and simplified procedure to the farmers for their cultivation and other needs as indicated below:

- a. To meet the short term credit requirements for cultivation of crops;
- b. Post-harvest expenses;
- c. Produce marketing loan;
- d. Consumption requirements of farmer household;
- e. Working capital for maintenance of farm assets and activities allied to agriculture;
- f. Investment credit requirement for agriculture and allied activities.

Note: The aggregate of components ' a' to 'e' above will form the short term credit limit portion and the aggregate of components under ' f' will  form the long term credit limit portion.

## 4 Eligibility

- i. Farmers - individual/joint borrowers who are owner cultivators;
- ii. Tenant farmers, oral lessees &amp; share croppers;
- iii. Self Help Groups (SHGs) or Joint Liability Groups (JLGs) of farmers including tenant farmers, share croppers etc.

<!-- RBI_PAGE:3 -->

## 5 Fixation of credit limit / Loan amount

The credit limit under the Kisan Credit Card may be fixed as under :

## 5.1 All farmers other than marginal farmers 1 :

## 5.1.1 The short term limit to be arrived for the first year (For cultivating single crop in a year):

Scale of finance for the crop (as decided by District Level Technical Committee) x Extent of area cultivated + 10%  of limit towards postharvest/household/  consumption  requirements  +  20%  of  limit  towards  repairs and maintenance expenses of farm assets + crop insurance and/or  accident insurance including PAIS, health insurance &amp; asset insurance.

## 5.1.2 Limit for second &amp; subsequent year

First year limit for crop cultivation purpose arrived at as above plus 10% of the limit towards cost escalation / increase in scale of finance for every successive year (2nd, 3rd, 4th and 5th year) and estimated term loan component for the tenure of Kisan Credit Card, i.e., five years. (Illustration I)

## 5.1.3 For cultivating more than one crop in a year

The limit is to be fixed as above depending upon the crops cultivated as per proposed cropping pattern for the first year plus an additional 10% of the limit towards cost escalation / increase in scale of finance for every successive year (2nd,  3rd,  4th  and  5th  year).  It  is  assumed  that  the  farmer  adopts  the  same cropping  pattern  for  the  succeeding  four  years.  In  case  the  cropping  pattern adopted  by  the  farmer  is  changed  in  the  subsequent  year,  the  limit  may  be reworked. (Illustration I)

## 5.1.4 Term loan for investment

The term loan for investment is to be made towards land development, minor irrigation,  purchase  of  farm  equipment  and  allied  agricultural  activities.  The banks  may  fix  the  quantum  of  credit  for  term  and  working  capital  limit  for agricultural  and  allied  activities,  etc.,  based  on  the  unit  cost  of  the  asset/s proposed  to  be  acquired  by  the  farmer,  the  allied  activities  already  being undertaken on the farm, the bank's judgment on repayment capacity vis-a-vis total loan burden devolving on the farmer, including existing loan obligations.

The long term loan limit should be based on the proposed investment(s) during the five year period and the bank's perception on the repaying capacity of the farmer.

1 Farmers with landholding of up to 1 hectare (Marginal Farmers). Farmers with a landholding of more than 1 hectare and up to 2 hectares (Small Farmers).

<!-- RBI_PAGE:4 -->

## 5.1.5 Maximum Permissible Limit

The short term loan limit arrived for the 5th year plus the estimated long term loan  requirement  will  be  the  Maximum  Permissible  Limit  (MPL)  and  is  to  be treated as the Kisan Credit Card limit.

## 5.1.6 Fixation of Sub-limits

i.  Short term loans and term loans are governed by different interest rates. At present,  short  term  crop  loans  upto  ₹  3  lakh  are  covered  under  Interest Subvention Scheme/Prompt Repayment Incentive scheme of the Government of India 2 .  Further, repayment schedule and norms are different for short term and term loans. Hence, in order to have operational and accounting convenience, the card limit is to be bifurcated into separate sub-limits for short term cash credit limit cum savings account and term loans .

ii. Drawing  limit for  short  term  cash  credit  should  be  fixed  based  on  the cropping pattern. The amount(s) for crop production, repair and maintenance of farm  assets  and  consumption  may  be  allowed  to  be  drawn  as  per  the convenience of the farmer. In case the revision of scale of finance for any year by  the  district  level  technical  committee  exceeds  the  notional  hike  of  10% contemplated while fixing the five year limit, a revised drawable limit may be fixed  in  consultation  with  the  farmer.  In  case  such  revisions  require  the  card limit  itself  to  be  enhanced  (4th  or  5th  year),  the  same  may  be  done  and  the farmer be so advised.

iii.  For term loans, installments may be allowed to be withdrawn based on the nature of investment and repayment schedule drawn as per the economic life of the proposed investments. It is to be ensured that at any point of time the total liability should be within the drawing limit of the concerned year .

iv. Wherever the card limit / liability so arrived warrants additional security, the banks may take suitable collateral as per their policy.

## 5.2 For Marginal Farmers

A flexible limit of ₹ 10,000 to ₹ 50,000 may be provided (as Flexi KCC) based on the land holding and crops grown including post-harvest warehouse storage related credit needs  and  other  farm  expenses,  consumption  needs,  etc.,  plus  small  term  loan investment(s)  like  purchase  of  farm  equipment(s),  establishing  mini  dairy/backyard poultry  as  per  assessment  of  the  Branch  Manager  without  relating  it  to  the  value  of land. The composite KCC limit is to be fixed for a period of five years on this basis.

2 Please refer to guidelines on Interest Subvention Scheme on crop loans as announced by GoI and issued by RBI from time to time.

<!-- RBI_PAGE:5 -->

Wherever higher limit is required due to change in cropping pattern and / or scale of finance,  the  limit  may  be  arrived  at  as  per  the  estimation  indicated  at  para  4.1 (Illustration II)

## 6 Disbursement

- 6.1 The short  term  component  of  the  KCC  limit  is  in  the  nature  of  revolving  cash  credit facility. There should be no restriction in number of debits and credits. The drawing limit for  the  current  season/year  could  be  allowed  to  be  drawn  using  any  of  the  following delivery channels.
- i. operation through branch;
- ii. operation using cheque facility;
- iii. withdrawal through ATM /debit cards
- iv. operation through Business  Correspondents  and  'banking  outlet/part-time banking outlet ' 3
- v. operation  through  PoS  available  in  Sugar  Mills/Contract  farming  companies, etc., especially for tie-up advances;
- vi. operations through PoS available with input dealers;
- vii. Mobile based transfer transactions at agricultural input dealers and mandies.

Note :  (v),(vi)  &amp;  (vii)  to  be  introduced  as  early  as  possible  so  as  to  reduce transaction costs of both the bank as well as the farmer.

- 6.2 The long term loan for investment purposes may be drawn as per installment fixed.

## 7 Issue of Electronic Kisan Credit Cards

All  new  KCC  must  be  issued  as  smart  card  cum  debit  card  as  laid  down  in  Part  II  of  the Annex. Further, at the time of renewal of existing KCC; farmers must be issued smart card cum debit card.

The  short  term  credit  limit  and  the  term  loan  limit  are  two  distinct  components  of  the aggregate  KCC  limit  bearing  different  rates  of  interest  and  repayment  periods.  Until  a composite card could be issued with appropriate software to separately account transactions in the sub limits, two separate electronic cards may be issued for all new/renewed cards.

## 8 Validity/Renewal

- i. Banks may determine the validity period of KCC and its periodic review.
- ii. The  review  may  result in continuation of the facility, enhancement  of  limit or cancellation of the limit/withdrawal of the facility depending upon increase in cropping area/pattern and performance of the borrower.

[3 DBR's Circular on Rationalisation of Branch Authorisation Policy- Revision of Guidelines](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=10972&Mode=0)

<!-- RBI_PAGE:6 -->

- iii. When the bank has granted extension and/or re-schedule the period of repayment on account of natural calamities affecting the farmer, the period for reckoning the status of operations as satisfactory or otherwise would get extended together with the extended amount  of  limit.  When  the  proposed  extension  is  beyond  one  crop  season,  the aggregate of debits for which extension is granted is to be transferred to a separate term loan account with stipulation for repayment in installments.

## 9 Rate of Interest (ROI) :

The  rate  of  interest  will  be  as  stipulated  in  DBR  Master  Directions  on  Interest  Rate  on Advances.

## 10 Repayment Period :

- 10.1  The repayment period may be fixed by banks as per the anticipated harvesting  and marketing period for the crops for which the loan has been granted.
- 10.2 The  term  loan  component  will  be  normally  repayable  within  a  period  of  5  years depending on the type of activity/investment as per the existing guidelines applicable for investment credit.
- 10.3 Financing banks may, at their discretion, provide longer repayment period for term loan depending on the type of investment.

## 11 Margin

To be decided by banks.

## 12 Security

- 12.1 Security will be applicable as per RBI guidelines prescribed from time to time.
- 12.2 Security requirement may be as under :
- i. Hypothecation  of  crops: For  KCC  limit  upto  ₹  1.00  lakh  banks  are  to  waive margin/security requirements.
- ii. With tie-up for recovery : Banks may consider sanctioning loans on hypothecation  of  crops  up  to  card  limit  of  ₹  3.00  lakh  without  insisting  on collateral security.
- iii. Collateral security: Collateral security may be obtained at the discretion of Bank for loan limits above ₹ 1.00 lakh in case of non-tie-up and above ₹ 3.00 lakh in case of tie-up advances.
- iv. In states where banks have the facility of on-line creation of charge on the land records, the same shall be ensured.

<!-- RBI_PAGE:7 -->

## 13. Other features

Uniformity to be adopted in respect of following:

- 13.1 The  applicable  interest  subvention  /incentive  for  prompt  repayment 4 as  advised  by Government  of  India  and/or  State  Governments.  The  bankers  will  give  adequate publicity of the facility so that maximum farmers may benefit from the scheme.
- 13.2 Besides the mandatory crop insurance, the KCC holder should have the option to avail the benefit of any type of asset insurance, accident insurance (including PAIS), health insurance (wherever product is available) and have premium paid through his/her KCC account. Premium has to be borne by the farmer/bank according to the terms of the scheme. Farmer beneficiaries should be made aware of the insurance cover available and  their  consent  (except  in  case  of  crop  insurance,  it  being  mandatory)  is  to  be obtained, at the application stage itself.
- 13.3  A one-time  documentation 5 at  the  first  time  of  availment  of  KCC  loan  and  thereafter simple  declaration  (about  crops  grown/proposed)  by  farmer  from  the  second  year onwards.

## 14 Classification of account as NPA :

- 14.1  The extant prudential norms on income recognition, asset-classification and provisioning 6 will apply for loans granted under the KCC Scheme.
- 14.2 Charging of interest is to be done uniformly as is applicable to agricultural advances.
3. 15 Processing fee, inspection charges and other charges may be decided by banks.
4. 16 Other conditions while implementing the revised guidelines of KCC Scheme :
- 16.1 In case the farmer applies for loan against the warehouse receipt of his produce, the banks would consider such requests as per the established procedure and guidelines. However, when such loans are sanctioned, these should be linked with the crop loan account, if any, and the crop loan outstanding in the account could be settled at the stage of disbursal of the pledge loan, if the farmer so desires.
- 16.2 The  National  Payments  Corporation  of  India  (NPCI)  will  design  the  KCC  card  to  be adopted by all the banks with their branding.

…………………………………………………………………………………………………….

4 Currently not applicable to Small Finance Banks/urban &amp; metro branches of Private Sector Banks.

5 Documentation as per banks' internal guidelines

6 DBR's Master Circular on Income Recognition, Asset Classification and Provisioning Norms

<!-- RBI_PAGE:8 -->

## Illustration I

## A. Small farmer cultivating multiple crops in a year

|   1. | Assumptions   | Assumptions                                                                                               | Assumptions                                                                      |
|------|---------------|-----------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------|
|      | A.            | Land holding : 2 acres                                                                                    | Land holding : 2 acres                                                           |
|      | B.            | Cropping Pattern                                                                                          | Cropping Pattern                                                                 |
|      |               | Paddy - 1 acre (Scale of finance plus crop insurance per acre : ₹.11000)                                  | Paddy - 1 acre (Scale of finance plus crop insurance per acre : ₹.11000)         |
|      |               | Sugarcane - 1 acre (Scale of finance plus crop insurance per acre : ₹.22,000)                             | Sugarcane - 1 acre (Scale of finance plus crop insurance per acre : ₹.22,000)    |
|      | C.            | Investment / Allied Activities                                                                            | Investment / Allied Activities                                                   |
|      |               | Establishment of 1+1 Dairy Unit in 1st Year () (Unit Cost : ₹ 20,000 per animal)                          | Establishment of 1+1 Dairy Unit in 1st Year () (Unit Cost : ₹ 20,000 per animal) |
|      |               | Replacement of Pump set in 3rd year (Unit Cost : ₹.30,000)                                                | Replacement of Pump set in 3rd year (Unit Cost : ₹.30,000)                       |
|   2. | (i)           | Crop loan Component                                                                                       | Crop loan Component                                                              |
|      |               | Cost of cultivation of 1 acre of Paddy and 1acre of Sugarcane (11,000+22,000)                             | ₹.33,000                                                                         |
|      |               | Add : 10% towards post-harvest / household expense / consumption                                          | ₹. 3,300                                                                         |
|      |               | Add : 20% towards farm maintenance                                                                        | ₹. 6,600                                                                         |
|      |               | Total Crop Loan limit for 1st year                                                                        | ₹. 42,900                                                                        |
|      |               | Loan Limit for 2nd year                                                                                   |                                                                                  |
|      |               | Add : 10% of the limit towards cost escalation / increase in scale of finance (10% of 42900 i.e 4300)     | ₹. 4,300                                                                         |
|      |               |                                                                                                           | ₹. 47,200                                                                        |
|      |               | Loan Limit for 3rd year                                                                                   |                                                                                  |
|      |               | Add : 10% of the limit towards cost escalation / increase in scale of finance (10% of 47,200 i.e., 4,700) | ₹. 4,700 ₹. 51,900                                                               |
|      |               | Loan Limit for 4th year                                                                                   |                                                                                  |
|      |               | Add : 10% of the limit towards cost escalation / increase in scale of finance (10% of 51,900 i.e 5,200)   | ₹. 5,200 ₹. 57,100                                                               |
|      |               | Loan Limit for 5th year                                                                                   |                                                                                  |
|      |               | Add : 10% of the limit towards cost                                                                       | ₹. 5,700                                                                         |
|      |               | escalation / increase in scale of finance (10% of 57100 i.e 5700)                                         | ₹. 62,800                                                                        |
|      |               | Say ….(A)                                                                                                 | ₹. 63,000                                                                        |

:

<!-- RBI_PAGE:9 -->

## (ii) Term loan component :

1st Year : Cost of 1+1 Dairy Unit

: ₹. 40,000

3rd Year : Replacement of Pumpset :

: ₹. 30,000

Total term loan amount                                        ….(B)

:

₹. 70,000

Maximum Permissible Limit / :

Kisan Credit Card Limit (A) +(B)

₹. 1,33,000

:

Rs. 1.33 lakh

Note: Drawing Limit will be reduced every year based on repayment schedule of the term loan(s) availed and withdrawals will be allowed up to the drawing limit.

## B Other farmer cultivating multiple crops in a year

1. Assumptions :
2. 2.
3. Land Holding : 10 acres
3. Cropping Pattern :

Paddy - 5 acres (Scale of finance plus crop insurance per acre ₹.11,000) Followed by

Groundnut - 5 acres (Scale of finance plus crop insurance per acre ₹.10,000)

Sugarcane - 5 acres (Scale of finance plus crop insurance per acre ₹.22,000)

4. Investment / Allied Activities :

- i. Establishment  1+1 Dairy Unit in 1st Year (Unit cost : ₹.50,000)

- ii. Purchase of Tractor in 1st Year (Unit Cost : ₹.6,00,000)

## 2. Assessment of Card Limit

- (i) Crop loan Component

Cost of cultivation of 5 acres of Paddy, 5 Acres of Groundnut and 5 acres of Sugarcane :

₹ 2,15,000

Add : 10% towards post-harvest / household expense / consumption :

₹ 21,500

Add : 20% towards farm maintenance :

₹ 43,000

Total Crop Loan limit for 1st year

:

₹ 2,79,500

## Loan Limit for 2nd year

Add  :  10%  of  the  limit  towards  cost  escalation  /  increase  in scale of finance (10% of 2,79,500 i.e., 27,950) :

₹ 27,950

:

₹ 3,07,450

## Loan Limit for 3rd year

Add  :  10%  of  the  limit  towards  cost  escalation  /  increase  in scale of finance (10% of 3,07,450 i.e., 30,750) :

₹ 30,750

<!-- RBI_PAGE:10 -->

:

₹ 3,38,200

## Loan Limit for 4th year

Add  :  10%  of  the  limit  towards  cost  escalation  /  increase  in scale of finance (10% of 338200 i.e., 33,800) :

₹ 33,800

:

₹ 3,72,000

## Loan Limit for 5th year

Add  :  10%  of  the  limit  towards  cost  escalation  /  increase  in scale of finance (10% of 3,72,000 i.e., 37,200) :

₹ 37,200

:

₹ 4,09,200

Say…. (A)

:

₹ 4,09,000

## (ii) Term loan component :

1st Year : Cost of   1 +1  Dairy Unit

:

₹ 1,00,000

: Purchase of Tractor

:

₹ 6,00,000

Total term loan amount                                        ….(B)

₹ 7,00,000

Maximum Permissible Limit /

Kisan Credit Card Limit (A) +(B)

:

₹ 11,09,000

Drawing Limit will be reduced every year based on repayment schedule of the term loan(s) availed and withdrawals will be allowed up to the drawing limit.

<!-- RBI_PAGE:11 -->

## Illustration II

## Assessment of KCC LIMIT

## 1. Marginal farmer cultivating single crop in a year

1. Assumptions :
1. Land holding : 1 acre
2. Crops grown : Paddy (Scale of finance plus crop insurance per acre : ₹ 11,000)
3. There is no change in Cropping Pattern for 5 years
4. Allied Activities to be financed - One Non-Descript Milch Animal (Unit Cost Rs : 15,000)

## 2. Assessment of Card Limit :

- (i) Crop loan Component

(Cost of cultivation for 1 acre of Paddy)

: ₹ 11,000

Add  : 10%  towards post-harvest / household expense / consumption

: ₹ 1,100

Add : 20% towards farm maintenance

: ₹ 2,200

Total Crop Loan limit for 1st year                        ….(A1) :

₹ 14,300

- (ii) Term Loan Component

Cost of One Milch Animal

….(B)

:

₹ 15,000

1st Year Composite KCC Limit :                    (A1) + (B)

: ₹ 29,300

2nd Year :

## Crop loan component :

A1 plus 10% of crop loan limit (A1) towards cost escalation / increase in scale of finance [14,300+(10% of 14300 = 1430)]

….(A2)

:

₹ 15,730

2nd Year Composite KCC Limit : A2+B (15730 + 15000) :

₹ 30,730

3rd Year :

## Crop loan component :

A2 plus 10% of crop loan limit (A2) towards cost escalation / increase in scale of finance [15,730+(10% of 15730 = 1570)]

….(A3) :

₹ 17,300

3rd Year Composite KCC Limit : A3+B (17,300 + 15,000) :

₹ 32,300

4th Year :

## Crop loan component :

A3 plus  10%  of  crop  loan  limit  (A3)  towards  cost  escalation  / increase  in  scale  of  finance  [17,300+(10%  of  17300  =  1730)]

….(A4) :

₹ 19,030

4th Year Composite KCC Limit : A4+B (19,030 + 15,000)

₹ 34,030

5th Year :

Crop loan component :

<!-- RBI_PAGE:12 -->

A4 plus  10%  of  crop  loan  limit  (A4)  towards  cost  escalation  / increase in scale of finance [19,030+(10% of 19,03 0 = 1,900)]

….(A5)

:

₹ 20,930

5th Year Composite KCC Limit : A5+B

(20,930

+ 15,000)

₹ 35,930

Maximum Permissible Limit /

Composite KCC Limi                                                Say

:

₹ 36,000

Note: All the above costs estimated are illustrative in nature. The recommended scale of finance / unit costs may be taken into account while finalising the credit limit.

<!-- RBI_PAGE:13 -->

## Delivery Channels - Technical features

## 1 Issue of cards

The beneficiaries under the scheme will be issued with a Smart card / Debit card (Biometric smart  card  compatible  for  use  in  the  ATMs  /  Hand  held  Swipe  Machines  and  capable  of storing adequate information on farmers identity, assets, land holdings and credit profile etc). All KCC holders should be provided with any one or a combination of the following types of cards :

## 2 Type of Card :

A magnetic stripe card with PIN (Personal Identification Number)  with an ISO  IIN (International Standards Organization International Identification Number) to enable access to all banks ATMs and micro ATMs

In  cases  where  the  Banks  would  want  to  utilize  the  centralized  biometric  authentication infrastructure of the UIDAI (Aadhaar authentication), debit cards with magnetic stripe and PIN with ISO IIN with biometric authentication of UIDAI can be provided.

Debit  Cards  with  magnetic  stripe  and  only  biometric  authentication  can  also  be  provided depending on customer base of the bank. Till such time, UIDAI becomes widespread, if the banks want to get started without inter-operability using their existing centralized bio metric infrastructure, banks may do so.

Banks  may  choose  to  issue  EMV  (Europay,  MasterCard  and  VISA,  a  global  standard  for interoperation  of  integrated  circuit  cards)  and  RUPAY  compliant  chip  cards  with  magnetic stripe and pin with ISO IIN.

Further, the biometric authentication and smart cards may follow the common open standards prescribed by IDRBT and IBA. This will enable them to transact seamlessly with input dealers as  also  enable  them  to  have  the  sales  proceeds  credited  to  their  accounts  when  they  sell their output at mandies, procurement centers, etc.

## 3 Delivery Channels :

The following delivery  channels  shall  be  put  in  place  to  start  with  so  that  the  Kisan  Credit Card is used by the farmers to effectively transact their operations in their KCC account.

1. Withdrawal through ATMs / Micro ATM
2. Withdrawal through BCs using smart cards.
3. PoS machine through input dealers
4. Mobile Banking with IMPS capabilities / IVR
5. Aadhaar enabled Cards.

## 4. Mobile Banking / Other Channels :

Provide Mobile banking functionality for KCC Cards / Accounts as well along with Interbank Mobile  Payment  Service  (IMPS  of  NPCI)  capability  to  allow  customers  to  use  this  interoperable  IMPS  for  funds  transfer  between  banks  and  also  to  do  merchant  payment transactions as additional capability for purchases of agricultural inputs.

This mobile banking should ideally be on Unstructured Supplementary Data (USSD) platform for  wider  and  safer  acceptance.  However,  the  banks  can  also  offer  this  on  other  fully encrypted modes (application based or SMS based) to make use of the recent relaxation on transaction limits. Banks  can  also  offer unencrypted  mobile  banking  subject to  RBI regulations on transaction limits.

<!-- RBI_PAGE:14 -->

It is necessary that Mobile based transaction platforms enabling transactions in the KCC use easy to use SMS based solution with authentication thru' MPIN. Such solutions also need to be enabled on IVR in local language to ensure transparency and security. Such mobile based payment  systems  should  be  encouraged  by  all  the  banks  by  creating  awareness  and  by doing proper customer education.

With the existing infrastructure available with banks, all KCC holders should be provided with any one or a combination of the following types of cards :

* Debit  cards  (magnetic  stripe  card  with  PIN)  enabling  farmers  to  operate  the limit through all banks ATMs / Micro ATMs
* Debit Cards with magnetic stripe and biometric authentication.
* Smart  cards  for  doing  transactions  through  PoS  machines  held  by  Business Correspondents, input dealers, traders and Mandies.
* EMV compliant chip cards with magnetic stripe and pin with ISO IIN.

In addition, the banks having a call centre / Inter active Voice Response (IVR), may provide SMS  based  mobile  banking  with  a  call  back  facility  from  bank  for  mobile  PIN  (MPIN) verification through IVR, thus making a secured SMS based mobile banking facility available to card holders.

<!-- RBI_PAGE:15 -->

## List of Circulars consolidated in the Master Circular on 'Kisan Credit Card'

|   SL | Circular No.                          | Date       | Subject                                                                                    |
|------|---------------------------------------|------------|--------------------------------------------------------------------------------------------|
|    1 | RPCD.No.PLFS.BC.20/05.05.09/98-99     | 05.08.1998 | Kisan Credit Card                                                                          |
|    2 | RPCD.PLNFS.No.BC.99/05.05.09/99- 2000 | 06.06.2000 | Kisan Credit Card Scheme - Modification                                                    |
|    3 | RPCD.No.PLFS.BC./63/05.05.09/2000-01  | 03.03.2001 | Kisan Credit Cards                                                                         |
|    4 | RPCD.PLFS.BC.No./64/05.05.09/2001-02  | 28.02.2002 | Kisan Credit Card                                                                          |
|    5 | RPCD.Plan.BC.No 87/04.09.01/2003-04   | 18.05.2004 | Credit Flow to Agriculture - Agricultural Loans - Waiver of Margin / Security Requirements |
|    6 | RPCD.PLFS.BC.No.38/05.05.09/2004-05   | 04.10.2004 | Scheme to cover term loans for agriculture & llied activities under KCC                    |
|    7 | RPCD.PLFS.BC.No. 85/05.04.02/2009-10  | 18.06.2010 | Credit Flow to Agriculture - Agricultural Loans - Waiver of Margin / Security Requirements |
|    8 | RPCD.FSD.BC.No. 77/05.05.09/2011-12   | 11.05.2012 | Revised Kisan Credit Card Scheme                                                           |
|    9 | RPCD. FSD.BC.No.23/05.05.09/2012-13   | 07.08.2012 | Revised Kisan Credit Card Scheme                                                           |
|   10 | FIDD.FSD.BC.No. 8/05.05.010/2016-17   | 13.10.2016 | Revised Kisan Credit Card Scheme                                                           |

## APPENDIX