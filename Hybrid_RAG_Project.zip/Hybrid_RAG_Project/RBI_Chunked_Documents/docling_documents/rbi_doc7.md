<!-- RBI_PAGE:1 -->

<!-- image -->

## HR Rd RESERVE BANK OF INDIA.

www.rbi.org.in

## RBI/DBR/2015-16/18 Master Direction DBR.AML.BC.No.81/14.01.001/2015-16

## February 25, 2016

(Updated as on August 14, 2025)

(Updated as on June 12, 2025)

(Updated as on November 06, 2024)

(Updated as on January 04, 2024)

(Updated as on October 17, 2023)

(Updated as on May 04, 2023)

(Updated as on April 28, 2023)

(Updated as on May 10, 2021)

(Updated as on April 01, 2021)

(Updated as on March 23, 2021)

(Updated as on December 18, 2020)

(Updated as on April 20, 2020)

(Updated as on April 01, 2020)

(Updated as on January 09, 2020)

(Updated as on August 09, 2019)

(Updated as on May 29, 2019)

## Master Direction - Know Your Customer (KYC) Direction, 2016

## Contents

| INTRODUCTION .....................................................................................................................                   |   3 |
|------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| CHAPTER I .............................................................................................................................              |   4 |
| PRELIMINARY .................................................................................................................................        |   4 |
| CHAPTER II ..........................................................................................................................                |  15 |
| General ............................................................................................................................................ |  15 |
| CHAPTER III .........................................................................................................................                |  19 |
| Customer Acceptance Policy ....................................................................................................                      |  19 |
| CHAPTER IV .........................................................................................................................                 |  21 |
| Risk Management .........................................................................................................................            |  21 |
| Chapter V ...............................................................................................................................            |  22 |
| Customer Identification Procedure (CIP) ...............................................................................                              |  22 |
| Chapter VI ..............................................................................................................................            |  24 |
| Customer Due Diligence (CDD) Procedure ...........................................................................                                   |  24 |
| Part I - Customer Due Diligence (CDD) Procedure in case of Individuals .....................................                                         |  24 |
| Part II - CDD Measures for Sole Proprietary firms ........................................................................                           |  34 |
| Part III- CDD Measures for Legal Entities ......................................................................................                     |  35 |
| Part IV - Identification of Beneficial Owner ..................................................................................                      |  38 |
| Part V - On-going Due Diligence ....................................................................................................                 |  38 |

<!-- RBI_PAGE:2 -->

| Part VI - Enhanced and Simplified Due Diligence Procedure ........................................................                          |   45 |
|---------------------------------------------------------------------------------------------------------------------------------------------|------|
| Chapter VII ............................................................................................................................    |   49 |
| Record Management ...................................................................................................................       |   49 |
| Chapter VIII ...........................................................................................................................    |   51 |
| Reporting Requirements to Financial Intelligence Unit - India ........................................                                      |   51 |
| Chapter IX ..............................................................................................................................   |   53 |
| Requirements/obligations under International Agreements - ..........................................                                        |   53 |
| Communications from International Agencies ....................................................................                             |   53 |
| Chapter X ...............................................................................................................................   |   57 |
| Other Instructions ........................................................................................................................ |   57 |
| Chapter XI ..............................................................................................................................   |   70 |
| Repeal Provisions ........................................................................................................................  |   70 |
| Annex I ................................................................................................................................... |   71 |
| Annex II .................................................................................................................................. |   74 |
| Annex III ................................................................................................................................. |   84 |
| Annex IV ................................................................................................................................   |   94 |
| Appendix ...............................................................................................................................    |   97 |

<!-- RBI_PAGE:3 -->

## 1 INTRODUCTION

In order to prevent banks and other financial institutions from being used as a channel for Money Laundering (ML)/ Terrorist Financing (TF) and to ensure the integrity and stability of the financial system, efforts are continuously being made  both internationally  and  nationally,  by  way  of  prescribing  various  rules  and  regulations. Internationally, the Financial Action Task Force (FATF) which is an inter-governmental body established in 1989 by the Ministers of its member jurisdictions, sets standards and promotes effective implementation of legal, regulatory and operational measures for combating money laundering, terrorist financing and other related threats to the integrity  of  the  international  financial  system.  India,  being  a  member  of  FATF,  is committed  to  upholding  measures  to  protect  the  integrity  of  international  financial system.

In India, the Prevention of Money-Laundering Act, 2002 and the Prevention of MoneyLaundering (Maintenance of Records) Rules, 2005, form the legal framework on AntiMoney Laundering (AML) and Countering Financing of Terrorism (CFT). In terms of the provisions of the PML Act, 2002 and the PML Rules, 2005, as amended from time to time by the Government of India, Regulated Entities (REs) are required to follow certain customer identification procedures while undertaking a transaction either by establishing an account-based relationship or otherwise and monitor their transactions.

2. Accordingly, in exercise of the powers conferred by sections 35A of the Banking Regulation Act, 1949, the Banking Regulation Act (AACS), 1949, read with section 56 of the Act ibid, sections 45JA, 45K and 45L of the Reserve Bank of India Act, 1934, section 10 (2) read with section 18 of Payment and Settlement Systems Act 2007 (Act 51 of 2007), section 11(1) of the Foreign Exchange Management Act, 1999, Rule 9(14) of Prevention of Money-Laundering (Maintenance of Records) Rules, 2005 and all other laws enabling the Reserve Bank in this regard, the Reserve Bank of India being satisfied that it is necessary and expedient in the public interest to do so, hereby issues the Directions hereinafter specified.

[1   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:4 -->

## CHAPTER  I

## PRELIMINARY

## 1.  Short Title and Commencement.

- (a) These  Directions  shall  be  called  the  Reserve  Bank  of  India  (Know  Your Customer (KYC)) Directions, 2016.
- (b) These directions shall come into effect on the day they are placed on the official website of the Reserve Bank of India.
- (c)  2 The Frequently Asked Questions (FAQs) on KYC may be accessed at the following link Reserve Bank of India - Frequently Asked Questions (rbi.org.in).

## 2.  Applicability

- (a) 3 The  provisions  of  these  Directions  shall  apply  to  every  entity  regulated  by Reserve Bank of India, more specifically as defined in 3 (b) (xiv) below, except where specifically mentioned otherwise.
- (b)  These  directions  shall  also  apply  to  those  branches  and  majority  owned subsidiaries of the REs which are located abroad, to the extent they are not contradictory to the local laws in the host country, provided that:
- i. 4 where  applicable  laws  and  regulations  prohibit  implementation  of  these guidelines, the same shall be brought to the notice of the Reserve Bank of India.  RBI  may  advise  further  necessary  action  by  the  RE  including application of additional measures to be taken by the RE to manage the ML/TF risks.
- ii.  in  case  there  is  a  variance  in  KYC/AML  standards  prescribed  by  the Reserve  Bank  of  India and  the host country regulators, branches/ subsidiaries of REs are required to adopt the more stringent regulation of the two.
- iii.  branches/ subsidiaries of foreign incorporated banks may adopt the more stringent  regulation  of  the  two  i.e.,  standards  prescribed  by  the  Reserve Bank of India and their home country regulators.

Provided  that  this  rule  shall  not  apply  to  'small  accounts'  referred  to  in paragraph 23 of Chapter VI.

## 3.  Definitions

[2 Amended vide circular DOR.AML.REC. 46/14.01.001/2025-26 dated August 14, 2025.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12893&Mode=0)

[3  Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

[4  Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:5 -->

In these Directions, unless the context otherwise requires, the terms herein shall bear the meanings assigned to them below:

- (a)  Terms bearing meaning assigned in terms of Prevention of Money-Laundering Act, 2002 and the Prevention of Money-Laundering (Maintenance of Records) Rules, 2005:
- i. 5 'Aadhaar number' shall have the meaning assigned to it in clause (a) of section 2 of the Aadhaar (Targeted Delivery of Financial and Other Subsidies, Benefits and Services) Act, 2016 (18 of 2016);
- ii.  'Act' and 'Rules' means the Prevention of Money-Laundering Act, 2002 and the Prevention of Money-Laundering (Maintenance of Records) Rules, 2005, respectively and amendments thereto.
- iii. 6 'Authentication', in the context of Aadhaar authentication, means the process as defined under sub-section (c) of section 2 of the Aadhaar (Targeted Delivery of Financial and Other Subsidies, Benefits and Services) Act, 2016.
- iv.  Beneficial Owner (BO)
- a. Where  the customer  is  a  company ,  the  beneficial  owner  is  the  natural person(s),  who,  whether  acting  alone  or  together,  or  through  one  or  more juridical persons, has/have a controlling ownership interest or who exercise control through other means.

Explanation- For the purpose of this sub-clause-

1. 7 'Controlling ownership interest' means ownership of/entitlement to more than 10 percent of the shares or capital or profits of the company.
2.  'Control' shall include the right to appoint majority of the directors or to control  the  management or policy decisions including by virtue of their shareholding or management rights or shareholders agreements or voting agreements.
- b.  8 Where  the customer  is  a  partnership  firm ,  the  beneficial  owner  is  the natural person(s), who, whether acting alone or together, or through one or more  juridical  person,  has/have  ownership  of/entitlement  to  more  than  10 percent of capital or profits of the partnership or who exercises control through other means.

[5   Amended vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

[6   Amended vide circular DBR.AML.BC.No.39/14.01.001/2018-19 dated May 29, 2019.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11565&Mode=0)

[7   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[8   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:6 -->

Explanation -For the purpose of this sub-clause, 'control' shall include the right to control the management or policy decision.

- c. Where  the customer  is  an  unincorporated  association  or  body  of individuals , the beneficial owner is the natural person(s), who, whether acting alone or together, or through one or more juridical person, has/have ownership of/entitlement to more than 15 percent of the property or capital or profits of the unincorporated association or body of individuals.

Explanation: Term 'body of individuals' includes societies. Where no natural person  is  identified  under  (a),  (b)  or  (c)  above,  the  beneficial  owner  is  the relevant natural person who holds the position of senior managing official.

- d.  9 Where the customer is a trust , the identification of beneficial owner(s) shall include identification of the author of the trust, the trustee, the beneficiaries with  10  percent  or  more  interest  in  the  trust  and  any  other  natural  person exercising ultimate effective control over the trust through a chain of control or ownership.
- v. 10 'Certified Copy' - Obtaining a certified copy by the RE shall mean comparing the  copy  of  the  proof  of  possession  of  Aadhaar  number  where  offline verification cannot be carried out or officially valid document so produced by the  customer  with  the  original  and  recording  the  same  on  the  copy  by  the authorised officer of the RE as per the provisions contained in the Act.
3. Provided that in case of Non-Resident Indians (NRIs) and Persons of Indian Origin  (PIOs),  as  defined  in  Foreign  Exchange  Management  (Deposit) Regulations,  2016  {FEMA  5(R)},  alternatively,  the  original  certified  copy,

certified by any one of the following, may be obtained:

- authorised officials of overseas branches of Scheduled Commercial Banks registered in India,
- branches of overseas banks with whom Indian banks have relationships,
- Notary Public abroad,
- Court Magistrate,
- Judge,
- Indian Embassy/Consulate General in the country where the non-resident customer resides.

[9   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[10   Amended vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

<!-- RBI_PAGE:7 -->

- vi.  'Central KYC Records Registry' (CKYCR) means an entity defined under Rule 2(1) of the Rules, to receive, store, safeguard and retrieve the KYC records in digital form of a customer.
- vii.  'Designated Director" means a person designated by the RE to ensure overall compliance with the obligations imposed under chapter IV of the PML Act and the Rules and shall include:
- a.  the  Managing  Director  or  a  whole-time  Director,  duly  authorized  by  the Board of Directors, if the RE is a company,
- b.  the Managing Partner, if the RE is a partnership firm,
- c.  the Proprietor, if the RE is a proprietorship concern,
- d.  the Managing Trustee, if the RE is a trust,
- e.  a person or individual, as the case may be, who controls and manages the affairs of the RE, if the RE is an unincorporated association or a body of individuals, and
- f. a  person  who  holds  the  position  of  senior  management  or  equivalent designated as a 'Designated Director' in respect of Cooperative Banks and Regional Rural Banks.

Explanation - For the purpose of this clause, the terms "Managing Director" and "Whole-time  Director"  shall  have  the  meaning  assigned  to  them  in  the Companies Act, 2013.

- viii. 11 'Digital KYC' means the capturing live photo of the customer and officially valid document or the proof of possession of Aadhaar, where offline verification cannot be carried out, along with the latitude and longitude of the location where such live photo is being taken by an authorised officer of the RE as per the provisions contained in the Act.
- ix. 12 'Digital Signature' shall have the same meaning as assigned to it in clause (p) of sub-section (1) of section (2) of the Information Technology Act, 2000 (21 of 2000).
- x. 13 'Equivalent  e-document'  means  an  electronic  equivalent  of  a  document, issued by the issuing authority of such document with its valid digital signature including documents issued to the digital locker account of the customer as per  rule  9  of  the  Information  Technology  (Preservation  and  Retention  of Information by Intermediaries Providing Digital Locker Facilities) Rules, 2016.

[11   Inserted vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

[12   Inserted vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

[13   Inserted vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

<!-- RBI_PAGE:8 -->

- xi. 14 'Group' - The term 'group" shall have the same meaning assigned to it in clause (e) of sub-section (9) of section 286 of the Income-tax Act,1961 (43 of 1961).
- xii. 15 'Know  Your  Client  (KYC)  Identifier'  means  the  unique  number  or  code assigned to a customer by the Central KYC Records Registry.
- xiii. 16 'Non-profit organisations' (NPO) means any entity or organisation, constituted for religious or charitable purposes referred to in clause (15) of section 2 of the Income-tax Act, 1961 (43 of 1961), that is registered as a trust or a society under the Societies Registration Act, 1860 or any similar State legislation or a company registered under section 8 of the Companies Act, 2013 (18 of 2013).
- xiv.  'Officially  Valid  Document'  (OVD)  means  the  passport,  the  driving  licence, 17 proof of possession of Aadhaar number, the Voter's Identity Card issued by the Election Commission of India, job card issued by NREGA duly signed by an officer of the State Government and letter issued by the National Population Register containing details of name and address. Provided that,
- a.  where the customer submits his proof of possession of Aadhaar number as an OVD, he may submit it in such form as are issued by the Unique Identification Authority of India.
- b. 18 where  the  OVD  furnished  by  the  customer  does  not  have  updated address, the following documents or the equivalent e-documents thereof shall be deemed to be OVDs for the limited purpose of proof of address:-
- i.  utility bill which is not more than two months old of any service provider (electricity, telephone, post-paid mobile phone, piped gas, water bill);
- ii.  property or Municipal tax receipt;
- iii.  pension  or  family  pension  payment  orders  (PPOs)  issued  to  retired employees by Government Departments or Public Sector Undertakings, if they contain the address;
- iv.  letter  of  allotment  of  accommodation  from  employer  issued  by  State Government or Central Government Departments, statutory or regulatory  bodies,  public  sector  undertakings,  scheduled  commercial

[14   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[15   Inserted vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

[16   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[17   Inserted vide circular DBR.AML.BC.No.39/14.01.001/2018-19 dated May 29, 2019.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11565&Mode=0)

[18   Amended vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

<!-- RBI_PAGE:9 -->

banks, financial institutions and listed companies and leave and licence agreements with such employers allotting official accommodation;

- c.  the customer shall submit OVD with current address within a period of three months of submitting the documents specified at 'b' above
- d.  where the OVD presented by a foreign national does not contain the details of  address,  in  such  case  the  documents  issued  by  the  Government departments  of  foreign  jurisdictions  and  letter  issued  by  the  Foreign Embassy or Mission in India shall be accepted as proof of address.

Explanation: For the purpose of this clause, a document shall be deemed to be an  OVD  even  if  there  is  a  change  in  the  name  subsequent  to  its  issuance provided  it  is  supported  by  a  marriage  certificate  issued  by  the  State Government or Gazette notification, indicating such a change of name.

- xv. 19 'Offline verification' shall have the same meaning as assigned to it in clause (pa)  of  section  2  of  the  Aadhaar  (Targeted  Delivery  of  Financial  and  Other Subsidies, Benefits and Services) Act, 2016 (18 of 2016).

xvi.  'Person' has the same meaning assigned in the Act and includes:

- a.  an individual,
- b.  a Hindu undivided family,
- c.  a company,
- d.  a firm,
- e.  an association of persons or a body of individuals, whether incorporated or not,
- f. every artificial juridical person, not falling within any one of the above persons  (a to e), and
- g.  any agency, office or branch owned or controlled by any of the above persons  (a to f).
- xvii. 20 Deleted.
- xviii. 21 'Principal Officer' means an officer at the management level nominated by the RE, responsible for furnishing information as per rule 8 of the Rules.
- xix.  'Suspicious transaction' means a 'transaction' as defined below, including an attempted transaction, whether or not made in cash, which, to a person acting in good faith:

[19   Amended vide DBR.AML.BC.No.39/14.01.001/2018-19 dated May 29, 2019.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11565&Mode=0)

[20   Deleted vide circular DOR.AML.REC.66/14.01.001/2023-24 dated January 04, 2024.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12593&Mode=0)

[21   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:10 -->

- a. gives  rise  to  a  reasonable  ground  of  suspicion  that  it  may  involve proceeds of an offence specified in the Schedule to the Act, regardless of the value involved; or
- b.  appears to be made  in circumstances of unusual or unjustified complexity; or
- c. appears to not have economic rationale or bona-fide purpose; or
- d. gives  rise  to  a  reasonable  ground  of  suspicion  that  it  may  involve financing of the activities relating to terrorism.

Explanation:  Transaction  involving  financing  of  the  activities  relating  to terrorism includes transaction involving funds suspected to be linked or related to,  or  to  be  used  for  terrorism,  terrorist  acts  or  by  a  terrorist,  terrorist organization or those who finance or are attempting to finance terrorism.

- xx. 22 A 'Small Account' means a savings account which is opened in terms of subrule (5) of rule 9 of the PML Rules, 2005. Details of the operation of a small account  and  controls  to  be  exercised  for  such  account  are  specified  in paragraph 23.
- xxi. 'Transaction' means a purchase, sale, loan, pledge, gift, transfer, delivery or the arrangement thereof and includes:
- a.  opening of an account;
- b.  deposit, withdrawal, exchange or transfer of funds in whatever currency, whether in cash or by cheque, payment order or other instruments or by electronic or other non-physical means;
- c. the use of a safety deposit box or any other form of safe deposit;
- d. entering into any fiduciary relationship;
- e.  any payment made or received, in whole or in part, for any contractual or other legal obligation; or
- f. establishing or creating a legal person or legal arrangement.
9. (b)  Terms bearing meaning assigned in this Directions, unless the context otherwise requires, shall bear the meanings assigned to them below:
- i. 'Common  Reporting  Standards'  (CRS)  means  reporting  standards  set  for implementation  of  multilateral  agreement  signed  to  automatically  exchange information  based  on  Article  6  of  the Convention  on  Mutual  Administrative Assistance in Tax Matters.

[22   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:11 -->

- ii. 23 Correspondent Banking: Correspondent banking is the provision of banking services  by  one  bank  (the  'correspondent  bank')  to  another  bank  (the 'respondent bank'). Respondent banks may be provided with a wide range of services,  including  cash  management  (e.g.,  interest-bearing  accounts  in  a variety of currencies), international wire transfers, cheque clearing, payablethrough accounts and foreign exchange services.
- iii. 'Customer'  means  a  person  who  is  engaged  in  a  financial  transaction  or activity with a Regulated Entity (RE) and includes a person on whose behalf the person who is engaged in the transaction or activity, is acting.
- iv.  'Walk-in Customer' means a person who does not have an account-based relationship with the RE, but undertakes transactions with the RE.
- v. 24 'Customer  Due  Diligence  (CDD)'  means  identifying  and  verifying  the customer and the beneficial owner using reliable and independent sources of identification.

Explanation - The CDD, at the time of commencement of an account-based relationship or while carrying out occasional transaction of an amount equal to or exceeding rupees fifty thousand, whether conducted as a single transaction or  several  transactions  that  appear  to  be  connected,  or  any  international money transfer operations,  shall include:

- (a)  Identification of the customer, verification of their identity using reliable and independent sources of identification, obtaining information on the purpose and intended nature of the business relationship, where applicable
- (b)  Taking reasonable steps to understand the nature of the customer's business, and its ownership and control;
- (c)  Determining whether a customer is acting on behalf of a beneficial owner, and identifying the beneficial owner and taking all steps to verify the identity of the beneficial owner, using reliable and independent sources of identification.
- vi.  'Customer identification' means undertaking the process of CDD.
- vii.  'FATCA' means Foreign Account Tax Compliance Act of the United States of America (USA) which, inter alia, requires foreign financial institutions to report about financial accounts held by U.S. taxpayers or foreign entities in which U.S. taxpayers hold a substantial ownership interest.

[23   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[24  Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:12 -->

- viii.  'IGA' means Inter Governmental Agreement between the Governments of India and the USA to improve international tax compliance and to implement FATCA of the USA.
- ix. 'KYC  Templates'  means  templates  prepared  to  facilitate  collating  and reporting the KYC data to the CKYCR, for individuals and legal entities.
- x. 'Non-face-to-face  customers'  means  customers  who  open  accounts  without visiting the branch/offices of the REs or meeting the officials of REs.
- xi. 25 'On-going  Due  Diligence'  means  regular  monitoring  of  transactions  in accounts to ensure that those are consistent with RE's knowledge about the customers, customers' business and risk profile, the source of funds / wealth.
- xii. 26 Payable-through accounts: The term payable-through accounts refers to correspondent  accounts  that  are  used  directly  by  third  parties  to  transact business on their own behalf.
- xiii.  'Periodic Updation' means steps taken to ensure that documents, data or information collected under the CDD process is kept up-to-date and relevant by undertaking reviews of existing records at periodicity prescribed by the Reserve Bank.
- xiv. 27 'Regulated Entities' (REs) means
- a.  all  Scheduled  Commercial  Banks  (SCBs)/  Regional  Rural  Banks (RRBs)/ Local Area Banks (LABs)/ All Primary (Urban) Co-operative Banks (UCBs) /State and Central Co-operative Banks (StCBs / CCBs) and  any  other  entity  which  has  been  licenced  under  section  22  of Banking Regulation Act, 1949, which as a group shall be referred as 'banks'
- b.  All India Financial Institutions (AIFIs)
- c.  All  Non-Banking  Finance  Companies  (NBFCs),  Miscellaneous  NonBanking Companies (MNBCs) and Residuary Non-Banking Companies (RNBCs)
- d.  Asset Reconstruction Companies (ARCs)
- e.  All Payment System Providers (PSPs)/ System Participants (SPs) and Prepaid Payment Instrument Issuers (PPI Issuers)
- f. All authorised persons (APs) including those who are agents of Money Transfer Service Scheme (MTSS), regulated by the Regulator.

[25   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

[26   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[27   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:13 -->

- xv. 28 Shell Bank' means a bank that has no physical presence in the country in which it is incorporated and licensed, and which is unaffiliated with a regulated financial group that is subject to effective consolidated supervision. Physical presence means meaningful mind and management located within a country. The existence simply of a local agent or low-level staff does not constitute physical presence.
- xvi. 29 'Video based Customer Identification Process (V-CIP)': an alternate method of customer identification with facial recognition and customer due diligence by an authorised official of the RE by undertaking seamless, secure, live, informedconsent based audio-visual interaction with the customer to obtain identification information  required  for  CDD  purpose,  and  to  ascertain  the  veracity  of  the information  furnished  by  the  customer  through  independent  verification  and maintaining audit trail  of  the  process.  Such  processes  complying  with prescribed standards and procedures shall be treated on par with face-to-face CIP for the purpose of this Master Direction.
- xvii. 30 'Wire transfer' related definitions:
- a.  Batch transfer: Batch transfer is a transfer comprised of a number of individual  wire  transfers  that  are  being  sent  to  the  same  financial institutions but may/may not be ultimately intended for different persons.
- b.  Beneficiary:  Beneficiary  refers  to  a  natural  or  legal  person  or  legal arrangement who / which is identified by the originator as the receiver of the requested wire transfer.
- c.  Beneficiary RE: It refers to a financial institution, regulated by the RBI, which receives the wire transfer from the ordering financial institution directly or through an intermediary RE and makes the funds available to the beneficiary.
- d.  Cover Payment: Cover Payment refers to a wire transfer that combines a payment message sent directly by the ordering financial institution to the  beneficiary  financial  institution  with  the  routing  of  the  funding instruction  (the  cover)  from  the  ordering  financial  institution  to  the beneficiary financial institution through  one  or  more  intermediary financial institutions.

[28   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[29   Amended vide circular DOR.AML.REC.No.15/14.01.001/2021-22 dated May 10, 2021.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12089&Mode=0)

[30   Amended vide circular DOR.AML.REC.13/14.01.001/2023-24 dated May 4, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12498&Mode=0)

<!-- RBI_PAGE:14 -->

- e.  Cross-border wire transfer: Cross-border wire transfer refers to any wire transfer where the ordering financial institution and beneficiary financial institution are located in different countries. This term also refers to any chain of wire transfer in which at least one of the financial institutions involved is located in a different country.
- f. Domestic wire transfer: Domestic wire transfer refers to any wire transfer where the ordering financial institution and beneficiary financial institution are located in India. This term, therefore, refers to any chain of wire transfer that takes place entirely within the borders of India, even though  the  system  used  to  transfer  the  payment  message  may  be located in another country.
- g.  Financial Institution: In the context of wire-transfer instructions, the term 'Financial Institution' shall have the same meaning as has been ascribed to it in the FATF Recommendations, as revised from time to time.
- h.  Intermediary RE: Intermediary RE refers to a financial institution or any other entity, regulated by the RBI which handles an intermediary element of the wire transfer, in a serial or cover payment chain and that receives and transmits a wire transfer on behalf of the ordering financial institution and the beneficiary financial institution, or another intermediary financial institution.
- i. Ordering RE : Ordering RE refers to the financial institution, regulated by the RBI, which initiates the wire transfer and transfers the funds upon receiving the request for a wire transfer on behalf of the originator.
- j. Originator: Originator refers to the account holder who allows the wire transfer from that account, or where there is no account, the natural or legal person that places the order with the ordering financial institution to perform the wire transfer.
- k.  Serial  Payment: Serial  Payment refers to a direct sequential chain of payment where the wire transfer and accompanying payment message travel together from the ordering financial institution to the beneficiary financial institution directly or through one or more intermediary financial institutions (e.g., correspondent banks).
- l. Straight-through Processing: Straight-through processing refers to payment transactions that are conducted electronically without the need for manual intervention.

<!-- RBI_PAGE:15 -->

- m. Unique  transaction  reference  number:  Unique  transaction  reference number  refers  to  a  combination  of  letters,  numbers  or  symbols, determined  by  the  payment  service  provider,  in  accordance  with  the protocols of the payment and settlement system or messaging system used for the wire transfer.
- n.  Wire  transfer:  Wire  transfer  refers  to  any  transaction  carried  out  on behalf of an originator through a financial institution by electronic means with a view to making an amount of funds available to a beneficiary at a beneficiary financial institution, irrespective of whether the originator and the beneficiary are the same person.
3. (c)  All other expressions unless defined herein shall have the same meaning as have been assigned to them under the Banking Regulation Act, 1949, the Reserve Bank of India Act, 1935, the Prevention of Money Laundering Act, 2002, the Prevention of  Money  Laundering  (Maintenance  of  Records)  Rules,  2005,  the 31 Aadhaar (Targeted Delivery of Financial and Other Subsidies, Benefits and Services) Act, 2016 and regulations made thereunder, any statutory modification or re-enactment thereto or as used in commercial parlance, as the case may be.

## CHAPTER  II

## General

4. (a) There shall be a Know Your Customer (KYC) policy duly approved by the Board of  Directors  of  REs  or  any  committee  of  the  Board  to  which  power  has  been delegated.

32 (b) In terms of PML Rules, groups are required to implement group-wide policies for the purpose of discharging obligations under the provisions of Chapter IV of the PML Act, 2002. (15 of 2003). Accordingly, every RE which is part of a group, shall  implement  group-wide  programmes  against  money  laundering  and  terror financing, including group-wide policies for sharing information required for the purposes of  client  due  diligence  and  money  laundering  and  terror  finance  risk management and such programmes shall include adequate safeguards on the confidentiality and use of information exchanged, including safeguards to prevent tipping-off.

[31   Inserted vide circular DBR.AML.BC.No.39/14.01.001/2018-19 dated May 29, 2019.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11565&Mode=0)

[32   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:16 -->

33 (c) REs' policy framework should seek to ensure compliance with PML Act/Rules, including regulatory instructions in this regard and should provide a bulwark against threats arising from money laundering, terrorist financing, proliferation financing and  other  related  risks.  While  ensuring  compliance  of  the  legal/regulatory requirements  as  above,  REs  may  also  consider  adoption  of  best  international practices taking into account the FATF standards and FATF guidance notes, for managing risks better.

5. The KYC policy shall include following four key elements:
2. (a) Customer Acceptance Policy;
3. (b) Risk Management;
4. (c) Customer Identification Procedures (CIP); and
5. (d) Monitoring of Transactions

## 34 5A. Money Laundering and Terrorist Financing Risk Assessment by REs:

- (a)  REs shall carry out 'Money Laundering (ML) and Terrorist Financing (TF) Risk Assessment'  exercise  periodically  to  identify,  assess  and  take  effective measures to mitigate its money laundering and terrorist financing risk for clients, countries  or  geographic  areas,  products,  services,  transactions  or  delivery channels, etc.

The assessment process should consider all the relevant risk factors before determining  the  level  of  overall  risk  and  the  appropriate  level  and  type  of mitigation to be applied. While preparing the internal risk assessment, REs shall take  cognizance  of  the  overall  sector-specific  vulnerabilities,  if  any,  that  the regulator/supervisor may share with REs from time to time.

- (b)  The  risk  assessment  by  the  RE  shall  be  properly  documented  and  be proportionate  to  the  nature,  size,  geographical  presence,  complexity  of activities/structure, etc. of the RE. Further, the periodicity of risk assessment exercise shall be determined by the Board or any committee of the Board of the RE to which power in this regard has been delegated, in alignment with the outcome of the risk assessment exercise. However, it should be reviewed at least annually.
- (c)  The outcome of the exercise shall be put up to the Board or any committee of the Board to which power in this regard has been delegated, and should be available to competent authorities and self-regulating bodies.

[33   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[34   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:17 -->

35 5B. REs shall apply a Risk Based Approach (RBA) for mitigation and management of the risks (identified on their own or through national risk assessment) and should have  Board  approved  policies,  controls  and  procedures  in  this  regard.  REs  shall implement a CDD programme, having regard to the ML/TF risks identified and the size of  business.  Further,  REs  shall  monitor  the  implementation  of  the  controls  and enhance them if necessary.

## 6.  Designated Director :

- (a) A  'Designated  Director'  means  a  person  designated  by  the  RE  to  ensure overall compliance with the obligations imposed under Chapter IV of the PML Act and the Rules and shall be nominated by the Board.
- (b) The  name,  designation  and  address  of  the  Designated  Director  shall  be communicated to the FIU-IND.
- (c) 36 Further, the name,  designation, address and contact details of the Designated Director shall also be communicated to the RBI.
- (d) In  no  case,  the  Principal  Officer  shall  be  nominated  as  the  'Designated Director'.

## 7.  Principal Officer:

- (a) The Principal Officer shall be responsible for ensuring compliance, monitoring transactions,  and  sharing  and  reporting  information  as  required  under  the law/regulations.
- (b) The name,  designation  and  address  of  the  Principal Officer shall  be communicated to the FIU-IND.
- (c)  37 Further, the name, designation, address and contact details of the Principal Officer shall also be communicated to the RBI.

## 8.  Compliance of  KYC policy

(a) REs shall ensure compliance with KYC Policy through:

- (i) Specifying as to who constitute 'Senior Management' for the purpose of KYC compliance.
- (ii) Allocation  of  responsibility  for  effective  implementation  of  policies  and procedures.

[35   Inserted vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

[36   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[37   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:18 -->

- (iii)  Independent  evaluation  of  the  compliance  functions  of  REs'  policies  and procedures, including legal and regulatory requirements.
- (iv)  Concurrent/internal  audit  system  to  verify  the  compliance  with  KYC/AML policies and procedures.
- (v)  Submission of quarterly audit notes and compliance to the Audit Committee.
- (b) REs shall ensure that decision-making functions of determining compliance with KYC norms are not outsourced.

<!-- RBI_PAGE:19 -->

## CHAPTER  III

## Customer Acceptance Policy

9. REs shall frame a Customer Acceptance Policy.
10. Without prejudice to the generality of the aspect that Customer Acceptance Policy may contain, REs shall ensure that:
3. (a) No account is opened in anonymous or fictitious/benami name.
4. (b)  38 No account  is  opened  where  the  RE  is  unable  to  apply  appropriate  CDD measures, either due to non-cooperation of the customer or non-reliability of the documents/information furnished by the customer. The RE shall consider filing an STR, if necessary, when it is unable to comply with the relevant CDD measures in relation to the customer.
5. (c) No transaction or account-based relationship is undertaken without following the CDD procedure.
6. (d) The mandatory information to be sought for KYC purpose while opening an account and during the periodic updation, is specified.
7. (e)  39 Additional  information,  where  such  information  requirement  has  not  been specified  in  the  internal  KYC  Policy  of  the  RE,  is  obtained  with  the  explicit consent of the customer.
8. (f) 40 REs shall apply the CDD procedure at the UCIC level. Thus, if an existing KYC compliant customer of a RE desires to open another account or avail any other product or service from the same RE, there shall be no need for a fresh CDD exercise as far as identification of the customer is concerned.
9. (g) CDD Procedure is followed for all the joint account holders, while opening a joint account.
10. (h) Circumstances in which, a customer is permitted to act on behalf of another person/entity, is clearly spelt out.
11. (i) 41 Suitable system is put in place to ensure that the identity of the customer does not match with any person or entity, whose name appears in the sanctions lists indicated in Chapter IX of this MD.
12. (j) 42 Where Permanent Account Number (PAN) is obtained, the same shall be verified from the verification facility of the issuing authority.

[38   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

[39   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[40  Amended vide circular DOR.AML.REC. 49/14.01.001/2024-25 dated November 6, 2024.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12746&Mode=0)

[41   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[42   Inserted vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

<!-- RBI_PAGE:20 -->

- (k)  43 Where an equivalent e-document is obtained from the customer, RE shall verify the digital signature as per the provisions of the Information Technology Act, 2000 (21 of 2000).
- (l) 44 Where Goods and Services Tax (GST) details are available, the GST number shall be verified from the search/verification facility of the issuing authority.
11. Customer Acceptance Policy shall not result in denial of banking/financial facility to members of the general public, especially those, who are financially or socially disadvantaged,  45 including the Persons with Disabilities (PwDs). No application for onboarding or periodic updation of KYC shall be rejected without application of mind. Reason(s) of rejection shall be duly recorded by the officer concerned.

46 11A. Where RE forms a suspicion of money laundering or terrorist financing, and it reasonably believes that performing the CDD process will tip-off the customer, it shall not pursue the CDD process, and instead file an STR with FIU-IND.

[43   Inserted vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

[44   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[45 Amended vide circular DOR.AML.REC. 46/14.01.001/2025-26 dated August 14, 2025.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12893&Mode=0)

[46   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:21 -->

## CHAPTER IV

## Risk Management

12. For Risk Management, REs shall have a risk-based approach which includes the following.
2. (a) Customers shall be categorised as low, medium and high-risk category, based on the assessment and risk perception of the RE.
3. (b) 47 Broad  principles  may  be  laid  down  by  the  REs  for  risk-categorisation  of customers.
4. (c)  48 Risk  categorisation  shall  be  undertaken  based  on  parameters  such  as customer's  identity,  social/financial  status,  nature  of  business  activity,  and information about the customer's business and their location, geographical risk covering customers as well as transactions, type of products/services offered, delivery  channel  used  for  delivery  of  products/services,  types  of  transaction undertaken -cash, cheque/monetary instruments, wire transfers, forex transactions, etc. While considering customer's identity, the ability to confirm identity  documents  through  online  or  other  services  offered  by  issuing authorities may also be factored in.
5. (d) 49 The  risk  categorisation  of  a  customer  and  the  specific  reasons  for  such categorisation  shall  be  kept  confidential  and  shall  not  be  revealed  to  the customer to avoid tipping off the customer.

Provided  that various other information collected from  different categories of customers relating to the perceived risk, is non-intrusive and the same is specified in the KYC policy.

50 Explanation: FATF Public Statement, the reports and guidance notes on KYC/AML issued by the Indian Banks Association (IBA), and other agencies, etc., may also be used in risk assessment.

[47   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[48   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[49   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[50   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:22 -->

## Chapter V

## Customer Identification Procedure (CIP)

13. REs shall undertake identification of customers in the following cases:
2. (a) Commencement of an account-based relationship with the customer.
3. (b)  51 Carrying out any international money transfer operations for a person who is not an account holder of the RE.
4. (c) When  there  is  a  doubt  about  the  authenticity  or  adequacy  of  the  customer identification data it has obtained.
5. (d) Selling third party products as agents, selling their own products, payment of dues of credit cards/sale and reloading of prepaid/travel cards and any other product for more than rupees fifty thousand.
6. (e) Carrying  out  transactions  for  a  non-account-based  customer,  that  is  a  walk-in customer,  where  the  amount  involved  is  equal  to  or  exceeds  rupees  fifty thousand, whether conducted as a single transaction or several transactions that appear to be connected.
7. (f)  When a RE has reason to believe that a customer (account- based or walk-in) is intentionally  structuring  a  transaction  into  a  series  of  transactions  below  the threshold of rupees fifty thousand.
8. (g)  REs shall ensure that introduction is not to be sought while opening accounts.
14. For the purpose of verifying the identity of customers at the time of commencement  of  an  account-based relationship 52 or while carrying out occasional transaction of an amount equal to or exceeding rupees fifty thousand, whether conducted as a single transaction or several transactions that appear to be connected, or any international money transfer operations, REs, shall at their option,  rely  on  customer  due  diligence  done  by  a  third  party,  subject  to  the following conditions:
10. (a) 53 Records or the information of the customer due diligence carried out by the third party is obtained immediately from the third party or from the Central KYC Records Registry.
11. (b)   Adequate  steps  are  taken  by  REs  to  satisfy  themselves  that  copies  of identification data and other relevant documentation relating to the customer

[51   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[52  Amended vide circular DOR.AML.REC.46 /14.01.001/2025-26 dated August 14 ,2025.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12893&Mode=0)

[53  Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:23 -->

due diligence requirements shall be made available from the third party upon request without delay.

- (c)  The third party is regulated, supervised or monitored for, and has measures in  place  for,  compliance  with  customer  due  diligence  and  record-keeping requirements in line with the requirements and obligations under the PML Act.
- (d)  The third party shall not be based in a country or jurisdiction assessed as high risk.
- (e)  The  ultimate  responsibility  for  customer  due  diligence  and  undertaking enhanced due diligence measures, as applicable, will be with the RE.

<!-- RBI_PAGE:24 -->

## Chapter VI

## Customer Due Diligence (CDD) Procedure

## Part I - Customer Due Diligence (CDD) Procedure in case of Individuals

15. 54 Deleted
16. 55 For  undertaking  CDD, REs shall obtain the following from an individual while establishing an account-based relationship or while dealing with the individual who is a beneficial owner, authorised signatory or the power of attorney holder related to any legal entity:
3. (a) the Aadhaar number where,
4. (i)  he  is  desirous  of  receiving  any  benefit  or  subsidy  under  any  scheme notified under section 7 of the Aadhaar (Targeted Delivery of Financial and Other subsidies, Benefits and Services) Act, 2016 (18 of 2016); or
5. (ii) he decides to submit his Aadhaar number voluntarily to a bank or any RE notified under first proviso to sub-section (1) of section 11A of the PML Act; or
6. (aa) the proof of possession of Aadhaar number where offline verification can be carried out; or
7. (ab)  the  proof  of  possession  of  Aadhaar  number  where  offline  verification cannot  be  carried  out  or  any  OVD  or  the  equivalent  e-document  thereof containing the details of his identity and address; or
8. 56 (ac)  the  KYC  Identifier  with  an  explicit  consent  to  download  records  from CKYCR; and
9. (b) the Permanent Account Number or the equivalent e-document thereof or Form No. 60 as defined in Income-tax Rules, 1962; and
10. (c) such other documents including in respect of the nature of business and financial status of the customer, or the equivalent e-documents thereof as may be required by the RE:

Provided that where the customer has submitted, i) Aadhaar number under clause (a) above to a bank or to a RE notified under first proviso to sub-section (1) of section 11A of the PML Act, such bank or RE shall carry out authentication of the customer's Aadhaar number using e-KYC authentication facility provided by the Unique Identification Authority of India.

[54   Deleted vide circular DBR.AML.BC.No.39/14.01.001/2018-19 dated May 29, 2019.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11565&Mode=0)

[55   Amended vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

[56   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:25 -->

Further, in such a case, if customer wants to provide a current address, different from  the  address  as  per  the  identity  information  available  in  the  Central Identities Data Repository, he may give a self-declaration to that effect to the RE.

ii)  proof  of  possession  of  Aadhaar  under  clause  (aa)  above  where  offline verification can be carried out, the RE shall carry out offline verification.

iii)  an  equivalent  e-document  of  any  OVD,  the  RE  shall  verify  the  digital signature as per the provisions of the Information Technology Act, 2000 (21 of 2000) and any rules issues thereunder and take a live photo as specified under Annex I.

iv) any OVD or proof of possession of Aadhaar number under clause (ab) above where  offline  verification  cannot  be  carried  out,  the  RE  shall  carry  out verification through digital KYC as specified under Annex I.

57 v)  KYC  Identifier  under  clause  (ac)  above,  the  RE  shall  retrieve  the  KYC records online from the CKYCR in accordance with paragraph 56.

Provided  that  for  a  period  not  beyond  such  date  as  may  be  notified  by  the Government  for  a  class  of  REs,  instead  of  carrying  out  digital  KYC,  the  RE pertaining to such class may obtain a certified copy of the proof of possession of Aadhaar number or the OVD and a recent photograph where an equivalent edocument is not submitted.

Provided  further  that  in  case  e-KYC  authentication  cannot  be  performed  for  an individual desirous of receiving any benefit or subsidy under any scheme notified under  section  7  of  the  Aadhaar  (Targeted  Delivery  of  Financial  and  Other subsidies, Benefits and Services) Act, 2016 owing to injury, illness or infirmity on account of old age or otherwise, and similar causes, REs shall, apart from obtaining the  Aadhaar  number,  perform  identification  preferably  by  carrying  out  offline verification or alternatively by obtaining the certified copy of any other OVD or the equivalent e-document thereof from the customer. CDD done in this manner shall invariably be carried out by an official of the RE and such exception handling shall also be a part of the concurrent audit as mandated in paragraph 8. REs shall ensure to duly record the cases of exception handling in a centralised exception database.

[57   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:26 -->

The database shall contain the details of grounds of granting exception, customer details,  name  of  the  designated  official  authorising  the  exception  and  additional details, if any. The database shall be subjected to periodic internal audit/inspection

by the RE and shall be available for supervisory review.

Explanation  1:  RE  shall,  where  its  customer  submits  a  proof  of  possession  of Aadhaar Number containing Aadhaar Number, ensure that such customer redacts or blacks out  his  Aadhaar  number  through  appropriate  means  where  the authentication of Aadhaar number is not required as per proviso (i) above.

Explanation 2: Biometric based e-KYC authentication,  58 including  Aadhaar  Face Authentication  can  be  done  by  bank  official/business  correspondents/business facilitators.

Explanation 3: The use of Aadhaar, proof of possession of Aadhaar etc., shall be in accordance with the Aadhaar (Targeted Delivery of Financial and Other Subsidies Benefits and Services) Act, 2016 and the regulations made thereunder.

17. Accounts opened using Aadhaar OTP based e-KYC, in non-face-to-face mode, are subject to the following conditions:
- i. There must be a specific consent from the customer for authentication through OTP.
- ii. 59 As  a  risk-mitigating  measure  for  such  accounts,  REs  shall  ensure  that transaction alerts, OTP, etc., are sent only to the mobile number of the customer registered with Aadhaar. REs shall have a board approved policy delineating a robust process of due diligence for dealing with requests for change of mobile number in such accounts.
- iii. The aggregate balance of all the deposit accounts of the customer shall not exceed  rupees  one  lakh.  In  case,  the  balance  exceeds  the  threshold,  the account shall cease to be operational, till CDD as mentioned at (vi) below is complete.

[58 Amended vide circular DOR.AML.REC.46/14.01.001/2025-26 dated August 14, 2025.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12893&Mode=0)

[59 Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:27 -->

- iv. The aggregate of all credits in a financial year, in all the deposit accounts taken together, shall not exceed rupees two lakh.
- v. As  regards  borrowal  accounts,  only  term  loans  shall  be  sanctioned.  The aggregate  amount  of  term  loans  sanctioned  shall  not  exceed  rupees  sixty thousand in a year.
- vi. 60 Accounts, both deposit and borrowal, opened using OTP based e-KYC shall not be allowed for more than one year unless identification as per paragraph 16 or as per paragraph 18 (V-CIP) is carried out. If Aadhaar details are used under paragraph  18,  the  process  shall  be  followed  in  its  entirety  including  fresh Aadhaar OTP authentication.
- vii. If  the  CDD procedure as mentioned above is not completed within a year, in respect of deposit accounts, the same shall be closed immediately. In respect of borrowal accounts no further debits shall be allowed.
- viii. 61 A declaration shall be obtained from the customer to the effect that no other account has been opened nor will be opened using OTP based KYC in nonface-to-face mode with any other RE. Further, while uploading KYC information to CKYCR, REs shall clearly indicate that such accounts are opened using OTP based  e-KYC  and  other  REs  shall  not  open  accounts  based  on  the  KYC information of accounts opened with OTP based e-KYC procedure in non-faceto-face mode.
- ix. REs shall have strict monitoring procedures including systems to generate alerts in case of any non-compliance/violation, to ensure compliance with the above mentioned conditions.

## 18. 62 REs may undertake V-CIP to carry out:

- CDD in case of new customer on-boarding for individual customers, proprietor in case of proprietorship firm, authorised signatories and Beneficial Owners
- i) (BOs) in case of Legal Entity (LE) customers.

63 Provided that in case of CDD of a proprietorship firm, REs shall also obtain the equivalent e-document  of  the activity proofs with respect to the proprietorship firm, as mentioned in paragraph 28 and paragraph 29, apart from undertaking CDD of the proprietor.

[60   Amended vide circular DOR.AML.REC.No.15/14.01.001/2021-22 dated May 10, 2021.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12089&Mode=0)

[61   Amended vide circular DBR.AML.BC.No.39/14.01.001/2018-19 dated May 29, 2019.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11565&Mode=0)

[62   Amended vide circular DOR.AML.REC.No.15/14.01.001/2021-22 dated May 10, 2021.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12089&Mode=0)

[63   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:28 -->

- ii) Conversion  of  existing  accounts  opened  in  non-face  to  face  mode  using Aadhaar OTP based e-KYC authentication as per paragraph 17.
- iii) Updation/ Periodic updation of KYC for eligible customers.

REs opting to undertake V-CIP, shall adhere to the following minimum standards:

## (a) V-CIP Infrastructure

- i) The RE should have complied with the RBI guidelines on minimum baseline cyber security and resilience framework for banks, as updated from time to time  as  well  as  other  general  guidelines  on  IT  risks.  The  technology infrastructure should be housed in own premises of the RE and the V-CIP connection and interaction shall necessarily originate from its own secured network domain. Any technology related outsourcing for the process should be compliant with relevant RBI guidelines.  64 Where cloud deployment model is used, it shall be ensured that the ownership of data in such model rests with the RE only and all the data including video recording is transferred to the RE's  exclusively  owned  /  leased  server(s)  including  cloud  server,  if  any, immediately  after  the  V-CIP  process  is  completed  and  no  data  shall  be retained  by  the  cloud  service  provider  or  third-party  technology  provider assisting the V-CIP of the RE.
2. ii) The RE shall ensure end-to-end encryption of data between customer device and the hosting point of the V-CIP application, as per appropriate encryption standards.  The  customer  consent  should  be  recorded  in  an  auditable  and alteration proof manner.
3. iii) The  V-CIP  infrastructure  /  application  should  be  capable  of  preventing connection from IP addresses outside India or from spoofed IP addresses.
4. iv)  The video recordings should contain the live GPS co-ordinates (geo-tagging) of the customer undertaking the V-CIP and date-time stamp. The quality of the live video in the V-CIP shall be adequate to allow identification of the customer beyond doubt.
- v) The application shall have components with face liveness / spoof detection as well as face matching technology with high degree of accuracy, even though the  ultimate  responsibility  of  any  customer  identification  rests  with  the  RE.

[64   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:29 -->

Appropriate artificial intelligence (AI) technology can be used to ensure that the V-CIP is robust.

- vi)  Based on experience of detected / attempted / 'near-miss' cases of forged identity, the technology infrastructure including application software as well as work flows shall be regularly upgraded. Any detected case of forged identity through  V-CIP  shall  be  reported  as  a  cyber  event  under  extant  regulatory guidelines.
- vii) 65 The V-CIP infrastructure shall undergo necessary tests such as Vulnerability Assessment, Penetration testing and a Security Audit to ensure its robustness and end-to-end encryption capabilities. Any critical gap reported under this process shall be mitigated before rolling out its implementation. Such tests should  be  conducted  by  the  empanelled  auditors  of  Indian  Computer Emergency Response Team (CERT-In). Such tests should also be carried out periodically in conformance to internal / regulatory guidelines.
- viii) The  V-CIP  application  software  and  relevant  APIs / webservices shall also undergo appropriate testing of functional, performance, maintenance strength before being used in live environment. Only after closure of any critical gap found during such tests, the application should be rolled out. Such tests shall also be  carried out periodically in conformity with internal/ regulatory guidelines.

## (b) V-CIP Procedure

- i) Each RE shall formulate a clear work flow and standard operating procedure for V-CIP and ensure adherence to it. The V-CIP process shall be operated only by officials of the RE specially trained for this purpose. The official should be  capable  to  carry  out  liveness  check  and  detect  any  other  fraudulent manipulation or suspicious conduct of the customer and act upon it.  66 The liveness check shall not result in exclusion of person with special needs.
2. ii) 67 Disruption of any sort including pausing of video, reconnecting calls, etc., should not result in creation of multiple video files. If pause or disruption is not leading to the creation of multiple files, then there is no need to initiate a fresh session by the RE. However, in case of call drop / disconnection, fresh session shall be initiated.

[65   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[66 Amended vide circular DOR.AML.REC.46/14.01.001/2025-26 dated August 14, 2025.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12893&Mode=0)

[67   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:30 -->

- iii) The sequence and/or type of questions, including those indicating the liveness of the interaction, during video interactions shall be varied in order to establish that the interactions are real-time and not pre-recorded.
- iv) Any  prompting  observed  at  end  of  customer  shall  lead  to  rejection  of  the account opening process.
- v) The fact of the V-CIP customer being an existing or new customer, or if it relates to a case rejected earlier or if the name appearing in some negative list should be factored in at appropriate stage of work-flow.
- vi) The authorised official of the RE performing the V-CIP shall record audio-video as well as capture photograph of the customer present for identification and obtain the identification information using any one of the following:
- a)  OTP based Aadhaar e-KYC authentication
- b)  Offline Verification of Aadhaar for identification
- c)  KYC records downloaded from CKYCR, in accordance with paragraph 56, using the KYC identifier provided by the customer
- d)  Equivalent e-document of Officially Valid Documents (OVDs) including documents issued through DigiLocker

RE  shall  ensure  to  redact  or  blackout  the  Aadhaar  number  in  terms  of paragraph 16.

68 In case of offline verification of Aadhaar using XML file or Aadhaar Secure QR Code, it shall be ensured that the XML file or QR code generation date is not older than three working days from the date of carrying out V-CIP.

69 Further, in line with the prescribed period of three working days for usage of Aadhaar XML file / Aadhaar QR code, REs shall ensure that the video process of  the  V-CIP  is  undertaken  within  three  working  days  of  downloading  / obtaining the identification information through CKYCR / Aadhaar authentication / equivalent e-document, if in the rare cases, the entire process cannot be completed at one go or seamlessly. However, REs shall ensure that no incremental risk is added due to this.

[68   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[69   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:31 -->

- vii)  If  the  address  of  the  customer  is  different  from  that  indicated  in  the  OVD, suitable records of the current address shall be captured, as per the existing requirement. It shall be ensured that the economic and financial profile/information  submitted  by  the  customer  is  also  confirmed  from  the customer undertaking the V-CIP in a suitable manner.
- viii) RE shall capture a clear image of PAN card to be displayed by the customer during the process, except in cases where e-PAN is provided by the customer. The PAN details shall be verified from the database of the issuing authority including through DigiLocker.
- ix)  Use of printed copy of equivalent e-document including e-PAN is not valid for the V-CIP.
- x) The authorised official of the RE shall ensure that photograph of the customer in the Aadhaar/OVD and PAN/e-PAN matches with the customer undertaking the V-CIP and the identification details in Aadhaar/OVD and PAN/e-PAN shall match with the details provided by the customer.
- xi) Assisted  V-CIP  shall  be  permissible  when  banks  take  help  of  Business Correspondents (BCs) facilitating the process only at the customer end. Banks shall maintain the details of the BC assisting the customer, where services of BCs are utilized. The ultimate responsibility for customer due diligence will be with the bank.
- xii)  All accounts opened through V-CIP shall be made operational only after being subject  to  concurrent  audit,  to  ensure  the  integrity  of  process  and  its acceptability of the outcome.
- xiii) All matters not specified under the paragraph but required under other statutes such as the Information Technology (IT) Act shall be appropriately complied with by the RE.

## (c) V-CIP Records and Data Management

- i) The entire data and recordings of V-CIP shall be stored in a system / systems located in India. REs shall ensure that the video recording is stored in a safe and  secure  manner  and  bears  the  date  and  time  stamp  that  affords  easy historical  data  search.  The  extant  instructions  on  record  management,  as stipulated in this MD, shall also be applicable for V-CIP.
2. ii) The activity log along with the credentials of the official performing the V-CIP shall be preserved.

<!-- RBI_PAGE:32 -->

19. 70 Deleted
20. 71 Deleted
21. 72 Deleted
22. Deleted
23. 73 Notwithstanding  anything  contained  in  paragraph  16  and  as  an  alternative thereto, in case an individual who desires to open a bank account, banks shall open a 'Small Account', which entails the following limitations:
- i. the aggregate of all credits in a financial year does not exceed rupees one lakh;
- ii. the aggregate of all withdrawals and transfers in a month does not exceed rupees ten thousand; and
- iii. the balance at any point of time does not exceed rupees fifty thousand.

74 Provided, that this limit on balance shall not be considered while making deposits through Government grants, welfare benefits and payment against procurements.

Further, small accounts are subject to the following conditions:

- (a) The bank shall obtain a self-attested photograph from the customer.
- (b) The designated officer of the bank certifies under his signature that the person opening  the  account  has  affixed  his  signature  or  thumb  impression  in  his presence.

75 Provided that where the individual is a prisoner in a jail, the signature or thumb print shall be affixed in presence of the officer in-charge of the jail and the said officer shall certify the same under his signature and the account shall remain operational on annual submission of certificate of proof of address issued by the officer in-charge of the jail.

70 Deleted vide amendment dated April 20, 2018. Deleted portion read as: In case the person who proposes to open an account does not have an OVD as 'proof of address', such person shall provide OVD of the relative as provided at sub-section 77 of section 2 of the Companies Act, 2013, read with Rule 4 of Companies (Specification of definitions details) Rules, 2014, with whom the person is staying, as the 'proof of address' Explanation: A declaration from the relative that the said person is a relative and is staying with him/her shall be obtained.

71 Deleted vide amendment  dated April 20, 2018. Deleted portion read as: 'In cases where a customer categorised as 'low risk', expresses inability to complete the documentation requirements on account of any reason that the REs consider to be genuine, and where it is essential not to interrupt the normal conduct of business, REs shall, at their option, complete the verification of identity of the customer within a period of six months from the date of establishment of the relationship.'

72 Deleted vide amendment dated April 20, 2018. Deleted portion read as:  In respect of customers who are categorised as 'low risk' and are not able to produce any of the OVDs mentioned at paragraph 3(a)(vi) of Chapter I and where 'simplified procedure' is applied, REs shall, accept any one document from each of the two additional sets of documents listed under the two provisos of sub-Rule 2(1)(d). Explanation: During the periodic review, if the 'low risk' category customer for whom simplified procedure is applied, is re-categorised as 'moderate or ''high' risk category, then REs shall obtain one of the six OVDs listed at paragraph 3(a)(vi) of these Directions for proof of identity and proof of address immediately. In the event such a customer fails to submit such an OVD, REs shall initiate action as envisaged in paragraph 39 of these Directions .

[73   Amended vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

74  Inserted vide Gazette Notification G.S.R. 1038(E) regarding PML Third amendment Rules dated August 21, 2017.

75 Inserted vide Gazette Notification G.S.R. 381(E) dated May 28, 2019.

<!-- RBI_PAGE:33 -->

- (c) Such  accounts  are  opened  only  at  Core  Banking  Solution  (CBS)  linked branches or in a branch where it is possible to manually monitor and ensure that foreign remittances are not credited to the account.
- (d) Banks shall ensure that the stipulated monthly and annual limits on aggregate of transactions and balance requirements in such accounts are not breached, before a transaction is allowed to take place.
- (e) The  account  shall  remain  operational  initially  for  a  period  of  twelve  months which  can  be  extended  for  a  further  period  of  twelve  months,  provided  the account holder applies and furnishes evidence of having applied for any of the OVDs during the first twelve months of the opening of the said account.
- (f)  The entire relaxation provisions shall be reviewed after twenty-four months.
- (g)  76 Notwithstanding anything contained in clauses (e) and (f) above, the small account shall remain operational between April 1, 2020 and June 30, 2020 and such other periods as may be notified by the Central Government.
- (h)  77 The  account  shall  be  monitored  and  when  there  is  suspicion  of  money laundering or financing of terrorism activities or other high-risk scenarios, the identity of the customer shall be established as per paragraph 16 or paragraph 18.
- (i)  78 Foreign remittance shall not be allowed to be credited into the account unless the  identity  of  the  customer  is  fully  established  as  per  paragraph  16  or paragraph 18.
24. 79 Simplified  procedure  for  opening  accounts  by  Non-Banking  Finance Companies (NBFCs) : In case a person who desires to open an account is not able to produce documents, as specified in paragraph 16, NBFCs may at their discretion open accounts subject to the following conditions:
- (a) The NBFC shall obtain a self-attested photograph from the customer.
- (b) The designated officer of the NBFC certifies under his signature that the person opening  the  account  has  affixed  his  signature  or  thumb  impression  in  his presence.
- (c)  80 The account shall remain operational initially for a period of twelve months, within which CDD as per paragraph 16 or paragraph 18 shall be carried out.

[76   Inserted vide circular DOR.AML.BC.No.66/14.01.001/2019-20 dated April 20, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11873&Mode=0)

[77   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[78   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[79 Amended vide circular DBR.AML.BC.No.39/14.01.001/2018-19 dated May 29, 2019 .](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11565&Mode=0)

[80   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:34 -->

- (d) Balances  in  all  their  accounts  taken  together  shall  not  exceed  rupees  fifty thousand at any point of time.
- (e) The total credit in all the accounts taken together shall not exceed rupees one lakh in a year.
- (f)  The customer shall be made aware that no further transactions will be permitted until the full KYC procedure is completed in case Directions (d) and (e) above are breached by him.
- (g) The customer shall be notified when the balance reaches rupees forty thousand or the total credit in a year reaches rupees eighty thousand that appropriate documents for conducting the KYC must be submitted otherwise the operations in the account shall be stopped when the total balance in all the accounts taken together exceeds the limits prescribed in direction (d) and (e) above.
- (h)  81   The  account  shall  be  monitored  and  when  there  is  suspicion  of  ML/TF activities  or  other  high-risk  scenarios,  the  identity  of  the  customer  shall  be established as per paragraph 16 or paragraph 18.
25. 82 Deleted.
26. 83 KYC verification  once  done  by  one  branch/office  of  the  RE  shall  be  valid  for transfer of the account to any other branch/office of the same RE, provided full KYC verification has already been done for the concerned account and the same is not due for periodic updation.

## Part II - CDD Measures for Sole Proprietary firms

27. 84 For  opening  an  account  in  the  name  of  a  sole  proprietary  firm,  CDD  of  the individual (proprietor) shall be carried out.
28. 85 In addition to the above, any two of the following documents or the equivalent edocuments there of as a proof of business/ activity in the name of the proprietary firm shall also be obtained:
3. (a)  86 Registration  certificate  including  Udyam  Registration  Certificate  (URC) issued by the Government

[81   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

82 Deleted vide amendment dated April 20, 2018 and shifted to paragraph 10. Deleted/shifted portion read as: 'If an existing KYC compliant customer of a RE desires to open another account with the same RE, there shall be no need for a fresh CDD exercise.'

83   Amended vide Gazette Notification G.S.R. 538(E) regarding PML Second amendment Rules dated June 1, 2017. Deleted portion of paragraph 26 is as follows: 'and a self-declaration from the account holder about his/her current address is obtained in such cases.

[84   Amended vide circular DBR.AML.BC.No.39/14.01.001/2018-19 dated May 29, 2019.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11565&Mode=0)

[85   Amended vide circular DBR.AML.BC.No.39/14.01.001/2018-19 dated  May 29, 2019.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11565&Mode=0)

[86   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:35 -->

- (b) Certificate/licence  issued  by  the  municipal  authorities  under  Shop  and Establishment Act
- (c) Sales and income tax returns
- (d)  87 CST/VAT/ GST certificate
- (e) Certificate/registration document issued by Sales Tax/Service Tax/Professional Tax authorities
- (f)  IEC (Importer Exporter Code) issued to the proprietary concern by the office of DGFT or Licence/certificate of practice issued in the name of the proprietary concern by any professional body incorporated under a statute
- (g) Complete Income Tax Return (not just the acknowledgement) in the name of the sole proprietor where the firm's income is reflected, duly authenticated/acknowledged by the Income Tax authorities
- (h) Utility bills such as electricity, water, landline telephone bills, etc.
29. In  cases where the REs are satisfied that it is not possible to furnish two such documents, REs may, at their discretion, accept only one of those documents as proof of business/activity.

Provided REs  undertake  contact point verification and  collect such  other information and clarification as would be required to establish the existence of such firm, and shall confirm and satisfy itself that the business activity has been verified from the address of the proprietary concern.

## Part III- CDD Measures for Legal Entities

30. 88 For opening an account of a company , certified copies of each of the following documents or the equivalent e-documents thereof shall be obtained:
2. (a) Certificate of incorporation
3. (b) Memorandum and Articles of Association
4. (c)  89 Permanent Account Number of the company
5. (d) A resolution from the Board of Directors and power of attorney granted to its managers, officers or employees to transact on its behalf

[87   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[88   Amended vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

[89   Inserted vide circular DBR.AML.BC.No.39/14.01.001/2018-19 dated May 29, 2019.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11565&Mode=0)

<!-- RBI_PAGE:36 -->

- (e)  90 Documents, as specified in paragraph 16, relating to beneficial owner, the managers, officers or employees, as the case may be, holding an attorney to transact on the company's behalf
- (f) 91 the names of the relevant persons holding senior management position; and
- (g) 92 the registered office and the principal place of its business, if it is different.
31. 93 For opening an account of a partnership firm , the certified copies of each of the following documents or the equivalent e-documents thereof shall be obtained:
- (a) Registration certificate
- (b) Partnership deed
- (c)  94 Permanent Account Number of the partnership firm
- (d) 95 Documents, as specified  in  paragraph  16,  relating  to  beneficial  owner, managers, officers or employees, as the case may be, holding an attorney to transact on its behalf
- (e)  96 the names of all the partners and
- (f) 97 address of the registered office, and the principal place of its business, if it is different.
32. 98 For  opening  an  account  of  a  trust , certified  copies  of  each  of  the  following documents or the equivalent e-documents thereof shall be obtained:
- (a) Registration certificate
- (b) Trust deed
- (c)  99 Permanent Account Number or Form No.60 of the trust
- (d)  100 Documents, as specified in paragraph 16, relating to beneficial owner, managers, officers or employees, as the case may be, holding an attorney to transact on its behalf
- (e) 101 the  names  of  the  beneficiaries,  trustees,  settlor,  protector,  if  any  and authors of the trust

[90   Amended vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

[91  Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[92   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[93   Amended vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

[94   Inserted vide circular DBR.AML.BC.No.39/14.01.001/2018-19 dated May 29, 2019.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11565&Mode=0)

[95   Amended vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

[96   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[97   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[98   Amended vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

[99   Inserted vide circular DBR.AML.BC.No.39/14.01.001/2018-19 dated May 29, 2019.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11565&Mode=0)

[100   Amended vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

[101   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:37 -->

- (f) 102 the address of the registered office of the trust; and
- (g)  103 list  of trustees and documents, as specified in paragraph 16, for those discharging the role as trustee and authorised to transact on behalf of the trust.
- 33A. 104 For  opening  an  account  of  an  unincorporated  association  or  a  body  of individuals , certified copies of each of the following documents or the equivalent e-documents thereof shall be obtained:
- (a)  Resolution of the managing body of such association or body of individuals
- (b) 105 Permanent  Account  Number  or  Form  No.  60  of  the  unincorporated association or a body of individuals
- (c)  Power of attorney granted to transact on its behalf
- (d) 106 Documents, as specified in paragraph 16, relating to beneficial owner, managers, officers or employees, as the case may be, holding an attorney to transact on its behalf and
- (e)  Such information as may be required by the RE to collectively establish the legal existence of such an association or body of individuals.

Explanation: Unregistered trusts/partnership firms shall be included under the term 'unincorporated association'.

Explanation: Term 'body of individuals' includes societies.

- 33B. 107 For opening account of a customer who is a juridical person (not specifically covered in the earlier part) such as societies, universities and local bodies like village panchayats, etc., or who purports to act on behalf of such juridical person or individual or trust, certified copies of the following documents or the equivalent e-documents thereof shall be obtained and verified:
2. (a) Document showing name of the person authorised to act on behalf of the entity
3. (b) Documents, as specified in paragraph 16, of the person holding an attorney to transact on its behalf and
4. (c) Such  documents  as  may  be  required  by  the  RE  to  establish  the  legal existence of such an entity/juridical person.

[102   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[103   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[104   Amended vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

[105   Inserted vide circular DBR.AML.BC.No.39/14.01.001/2018-19 dated May 29, 2019.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11565&Mode=0)

[106   Amended vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

[107   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:38 -->

108 Provided that in case of a trust, the RE shall ensure that trustees disclose their status at the time of commencement of an account-based relationship or when  carrying  out  transactions  as  specified  in  clauses  (b),  (e)  and  (f)  of paragraph 13 of this MD.

## Part IV - Identification of Beneficial Owner

34. For  opening  an  account  of  a  Legal  Person  who  is  not  a  natural  person,  the beneficial owner(s) shall be identified and all reasonable steps in terms of subrule (3) of Rule 9 of the Rules to verify his/her identity shall be undertaken keeping in view the following:
2. (a) 109 Where the customer or the owner of the controlling interest is (i) an entity listed  on  a  stock  exchange  in  India,  or  (ii)  it  is  an  entity  resident  in jurisdictions  notified  by  the  Central  Government  and  listed  on  stock exchanges  in  such  jurisdictions,  or  (iii)  it  is  a  subsidiary  of  such  listed entities;  it  is  not  necessary  to  identify  and  verify  the  identity  of  any shareholder or beneficial owner of such entities.
3. (b) In cases of trust/nominee or fiduciary accounts whether the customer is acting  on  behalf  of  another  person  as  trustee/nominee  or  any  other intermediary  is  determined.  In  such  cases,  satisfactory  evidence  of  the identity of the intermediaries and of the persons on whose behalf they are acting, as also details of the nature of the trust or other arrangements in place shall be obtained.

## Part V - On-going Due Diligence

35. 110 REs shall undertake on-going due diligence of customers to ensure that their transactions are consistent with their knowledge about the customers, customers' business and risk profile, the source of funds / wealth.
36. Without prejudice to the generality of factors that call for close monitoring following types of transactions shall necessarily be monitored:
3. (a) Large and complex transactions including RTGS transactions, and those with unusual patterns, inconsistent with the normal and expected activity

[108  Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

[109   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[110   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:39 -->

of the customer, which have no apparent economic rationale or legitimate purpose.

- (b) Transactions which exceed  the thresholds prescribed for specific categories of accounts.
- (c) High account  turnover inconsistent with the size of the  balance maintained.
- (d) Deposit of third-party cheques, drafts, etc. in the existing and newly opened accounts followed by cash withdrawals for large amounts.

111 For ongoing due diligence, REs  may  consider adopting appropriate innovations  including  artificial  intelligence  and  machine  learning  (AI  &amp;  ML) technologies to support effective monitoring.

37. The extent of monitoring shall be aligned with the risk category of the customer.
2. (a) A system of periodic review of risk categorisation of accounts, with such periodicity being at least once in six months, and the need for applying enhanced due diligence measures shall be put in place.
3. (b) The transactions in accounts of marketing firms, especially accounts of Multi-level Marketing (MLM) Companies shall be closely monitored.

Explanation:  High  risk  accounts  have  to  be  subjected  to  more  intensified monitoring .

Explanation: Cases where a large number of cheque books are sought by the company and/or multiple small deposits (generally in cash) across the country in  one  bank  account  and/or  where  a  large  number  of  cheques  are  issued bearing similar amounts/dates, shall be immediately reported to Reserve Bank of India and other appropriate authorities such as FIU-IND.

## 38.  112 Updation / Periodic Updation of KYC

REs shall adopt a risk-based approach for periodic updation of KYC ensuring that the information or data collected under CDD is kept up-to-date and relevant, particularly where there is high risk. However, periodic updation shall be carried out at least once in every two years for high-risk customers, once in every eight years  for  medium  risk  customers  and  once  in  every  ten  years  for  low-risk customers from the date of opening of the account / last KYC updation. Policy in this  regard  shall  be  documented  as  part  of  REs'  internal  KYC  policy  duly approved by the Board of Directors of REs or any committee of the Board to which power has been delegated.

[111   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[112   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:40 -->

113 Notwithstanding  the  provisions  given  above,  in  respect  of  an  individual customer who is categorized as low risk, the RE shall allow all transactions and ensure the updation of KYC within one year of its falling due for KYC or upto June  30,  2026,  whichever  is  later.  The  RE  shall  subject  accounts  of  such customers  to  regular  monitoring.  This  shall  also  be  applicable  to  low-risk individual customers for whom periodic updation of KYC has already fallen due.

## a) Individuals:

- i. No  change  in  KYC  information: In  case  of  no  change  in  the  KYC information, a self-declaration from the customer in this regard shall be obtained through customer's email-id registered with the RE, customer's mobile number registered with the RE, ATMs, digital channels (such as online banking / internet banking, mobile application of RE), letter, etc.
- ii. Change in address: In case of a change only in the address details of the customer, a self-declaration of the new address shall be obtained from the  customer  through  customer's  email-id  registered with the  RE, customer's mobile number registered with the RE, ATMs, digital channels (such  as  online  banking  /  internet  banking,  mobile  application  of  RE), letter,  etc.,  and  the  declared  address  shall  be  verified  through  positive confirmation within two months, by means such as address verification letter, contact point verification, deliverables, etc.

114 Further,  REs,  at  their  option,  may  obtain  a  copy  of  OVD  or  deemed OVD, as defined in paragraph 3(a)(xiv), or the equivalent e-documents thereof,  as  defined  in  paragraph  3(a)(x),  for  the  purpose  of  proof  of address,  declared  by  the  customer  at  the  time  of 115 updation/  periodic updation.  Such  requirement,  however,  shall  be  clearly  specified  by  the REs in their internal KYC policy duly approved by the Board of Directors of REs or any committee of the Board to which power has been delegated.

[113 Amended vide circular DOR.AML.REC. 30/14.01.001/2025-26 dated June 12, 2025.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12866&Mode=0)

[114   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

[115   Inserted vide circular DOR.AML.REC. 49/14.01.001/2024-25 dated November 6, 2024.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12746&Mode=0)

<!-- RBI_PAGE:41 -->

## iia . 116 Use  of  Business  Correspondent  (BC)  by  banks  for  Updation/ Periodic Updation of KYC

Self-declaration  from  the  customer  in  case  of  no  change  in  KYC information or change only in the address details may be obtained through an authorized BC of the bank. The bank shall enable its BC systems for recording  these  self-declarations  and  supporting  documents  thereof  in electronic form in the bank's systems.

The  bank  shall obtain the self-declaration including the supporting documents, if required, in the electronic mode from the customer through the  BC,  after  successful  biometric  based  e-KYC  authentication.  Until  an option is made available in the electronic mode, such declaration may be submitted in physical form by the customer. The BC shall authenticate the self-declaration  and  supporting  documents  submitted  in  person  by  the customer, and promptly forward the same to the concerned bank branch. The BC shall provide the customer an acknowledgment of receipt of such declaration /submission of documents.

The  bank  shall  update  the  customer's  KYC  records  and  intimate  the customer once the records get updated in the system, as required under paragraph 38(c) of the Master Direction ibid . It is, however, reiterated that the ultimate responsibility for periodic updation of KYC remains with the bank concerned.

- iii. Accounts  of  customers,  who  were  minor  at  the  time  of  opening account,  on  their  becoming  major: In  case  of  customers  for  whom account was opened when they were minor, fresh photographs shall be obtained on their becoming a major and at that time it shall be ensured that CDD documents as per the current CDD standards are available with the  REs.  Wherever  required,  REs  may  carry  out  fresh  KYC  of  such customers i.e., customers for whom account was opened when they were minor, on their becoming a major.
- iv. 117 Aadhaar OTP based e-KYC in non-face to face mode may be used for 118 updation/ periodic updation. To clarify, conditions stipulated in

[116 Amended vide circular DOR.AML.REC. 30/14.01.001/2025-26 dated June 12, 2025.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12866&Mode=0)

[117   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[118  Inserted vide circular DOR.AML.REC.49/14.01.001/2024-25 dated November 6, 2024.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12746&Mode=0)

<!-- RBI_PAGE:42 -->

paragraph 17 are not applicable in case of updation / periodic updation of

KYC through Aadhaar OTP based e-KYC in non-face to face mode. Declaration of current address, if the current address is different from the address in Aadhaar, shall not require positive confirmation in this case. REs shall ensure that the mobile number for Aadhaar authentication is same as the one available with them in the customer's profile, in order to prevent any fraud.

## b) Customers other than individuals:

- i. No  change  in  KYC  information: In  case  of  no  change  in  the  KYC information of the LE customer, a self-declaration in this regard shall be obtained from the LE customer through its email id registered with the RE, ATMs, digital channels (such as online banking / internet banking, mobile application  of  RE),  letter  from  an  official  authorized  by  the  LE  in  this regard,  board  resolution,  etc.  Further,  REs  shall  ensure  during  this process that Beneficial Ownership (BO) information available with them is accurate and shall update the same, if required, to keep it as up-to-date as possible.
- ii. Change in KYC information: In case of change in KYC information, RE shall  undertake  the  KYC  process  equivalent  to  that  applicable  for  onboarding a new LE customer.
- c) 119 Additional measures: In addition to the above, REs shall ensure that,
- i. The KYC documents of the customer as per the current CDD standards are available with them. This is applicable even if there is no change in customer information but the documents available with the RE are not as per the current CDD standards. Further, in case the validity of the CDD documents  available  with  the  RE  has  expired  at  the  time  of  periodic updation of KYC, RE shall undertake the KYC process equivalent to that applicable for on-boarding a new customer.
- ii. Customer's  PAN  details,  if  available  with  the  RE,  is  verified  from  the database of the issuing authority at the time of periodic updation of KYC.
- iii. Acknowledgment  is  provided  to  the  customer  mentioning  the  date  of receipt  of  the  relevant  document(s),  including  self-declaration  from  the customer, for carrying out  120 updation/ periodic updation. Further, it shall

[119   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[120  Inserted vide circular DOR.AML.REC.49 /14.01.001/2024-25 dated November 6, 2024.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12746&Mode=0)

<!-- RBI_PAGE:43 -->

be ensured that the information / documents obtained from the customers at the time of  121 updation/ periodic updation of KYC are promptly updated in  the records / database of the REs and an intimation, mentioning the date of updation of KYC details, is provided to the customer.

- iv. In  order  to  ensure  customer  convenience,  REs  may  consider  making available  the  facility  of 122 updation/  periodic  updation  of  KYC  at  any branch, in terms of their internal KYC policy duly approved by the Board of Directors of REs or any committee of the Board to which power has been delegated.
- v. REs shall adopt a risk-based approach with respect to periodic updation of KYC. Any additional and exceptional measures, which otherwise are not mandated under the above instructions, adopted by the REs such as requirement  of  obtaining  recent  photograph,  requirement  of  physical presence of the customer, requirement of periodic updation of KYC only in  the  branch  of  the  RE  where account is maintained, a more frequent periodicity of KYC updation than the minimum specified periodicity etc., shall be clearly specified in the internal KYC policy duly approved by the Board of Directors of REs or any committee of the Board to which power has been delegated.
- d) 123 REs shall advise the customers that in order to comply with the PML Rules, in case of any update in the documents submitted by the customer at the time of establishment of business relationship/ account-based relationship and thereafter, as necessary; customers shall submit to the REs the update of such documents. This shall be done within 30 days of the update to the documents for the purpose of updating the records at REs' end.

## e) 124 Due Notices for Periodic Updation of KYC

The RE shall intimate its customers, in advance, to update their KYC.  Prior to the due date of periodic updation of KYC, the RE shall give at least three advance intimations, including at least one intimation by letter, at appropriate intervals to its customers through available communication options/ channels for complying with the requirement of periodic updation of KYC. Subsequent to the due date, the RE shall give at least three reminders, including at least one reminder by letter, at appropriate  intervals,  to  such  customers  who  have  still  not  complied  with  the requirements, despite advance intimations. The letter of intimation/ reminder may, inter alia ,  contain easy to understand instructions for updating KYC, escalation mechanism for seeking help, if required, and the consequences, if any, of failure to update their KYC in time. Issue of such advance intimation/ reminder shall be duly recorded in the RE's system against each customer for audit trail. The RE shall expeditiously implement the same but not later than January 01, 2026.

[121  Inserted vide circular DOR.AML.REC.49/14.01.001/2024-25 dated November 6, 2024.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12746&Mode=0)

[122  Inserted vide circular DOR.AML.REC.49/14.01.001/2024-25 dated November 6, 2024.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12746&Mode=0)

[123   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[124 Amended vide circular DOR.AML.REC. 30/14.01.001/2025-26 dated June 12, 2025.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12866&Mode=0)

<!-- RBI_PAGE:44 -->

39. 125 In case of existing customers, RE shall obtain the Permanent Account Number or equivalent e-document thereof or Form No. 60, by such date as may be notified by the Central Government, failing which RE shall temporarily cease operations in the account till the time the Permanent Account Number or equivalent e-documents thereof or Form No. 60 is submitted by the customer.

Provided that before temporarily ceasing operations for an account, the RE shall give the customer an accessible notice and a reasonable opportunity to be heard. Further,  RE  shall  include,  in  its  internal  policy,  appropriate  relaxation(s)  for continued  operation  of  accounts  for  customers  who  are  unable  to  provide Permanent Account Number or equivalent e-document thereof or Form No. 60 owing to injury, illness or infirmity on account of old age or otherwise, and such like causes. Such accounts shall, however, be subject to enhanced monitoring.

Provided further that if a customer having an existing account-based relationship with a RE gives in writing to the RE that he does not want to submit his Permanent Account Number or equivalent e-document thereof or Form No.60, RE shall close the account and all obligations due in relation to the account shall be appropriately settled after establishing the identity of the customer by obtaining the identification documents as applicable to the customer.

Explanation  -  For  the purpose  of  this  paragraph,  'temporary  ceasing  of operations'  in  relation  an  account  shall  mean  the  temporary  suspension  of  all transactions or activities in relation to that account by the RE till such time the customer complies with the provisions of this paragraph. In case of asset accounts such as loan accounts, for the purpose of ceasing the operation in the account, only credits shall be allowed.

[125   Amended vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

<!-- RBI_PAGE:45 -->

## Part VI - Enhanced and Simplified Due Diligence Procedure

## A. Enhanced Due Diligence

40. 126 Enhanced Due Diligence (EDD) for non-face-to-face customer onboarding  (other  than  customer  onboarding  in  terms  of paragraph 17): Non-face-to-face onboarding facilitates the REs to establish relationship with the customer without meeting the customer physically or through V-CIP. Such non-face-to-face modes for the purpose of this paragraph includes use of digital channels such as CKYCR, DigiLocker, equivalent e-document, etc., and nondigital  modes such as obtaining copy of OVD certified by additional certifying authorities  as  allowed  for  NRIs  and  PIOs.  Following  EDD  measures  shall  be undertaken  by  REs  for  non-face-to-face  customer  onboarding  (other  than customer onboarding in terms of paragraph 17):

a) In case RE has introduced the process of V-CIP, the same shall be provided as  the  first  option  to  the  customer  for  remote  onboarding.  It  is  reiterated  that processes complying with prescribed standards and procedures for V-CIP shall be treated on par with face-to-face CIP for the purpose of this Master Direction.

- b) In order to prevent frauds, alternate mobile numbers shall not be linked post CDD  with  such  accounts  for  transaction  OTP,  transaction updates,  etc. Transactions shall be permitted only from the mobile number used for account opening. RE shall have a Board approved policy delineating a robust process of due diligence for dealing with requests for change of registered mobile number.

c)  Apart  from  obtaining  the  current  address  proof,  RE  shall  verify  the  current address through positive confirmation before allowing operations in the account. Positive confirmation may be carried out by means such as address verification letter, contact point verification, deliverables, etc.

d) RE shall obtain PAN from the customer and the PAN shall be verified from the verification facility of the issuing authority.

e) First transaction in such accounts shall be a credit from existing KYC-complied bank account of the customer.

[126   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:46 -->

f)  Such  customers  shall  be  categorized  as  high-risk  customers  and  accounts opened in non-face to face mode shall be subjected to enhanced monitoring until the identity of the customer is verified in face-to-face manner or through V-CIP.

## 41.  127 Accounts of Politically Exposed Persons (PEPs)

- A.  REs shall have the option of establishing a relationship with PEPs (whether as customer  or  beneficial  owner)  provided  that,  apart  from  performing  normal customer due diligence:
2. (a) REs  have  in  place  appropriate  risk  management  systems  to  determine whether the customer or the beneficial owner is a PEP;
3. (b) Reasonable measures are taken by the REs for establishing the source of funds / wealth;
4. (c) the approval to open an account for a PEP shall be obtained from the senior management;
5. (d) all  such  accounts  are  subjected  to  enhanced  monitoring  on  an  on-going basis;
6. (e)  in the event of an existing customer or the beneficial owner of an existing account subsequently becoming a PEP, senior management's approval is obtained to continue the business relationship;
- B.  These  instructions  shall  also  be  applicable  to  family  members  or  close associates of PEPs.

128 Explanation: For the purpose of this paragraph, 'Politically Exposed Persons' (PEPs) are individuals who are or have been entrusted with prominent public functions by  a  foreign  country ,  including  the  Heads  of  States/Governments, senior  politicians,  senior  government  or  judicial  or  military  officers,  senior executives of state-owned corporations and important political party officials.

## 42.  Client accounts opened by professional intermediaries:

REs shall ensure while opening client accounts through professional intermediaries, that:

- (a) Clients shall be identified when client account is opened by a professional intermediary on behalf of a single client.

[127 Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

[128 Inserted vide circular DOR.AML.REC.66/14.01.001/2023-24 dated January 04, 2024.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12593&Mode=0)

<!-- RBI_PAGE:47 -->

- (b) REs shall have option to hold 'pooled' accounts managed by professional intermediaries on behalf of entities like mutual funds, pension funds or other types of funds.
- (c) REs shall not open accounts of such professional intermediaries who are bound  by  any  client  confidentiality  that  prohibits  disclosure  of  the  client details to the RE.
- (d) All  the  beneficial  owners  shall  be  identified  where  funds  held  by  the intermediaries  are  not  co-mingled  at  the  level  of  RE,  and  there  are  'subaccounts', each of them attributable to a beneficial owner, or where such funds are co-mingled at the level of RE, the RE shall look for the beneficial owners.
- (e) REs shall, at their discretion, rely on the 'customer due diligence' (CDD) done by  an  intermediary,  provided  that  the  intermediary  is  a  regulated  and supervised entity and has adequate systems in place to comply with the KYC requirements of the customers.
- (f)  The ultimate responsibility for knowing the customer lies with the RE.

## B. Simplified Due Diligence

## 43. 129 Simplified norms for Self Help Groups (SHGs)

- (a) CDD of all the members of SHG shall not be required while opening the savings bank account of the SHG.
- (b) CDD of all the office bearers shall suffice.
- (c)  130   CDD of all the members of SHG may be undertaken at the time of credit linking of SHGs.

## 44.  Procedure to be followed by banks while opening accounts of foreign students

- (a) Banks shall, at their option, open a Non-Resident Ordinary (NRO) bank account of a foreign student on the basis of his/her passport (with visa &amp; immigration endorsement) bearing the proof of identity and address in the home country together with a photograph and a letter offering admission from the educational institution in India.

[129   Amended vide circular DBR.AML.BC.No.39/14.01.001/2018-19 dated May 29, 2019.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11565&Mode=0)

[130   Amended vide circular DOR.AML.BC.No.1/14.01.001/2021-22 dated April 1, 2021.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12060&Mode=0)

<!-- RBI_PAGE:48 -->

- i. Provided that a declaration about the local address shall be obtained within a period of 30 days of opening the account and the said local address is verified.
- ii. Provided further that pending the verification of address, the account shall be operated with a condition of allowing foreign remittances not exceeding USD 1,000 or equivalent into the account and a cap of rupees fifty thousand on aggregate in the same, during the 30-day period.
3. (b) The account shall be treated as a normal NRO account, and shall be operated in  terms  of  Reserve  Bank  of  India's  instructions  on  Non-Resident  Ordinary Rupee (NRO) Account, and the provisions of FEMA 1999.
4. (c) Students with Pakistani nationality shall require prior approval of the Reserve Bank for opening the account.

## 45.  Simplified KYC norms for Foreign Portfolio Investors (FPIs)

Accounts of FPIs which are eligible/ registered as per SEBI guidelines, for the purpose of investment under Portfolio Investment Scheme (PIS), shall be opened by  accepting  KYC documents as detailed in Annex IV, subject to Income Tax (FATCA/CRS) Rules.

Provided that banks shall obtain undertaking from FPIs or the Global Custodian acting on behalf of the FPI that as and when required, the exempted documents as detailed in Annex IV will be submitted.

<!-- RBI_PAGE:49 -->

## Chapter VII

## Record Management

46. 131 The following steps shall be taken regarding maintenance, preservation and reporting of customer information, with reference to provisions of PML Act and Rules. REs shall,
2. (a) maintain  all  necessary  records  of  transactions  between  the  RE  and  the customer, both domestic and international, for at least five years from the date of transaction;
3. (b) preserve the records pertaining to the identification of the customers and their addresses  obtained  while  opening  the  account  and  during  the  course  of business relationship, for at least five years after the business relationship is ended;
4. (c) 132 make available swiftly, the identification records and transaction data to the competent authorities upon request;
5. (d) introduce a system of maintaining proper record of transactions prescribed under Rule 3 of Prevention of Money Laundering (Maintenance of Records) Rules, 2005 (PML Rules, 2005);
6. (e) maintain all necessary information in respect of transactions prescribed under PML Rule 3 so as to permit reconstruction of individual transaction, including the following:
7. (i)  the nature of the transactions;
8. (ii)  the amount  of  the transaction and  the currency in which  it  was denominated;
9. (iii)  the date on which the transaction was conducted; and
10. (iv)  the parties to the transaction.
11. (f)  evolve  a  system  for  proper  maintenance  and  preservation  of  account information in a manner that allows data to be retrieved easily and quickly whenever required or when requested by the competent authorities;
12. (g) maintain records of the identity and address of their customer, and records in respect of transactions referred to in Rule 3 in hard or soft format.
13. 133 Explanation. - For the purpose of this paragraph, the expressions "records pertaining  to  the  identification",  'identification  records',  etc.,  shall  include

[131   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

[132   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[133   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:50 -->

updated records of the identification data, account files, business correspondence and results of any analysis undertaken.

- 46A. REs shall ensure that in case of customers who are non-profit organisations, the details of such customers are registered on the DARPAN Portal of NITI Aayog. If the same are not registered, RE shall register the details on the DARPAN Portal. REs shall also maintain such registration records for a period of five years after the business relationship between the customer and the RE has ended or the account has been closed, whichever is later.

<!-- RBI_PAGE:51 -->

## Chapter VIII

## Reporting Requirements to Financial Intelligence Unit - India

47. REs shall furnish  to  the  Director,  Financial  Intelligence  Unit-India  (FIU-IND), information referred to in rule 3 of the PML (Maintenance of Records) Rules, 2005 in terms of rule 7 thereof.

Explanation:  In  terms  of  Third  Amendment  Rules  notified  September  22,  2015 regarding amendment to sub rule 3 and 4 of rule 7, Director, FIU-IND shall have powers  to  issue  guidelines  to  the  REs  for  detecting  transactions  referred  to  in various clauses of sub-rule (1) of rule 3, to direct them about the form of furnishing information and to specify the procedure and the manner of furnishing information.

48. The reporting formats and comprehensive reporting format guide, prescribed/ released by FIU-IND and Report Generation Utility and Report Validation Utility developed to assist reporting entities in the preparation of prescribed reports shall be taken note of. The editable electronic utilities to file electronic Cash Transaction Reports (CTR) / Suspicious Transaction Reports (STR) which FIUIND has placed on its website shall be made use of by REs which are yet to install/adopt suitable technological tools for extracting CTR/STR from their live transaction data. The Principal Officers of those REs, whose all branches are not  fully  computerized,  shall  have  suitable  arrangement  to  cull  out  the transaction details from branches which are not yet computerized and to feed the data into an electronic file with the help of the editable electronic utilities of CTR/STR  as have been made  available by FIU-IND on its website http://fiuindia.gov.in.
49. 134 While furnishing information to the Director, FIU-IND, delay of each day in not reporting a transaction or delay of each day in rectifying a mis-represented transaction beyond the time limit as specified in the Rule shall be constituted as a  separate  violation.  REs  shall  not  put  any  restriction  on  operations  in  the accounts merely on the basis of the STR filed.

Every RE, its directors, officers, and all employees shall ensure that the fact of maintenance  of  records  referred  to  in  rule  3  of  the  PML  (Maintenance  of Records)  Rules,  2005  and  furnishing  of  the  information  to  the  Director  is confidential. However, such confidentiality requirement shall not inhibit sharing of information under paragraph 4(b) of this Master Direction of any analysis of transactions and activities which appear unusual, if any such analysis has been done.

[134   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:52 -->

50. Robust software, throwing alerts when the transactions are inconsistent with risk categorization and updated profile of the customers shall be put in to use as a part of effective identification and reporting of suspicious transactions.

<!-- RBI_PAGE:53 -->

## Chapter IX

## Requirements/obligations under International Agreements Communications from International Agencies

## 51.  135 Obligations under the Unlawful Activities (Prevention) (UAPA) Act, 1967:

- (a) REs  shall  ensure  that  in  terms  of  section  51A  of  the  Unlawful  Activities (Prevention) (UAPA) Act, 1967 and amendments thereto, they do not have any account in the name of individuals/entities appearing in the lists of individuals and  entities,  suspected  of  having  terrorist  links,  which  are  approved  by  and periodically  circulated  by  the  United  Nations  Security  Council  (UNSC).  The details of the two lists are as under:
- i. The 'ISIL  (Da'esh)  &amp;Al-Qaida  Sanctions  List ',  established  and maintained  pursuant  to  Security  Council  resolutions  1267/1989/2253, which includes names of individuals and entities associated with the AlQaida is available at

[www.un.org/securitycouncil/sanctions/1267/aq\_sanctions\_list](https://www.un.org/securitycouncil/sanctions/1267/aq_sanctions_list)

- ii. The 'Taliban Sanctions List' , established and maintained pursuant to Security  Council  resolution  1988  (2011) , which  includes  names  of individuals and entities associated with the Taliban is available at https://www.un.org/securitycouncil/sanctions/1988/materials

REs shall also ensure to refer to the lists as available in the Schedules to the Prevention and Suppression of Terrorism (Implementation of Security Council Resolutions) Order, 2007, as amended from time to time. The aforementioned lists, i.e., UNSC Sanctions Lists and lists as available in the Schedules to the Prevention and Suppression of Terrorism (Implementation of Security Council Resolutions) Order, 2007, as amended from time to time, shall be verified on daily basis and any modifications to the lists in terms of additions, deletions or other  changes  shall  be  taken  into  account  by  the  REs  for  meticulous compliance.

- (b) Details  of  accounts  resembling  any  of  the  individuals/entities  in  the  lists shall  be  reported  to  FIU-IND  apart  from  advising  Ministry  of  Home  Affairs (MHA) as required under UAPA notification dated  136 February 2, 2021 (Annex II of this Master Direction).

[135   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023. Further, earlier paragraphs 51, 52 and](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

53 have been consolidated in paragraph 51 vide this amendment.

[136   Amended vide circular DOR.AML.REC.48/14.01.001/2020-21 dated March 23, 2021.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12042&Mode=0)

<!-- RBI_PAGE:54 -->

- (c) Freezing of Assets under section 51A of UAPA, 1967: The procedure laid down in the UAPA Order dated  137 February 2, 2021 (Annex II of this Master Direction), shall be strictly followed and meticulous compliance with the Order issued by the  Government  shall  be  ensured.  The  list  of  Nodal  Officers  for  UAPA  is available on the website of MHA.
52.    138 Obligations  under  Weapons  of  Mass  Destruction  (WMD)  and  their Delivery Systems (Prohibition of Unlawful Activities) Act, 2005 (WMD Act, 2005):
- (a) 139 REs shall ensure meticulous compliance with the 'Procedure for Implementation of section 12A of the Weapons of Mass Destruction (WMD) and their Delivery Systems (Prohibition of Unlawful Activities) Act, 2005' laid down  in  terms  of  section  12A  of  the  WMD  Act,  2005  vide  Order  dated September 1, 2023, by the Ministry of Finance, Government of India (Annex III of this Master Direction).
- (b) In  accordance  with  paragraph  3  of  the  aforementioned  Order,  REs  shall ensure not to carry out transactions in case the particulars of the individual / entity match with the particulars in the designated list.
- (c) Further,  REs  shall  run  a  check,  on  the  given  parameters,  at  the  time  of establishing  a  relation  with  a  customer  and  on  a  periodic  basis  to  verify whether individuals and entities in the designated list are holding any funds, financial asset, etc., in the form of bank account, etc.
- (d) 140 In  case  of  match  in  the  above  cases,  REs  shall  immediately  inform  the transaction  details  with  full  particulars  of  the  funds,  financial  assets  or economic resources involved to the Central Nodal Officer (CNO), designated as the authority to exercise powers under section 12A of the WMD Act, 2005. A copy of the communication shall be sent to State Nodal Officer, where the account / transaction is held and to the RBI.

It may be noted that in terms of Paragraph 1 of the Order, Director, FIU-India has been designated as the CNO.

- (e) REs may refer to the designated list, as amended from time to time, available on the portal of FIU-India.

[137   Amended vide circular DOR.AML.REC.48/14.01.001/2020-21 dated March 23, 2021.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12042&Mode=0)

[138   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12042&Mode=0)

[139   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

[140   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:55 -->

- (f)  In case there are reasons to believe beyond doubt that funds or assets held by a customer would fall under the purview of clause (a) or (b) of sub-section (2)  of  section  12A  of  the  WMD  Act,  2005,  REs  shall  prevent  such individual/entity from conducting financial transactions, under intimation to the CNO by email, FAX and by post, without delay.
- (g) In case an order to freeze assets under section 12A is received by the REs from the CNO, REs shall, without delay, take necessary action to comply with the Order.
- (h) The process of unfreezing of funds, etc., shall be observed as per paragraph 7 of the Order. Accordingly, copy of application received from an individual/entity regarding unfreezing shall be forwarded by RE along with full details of the asset frozen, as given by the applicant, to the CNO by email, FAX and by post, within two working days.
53. REs  shall  verify  every  day,  the  'UNSCR  1718  Sanctions  List  of  Designated Individuals and Entities', as available at https://www.mea.gov.in/Implementationof-UNSC-Sanctions-DPRK.htm, to take into account any modifications to the list in terms of additions, deletions or other changes and also ensure compliance with the 'Implementation of Security Council Resolution on Democratic People's Republic of Korea Order, 2017', as amended from time to time by the Central Government.
- 53A. 141 In addition to the above, REs shall take into account - (a) other UNSCRs and (b)  lists  in  the  first  schedule  and  the  fourth  schedule  of  UAPA,  1967  and  any amendments  to  the  same  for  compliance  with  the  Government  orders  on implementation of section 51A of the UAPA and section 12A of the WMD Act.
- 53B. 142 REs shall  undertake  countermeasures  when  called  upon  to  do  so  by  any international or intergovernmental organisation of which India is a member and accepted by the Central Government.

## 54.  Jurisdictions that do not or insufficiently apply the FATF Recommendations

- (a)  143 FATF Statements circulated by Reserve Bank of India from time to time, and publicly  available  information,  for  identifying  countries,  which  do  not  or insufficiently apply the FATF Recommendations, shall be considered. REs shall

[141   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[142   Inserted vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

[143   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:56 -->

apply enhanced due diligence measures, which are effective and proportionate to the risks, to business relationships and transactions with natural and legal persons (including financial institutions) from countries for which this is called for by the FATF.

- (b) Special attention shall be given to business relationships and transactions with persons  (including  legal  persons  and  other  financial  institutions)  from  or  in countries that do not or insufficiently apply the FATF Recommendations and jurisdictions included in FATF Statements.

Explanation: The processes referred to in (a) &amp; (b) above do not preclude REs from having legitimate trade and business transactions with the countries and jurisdictions mentioned in the FATF statement.

- (c) The  background  and  purpose  of  transactions  with  persons  (including  legal persons  and  other  financial  institutions)  from  jurisdictions  included  in  FATF Statements  and  countries  that  do  not  or  insufficiently  apply  the  FATF Recommendations shall  be  examined,  and  written  findings  together  with  all documents  shall  be  retained  and  shall  be  made  available  to  Reserve Bank/other relevant authorities, on request.

54A.  144 REs are encouraged to leverage latest technological innovations and tools for effective implementation of name screening to meet the sanctions requirements.

[144   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:57 -->

## Chapter X

## Other Instructions

## 55. 145 Secrecy Obligations and Sharing of Information:

- (a) REs shall maintain secrecy regarding the customer information which arises out of the contractual relationship between the RE and customer.
- (b) Information collected from customers for the purpose of opening of account shall be treated as confidential and details thereof shall not be divulged for the purpose of cross selling, or for any other purpose without the express permission of the customer.
- (c) While considering the requests for data/information from Government and other agencies, REs shall satisfy themselves that the information being sought is not of such a nature as will violate the provisions of the laws relating to secrecy in the transactions.
- (d) The exceptions to the said rule shall be as under:
- i. Where disclosure is under compulsion of law,
- ii. Where there is a duty to the public to disclose,
- iii. Where the interest of RE requires disclosure, and
- iv. Where the disclosure is made with the express or implied consent of the customer.

## 55A. 146 Compliance with  the  provisions  of  Foreign  Contribution  (Regulation) Act, 2010

Banks  shall  ensure  adherence  to  the  provisions  of  Foreign  Contribution (Regulation) Act, 2010 and Rules made thereunder. Further, banks shall also ensure meticulous compliance with any instructions / communications on the matter issued from time to time by the Reserve Bank based on advice received from the Ministry of Home Affairs, Government of India.

## 56.  147 CDD Procedure and sharing KYC information with Central KYC Records Registry (CKYCR)

- (a) Government of India has authorised the Central Registry of Securitisation Asset Reconstruction  and  Security  Interest  of  India  (CERSAI),  to  act  as,  and  to perform the functions of the CKYCR vide Gazette Notification No. S.O. 3183(E) dated November 26, 2015.

[145   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[146   Inserted vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

[147   Amended vide circular DOR.AML.BC.No.31/14.01.001/2020-21 dated December 18, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12008&Mode=0)

<!-- RBI_PAGE:58 -->

- (b) In terms of provision of Rule 9(1A) of the PML Rules, the REs shall capture customer's KYC  records  and  upload onto  CKYCR  within  10  days of commencement of an account-based relationship with the customer.
- (c) Operational  Guidelines  for  uploading  the  KYC  data  have  been  released  by CERSAI.
- (d) REs  shall  capture  the  KYC  information  for  sharing  with  the  CKYCR  in  the manner  mentioned  in  the  Rules,  as  per  the  KYC  templates  prepared  for 'Individuals' and 'Legal Entities' (LEs), as the case may be. The templates may be revised from time to time, as may be required and released by CERSAI.
- (e) The  'live  run'  of  the  CKYCR  started  from  July  15,  2016  in  phased  manner beginning with new 'individual accounts'. Accordingly, Scheduled Commercial Banks (SCBs) are required to invariably upload the KYC data pertaining to all new individual  accounts  opened  on  or  after  January  1,  2017,  with  CKYCR. SCBs were initially allowed time up-to February 1, 2017, for uploading data in respect of accounts opened during January 2017.

REs other than SCBs were required to start uploading the KYC data pertaining to  all  new  individual  accounts  opened  on  or  after  from  April  1,  2017,  with CKYCR in terms of the provisions of the Rules ibid.

- (f)  REs shall upload KYC records pertaining to accounts of LEs opened on or after April 1, 2021, with CKYCR in terms of the provisions of the Rules ibid. The KYC records have to be uploaded as per the LE Template released by CERSAI.
- (g) Once KYC Identifier is generated by CKYCR, REs shall ensure that the same is communicated to the individual/LE as the case may be.
- (h) In  order  to  ensure  that  all  KYC  records  are  incrementally  uploaded  on  to CKYCR,  REs  shall  upload/update  the  KYC  data  pertaining  to  accounts  of individual customers and LEs opened prior to the above-mentioned dates as per clauses (e) and (f), respectively, at the time of periodic updation as specified in  paragraph  38  of  this  Master  Direction,  or  earlier,  when  the  updated  KYC information is obtained/received from the customer.  148 Also, whenever the RE obtains additional or updated information from any customer as per clause (j) below in this paragraph or Rule 9 (1C) of the PML Rules, the RE shall within seven days or within such period as may be notified by the Central Government, furnish the updated information to CKYCR, which shall update the KYC records of the existing customer in CKYCR. CKYCR  shall thereafter inform

[148  Inserted vide circular DOR.AML.REC. 49/14.01.001/2024-25 dated November 6, 2024.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12746&Mode=0)

<!-- RBI_PAGE:59 -->

electronically  all  the  reporting  entities  who  have  dealt  with  the  concerned customer regarding updation of KYC record of the said customer. Once CKYCR informs an RE regarding an update in the KYC record of an existing customer, the RE shall retrieve the updated KYC records from CKYCR and update the KYC record maintained by the RE.

- (i)  REs shall ensure that during periodic updation, the customers are migrated to the current CDD standard.
- (j) 149 For  the  purpose  of  establishing  an  account-based  relationship,  updation/ periodic updation or for verification of identity of a customer, the RE shall seek the KYC Identifier from the customer or retrieve the KYC Identifier, if available, from the CKYCR and proceed to obtain KYC records online by using such KYC Identifier and shall not require a customer to submit the same KYC records or information or any other additional identification documents or details, unless-
- (i)  there  is  a  change  in  the  information  of  the  customer  as  existing  in  the records of CKYCR; or
- (ii) the KYC record or information retrieved is incomplete or is not as per the current applicable KYC norms; or
- (iii)  150 the validity period of downloaded documents  has lapsed; or
- (iv) the  RE  considers  it  necessary  in  order  to  verify  the  identity  or  address (including current address) of the customer, or to perform enhanced due diligence or to build an appropriate risk profile of the customer.

## 57.  Reporting requirement under Foreign Account Tax Compliance Act (FATCA) and Common Reporting Standards (CRS)

Under FATCA and CRS, REs shall adhere to the provisions of Income Tax Rules 114F,  114G  and  114H  and  determine  whether  they  are  a  Reporting  Financial Institution as defined in Income Tax Rule 114F and if so, shall take following steps for complying with the reporting requirements:

- (a) Register on the related e-filling portal of Income Tax Department as Reporting Financial Institutions at the link https://incometaxindiaefiling.gov.in/ post login -&gt; My Account --&gt; Register as Reporting Financial Institution,

[149  Amended vide circular DOR.AML.REC. 49/14.01.001/2024-25 dated November 6, 2024.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12746&Mode=0)

[150   Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:60 -->

- (b) Submit online reports by using the digital signature of the 'Designated Director' by  either  uploading  the  Form  61B  or  'NIL'  report,  for  which,  the  schema prepared by Central Board of Direct Taxes (CBDT) shall be referred to.

Explanation: REs shall refer to the spot reference rates published by Foreign Exchange Dealers' Association of India (FEDAI) on their website at http://www.fedai.org.in/RevaluationRates.aspx for carrying out the due diligence procedure for the purposes of identifying reportable accounts in terms of Rule 114H.

- (c) Develop Information Technology (IT) framework for carrying out due diligence procedure and for recording and maintaining the same, as provided in Rule 114H.
- (d) Develop a system of audit for the IT framework and compliance with Rules 114F, 114G and 114H of Income Tax Rules.
- (e) Constitute a 'High Level Monitoring Committee' under the Designated Director or any other equivalent functionary to ensure compliance.
- (f)  Ensure  compliance  with  updated  instructions/  rules/  guidance  notes/  Press releases/ issued on the subject by Central Board of Direct Taxes (CBDT) from time to time and available on the web site http://www.incometaxindia.gov.in/Pages/default.aspx.  REs  may  take  note  of the following:
- i.  updated Guidance Note on FATCA and CRS
- ii. a press release on 'Closure of Financial Accounts' under Rule 114H (8).

## 58.  Period for presenting payment instruments

Payment of cheques/drafts/pay orders/banker's cheques, if they are presented beyond the period of three months from the date of such instruments, shall not be made.

## 59.  151 Operation of Bank Accounts &amp; Money Mules

The instructions on opening of accounts and monitoring of transactions shall be strictly adhered to,  in  order  to  minimise  the  operations  of  'Money  Mules'  which  are  used  to launder the proceeds of fraud schemes (e.g., phishing and identity theft) by criminals who gain illegal access to deposit accounts by recruiting third parties which act as 'money mules.' Banks shall undertake diligence measures and meticulous monitoring to identify accounts  which  are  operated  as  Money  Mules  and  take  appropriate  action,  including reporting of suspicious transactions to FIU-IND. Further, if it is established that an account opened and operated is that of a Money Mule, but no STR was filed by the concerned bank, it shall then be deemed that the bank has not complied with these directions.

[151   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:61 -->

## 60.  Collection of Account Payee Cheques

Account payee cheques for any person other than the payee constituent shall not be collected. Banks shall, at their option, collect account payee cheques drawn for an amount not exceeding rupees fifty thousand to the account of their customers who are co-operative credit societies, provided the payees  of such  cheques  are  the constituents of such co-operative credit societies.

61. (a)  152 A Unique Customer Identification Code (UCIC) shall be allotted while entering  into  new  relationships  with  individual  customers  as  also  the  existing individual customers by REs.

- (b) 153 The  REs  shall,  at  their  option,  not  issue  UCIC  to  all  walk-in/occasional customers provided it is ensured that there is adequate mechanism to identify such walk-in customers who have frequent transactions with them and ensure that they are allotted UCIC.

## 62.  154 Introduction of New Technologies

REs  shall  identify  and  assess  the  ML/TF  risks  that  may  arise  in  relation  to  the development of new products and new business practices, including new delivery mechanisms, and the use of new or developing technologies for both new and preexisting products.

Further, REs shall ensure:

- (a)  to  undertake  the  ML/TF  risk  assessments  prior  to  the  launch  or  use  of  such products, practices, services, technologies; and
- (b)  adoption  of  a  risk-based  approach  to  manage  and  mitigate  the  risks  through appropriate EDD measures and transaction monitoring, etc.

[152   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[153   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

[154   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:62 -->

## 63.  155 Correspondent Banking

Banks shall have a policy approved by their Boards, or by a committee headed by the Chairman/CEO/MD to lay down parameters for approving  cross-border  correspondent banking and other similar relationships. In addition to performing normal CDD measures, such relationships shall be subject to the following conditions:

- (a) Banks shall gather sufficient information about a respondent bank to understand fully the nature of the respondent bank's business and to determine from publicly available information  the  reputation  of  the  respondent  bank  and  the  quality  of  supervision, including whether it has been subjected to a ML/TF investigation or regulatory action. Banks shall assess the respondent bank's AML/CFT controls.
- (b) The information gathered in relation to the nature of business of the respondent bank  shall  include  information  on  management,  major  business  activities, purpose of opening the account, identity of any third-party entities that will use the correspondent banking services, regulatory/supervisory framework in the respondent bank's home country among other relevant information.
- (c) Prior approval from senior management shall be obtained for establishing new correspondent  banking  relationships.  However,  post  facto  approval  of  the Board or the Committee empowered for this purpose shall also be taken.
- (d) Banks  shall  clearly  document  and  understand  the  respective  AML/CFT responsibilities of institutions involved.
- (e) In  the  case  of  payable-through-accounts,  the  correspondent  bank  shall  be satisfied  that  the  respondent  bank  has  conducted  CDD  on  the  customers having  direct  access  to  the  accounts  of  the  correspondent  bank  and  is undertaking on-going 'due diligence' on them.
- (f)  The  correspondent  bank  shall  ensure  that  the  respondent  bank  is  able  to provide the relevant CDD information immediately on request.
- (g)  Correspondent relationship shall not be entered into or continued with a shell bank.
- (h)  It shall be ensured that the respondent banks do not permit their accounts to be used by shell banks.
- (i)  Banks shall be cautious of correspondent banking relationships with institutions located  in  jurisdictions  which  have  strategic  deficiencies  or  have  not  made sufficient progress in implementation of FATF Recommendations.

[155   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:63 -->

- (j)  Banks  shall  ensure  that  respondent  banks  have  KYC/AML  policies  and procedures  in  place  and  apply  enhanced  'due  diligence'  procedures  for transactions carried out through the correspondent accounts.

## 64.  156 Wire Transfer

## A.  Information requirements for wire transfers for the purpose of this Master Direction:

- i.  All cross-border wire transfers shall be accompanied  by  accurate, complete, and meaningful originator and beneficiary information as mentioned below:
- a.  name of the originator;
- b.  the  originator  account  number  where  such  an  account  is  used  to process the transaction;
- c. the  originator's  address,  or  national  identity  number,  or  customer identification number, or date and place of birth;
- d.  name of the beneficiary; and
- e.  the  beneficiary  account  number  where  such  an  account  is  used  to process the transaction.

In the absence of an account, a unique transaction reference number should be included which permits traceability of the transaction.

- ii.  In  case  of  batch  transfer,  where  several  individual  cross-border  wire transfers from a single originator are bundled in a batch file for transmission to  beneficiaries,  they  (i.e.,  individual  transfers)  are  exempted  from  the requirements  of  clause  (i)  above  in  respect  of  originator  information, provided  that  they  include  the  originator's  account  number  or  unique transaction  reference  number,  as  mentioned  above,  and  the  batch  file contains required and accurate originator information, and full beneficiary information, that is fully traceable within the beneficiary country.
- iii.  Domestic  wire  transfer, where  the  originator  is  an  account  holder of  the ordering RE, shall be accompanied by originator and beneficiary information, as indicated for cross-border wire transfers in (i) and (ii) above.
- iv. 157 Domestic wire transfers of rupees fifty thousand and above, where the originator  is  not  an  account  holder  of  the  ordering  RE ,  shall  also  be

[156   Amended vide circular DOR.AML.REC.13/14.01.001/2023-24 dated May 4, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12498&Mode=0)

[157   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:64 -->

accompanied  by  originator  and  beneficiary  information  as  indicated  for cross-border wire transfers.

In case of domestic wire transfers below rupees fifty thousand where the originator  is  not  an  account  holder  of  the  ordering  RE  and  where  the information accompanying the wire transfer can be made available to the beneficiary RE and appropriate authorities by other means, it is sufficient for  the  ordering  RE  to  include  a  unique  transaction  reference  number, provided  that  this  number  or  identifier  will  permit  the  transaction  to  be traced back to the originator or the beneficiary.

The  ordering  RE  shall  make  the  information  available  within  three working/business days of receiving the request from the intermediary RE, beneficiary RE, or from appropriate competent authorities.

- v. 158 REs shall ensure that all the information on the wire transfers shall be immediately made available to appropriate  law  enforcement  authorities, prosecuting / competent authorities as well as FIU-IND on receiving such requests with appropriate level provisions.
- vi.  The wire transfer instructions are not intended to cover the following types of payments:
- a.  Any transfer that flows from a transaction carried out using a credit card / debit card / Prepaid Payment Instrument (PPI), including through a token or any other similar reference string associated with the card / PPI, for the purchase of goods or services ,  so  long as the credit or debit  card  number  or  PPI  id  or  reference  number  accompanies  all transfers flowing from the transaction. However, when a credit or debit card or PPI is used as a payment system to effect a person-to-person wire  transfer,  the  wire  transfer  instructions  shall  apply  to  such transactions and the necessary information should be included in the message.
- b.  Financial institution-to-financial institution  transfers  and  settlements, where  both  the  originator  person  and  the  beneficiary  person  are regulated financial institutions acting on their own behalf.

It is, however, clarified that nothing within these instructions will impact the obligation of an RE to comply with applicable reporting requirements under PML  Act,  2002,  and  the  Rules  made  thereunder,  or  any  other  statutory requirement in force.

[158   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:65 -->

- B.  Responsibilities  of  ordering  RE,  intermediary  RE  and  beneficiary  RE, effecting wire transfer, are as under:

## i.  Ordering RE:

- a.  The  ordering  RE  shall  ensure  that  all  cross-border  and  qualifying domestic wire transfers {viz., transactions as per clauses (iii) and (iv) of  paragraph  'A'  above},  contain  required  and  accurate  originator information and required beneficiary information, as indicated above.
- b.  Customer Identification shall be made if a customer, who is not an account  holder  of  the  ordering  RE, is  intentionally  structuring domestic  wire  transfers below  rupees  fifty  thousand  to  avoid reporting or monitoring.  In  case  of  non-cooperation  from  the customer, efforts shall be made to establish identity and if the same transaction is found to be suspicious, STR may be filed with FIU-IND in accordance with the PML Rules.
- c.  Ordering RE shall not execute the wire transfer if it is not able to comply with the requirements stipulated in this paragraph.

## ii.  Intermediary RE:

- a.  RE processing an intermediary element of a chain of wire transfers shall ensure that all originator and beneficiary information accompanying a wire transfer is retained with the transfer.
- b.  Where technical limitations prevent the required originator or beneficiary  information  accompanying  a  cross-border  wire  transfer from remaining with a related domestic wire transfer, the intermediary RE shall keep a record, for at least five years, of all the information received from the ordering financial institution or another intermediary RE.
- c. Intermediary  RE  shall  take  reasonable  measures  to  identify  crossborder  wire  transfers  that  lack  required  originator  information  or required beneficiary information. Such measures should be consistent with straight-through processing.
- d.  Intermediary RE shall have effective risk-based policies and procedures for determining: (a) when to execute, reject, or suspend a wire transfer lacking required originator or required beneficiary information; and (b) the appropriate follow-up action including seeking

<!-- RBI_PAGE:66 -->

further  information  and  if  the  transaction  is  found  to  be  suspicious, reporting to FIU-IND in accordance with the PML Rules.

## iii.  Beneficiary RE:

- a.  Beneficiary RE shall take reasonable measures, including post-event monitoring or real-time monitoring where feasible, to identify crossborder  wire  transfers  and  qualifying  domestic  wire  transfers  {viz., transactions as per clauses (iii) and (iv) of paragraph 'A' above}, that lack required originator information or required beneficiary information.
- b.  Beneficiary RE shall have effective risk-based policies and procedures for determining: (a) when to execute, reject, or suspend a wire transfer lacking required originator or required beneficiary information; and (b) the  appropriate  follow-up  action  follow-up  action  including  seeking further  information  and  if  the  transaction  is  found  to  be  suspicious, reporting to FIU-IND in accordance with the PML Rules.
- iv. 159 Money Transfer Service Scheme (MTSS) providers and other REs, are required to  comply  with  all  of  the  relevant  requirements  of  this  paragraph, whether they are providing services directly or through their agents. REs that control both the ordering and the beneficiary side of a wire transfer shall:
- a.  take  into  account  all  the  information  from  both  the  ordering  and beneficiary sides in order to determine whether an STR has to be filed; and
- b.  file an STR with FIU, in accordance with the PML Rules, if a transaction is found to be suspicious.

## C.  Other Obligations

- i.  Obligations  in  respect  of  REs'  engagement  or  involvement  with unregulated entities in the process of wire transfer

REs shall be cognizant of their obligations under these instructions and ensure strict compliance, in respect of engagement or involvement of any unregulated entities in the process of wire transfer. More specifically, whenever there is involvement of any unregulated entities in the process of wire transfers, the concerned REs shall be fully responsible for information, reporting and other requirements and therefore shall ensure, inter alia, that,

[159   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:67 -->

- i)  there  is  unhindered  flow  of  complete  wire  transfer  information,  as mandated  under  these  directions,  from  and  through  the  unregulated entities involved;

ii) the agreement / arrangement, if any, with such unregulated entities by REs clearly stipulates the obligations under wire transfer instructions; and iii) a termination clause is available in their agreement / arrangement, if any, with such entities so that in case the unregulated entities are unable / arrangement can be terminated. Existing agreements / arrangements, if any, with such entities shall be reviewed within three months to ensure

- to support the wire information requirements, the agreement aforementioned requirements.
- ii.  REs' responsibility while undertaking cross-border wire transfer with respect to name screening (such that they do not process cross-border transactions of designated persons and entities)

REs are prohibited from conducting transactions with designated persons and entities  and  accordingly,  in  addition  to  compliance  with  Chapter  IX  of  the Master Direction,  REs  shall  ensure  that  they  do  not  process  cross-border transactions of designated persons and entities.

## iii.  REs' responsibility to fulfil record management requirements

Complete originator and beneficiary information relating to wire transfers shall be preserved by the REs involved in the wire transfer, in accordance with paragraph 46 of the Master Direction.

## 65. Issue and Payment of Demand Drafts, etc.,

Any remittance of funds by way of demand draft, mail/telegraphic transfer/NEFT/IMPS or any other mode and issue of travelers' cheques for value of rupees fifty thousand and above shall be effected by debit to the customer's account or against cheques and not against cash payment.

Further, the name of the purchaser shall be incorporated on the face of the demand draft, pay order, banker's cheque, etc., by the issuing bank. These instructions shall take effect for such instruments issued on or after September 15, 2018.

<!-- RBI_PAGE:68 -->

## 66.  160 Quoting of PAN

Permanent account number (PAN) or equivalent e-document thereof of customers shall be obtained and verified while undertaking transactions as per the provisions of Income Tax Rule 114B applicable to banks, as amended from time to time. Form 60 shall  be  obtained  from  persons  who  do  not  have  PAN  or  equivalent  e-document thereof.

## 67.  Selling Third party products

REs acting as agents while selling third party products as per regulations in force from time to time shall comply with the following aspects for the purpose of these directions:

- (a) the identity and  address  of  the  walk-in  customer  shall  be  verified for transactions above rupees fifty thousand as required under paragraph 13(e) of this Direction.
- (b)   161 transaction details of sale of third-party products and related records shall be maintained as prescribed in paragraph 46 of Chapter VII.
- (c)  AML software capable of capturing, generating and analysing alerts for the purpose  of  filing  CTR/STR  in  respect  of  transactions  relating  to  third  party products with customers including walk-in customers shall be available.
- (d) transactions involving rupees fifty thousand and above shall be undertaken only by:
- debit to customers' account or against cheques;  and
- obtaining and verifying the PAN given by the account-based as well as walk-in customers.
- (e) Instruction at 'd' above shall also apply to sale of REs' own products, payment of dues of credit cards/sale and reloading of prepaid/travel cards and any other product for rupees fifty thousand and above.

## 68.  At-par cheque facility availed by co-operative banks

- (a) The 'at par' cheque facility offered by commercial banks to co-operative banks shall  be  monitored  and such arrangements be reviewed to assess the risks including credit risk and reputational risk arising therefrom.
- (b) The right to verify the records maintained by the customer cooperative banks/ societies for compliance with the extant instructions on KYC and AML under such arrangements shall be retained by banks.

[160   Amended vide circular DOR.AML.BC.No.27/14.01.001/2019-20 dated January 9, 2020.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=11783&Mode=0)

[161   Amended vide circular DOR.AML.REC.44/14.01.001/2023-24 dated October 17, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12549&Mode=0)

<!-- RBI_PAGE:69 -->

- (c) Cooperative Banks shall:
- i. ensure that the 'at par' cheque facility is utilised only:
- a.  for their own use,
- b.  for  their  account-holders  who  are  KYC  complaint,  provided  that  all transactions of rupees fifty thousand or more are strictly by debit to the customers' accounts,
- c.  for walk-in customers against cash for less than rupees fifty thousand per individual.
- ii. maintain the following:
- a.  records  pertaining  to  issuance  of  'at  par'  cheques  covering,  inter  alia, applicant's name and account number, beneficiary's details and date of issuance of the 'at par' cheque,
- b.  sufficient  balances/drawing  arrangements  with  the  commercial  bank extending such facility for purpose of honouring such instruments.
- iii. ensure  that  'At  par'  cheques  issued  are  crossed  'account  payee' irrespective of the amount involved.

## 69.  Issuance of Prepaid Payment Instruments (PPIs):

PPI issuers shall ensure that the instructions issued by Department of Payment and Settlement System of Reserve Bank of India through their Master Direction are strictly adhered to.

## 70.  162 Hiring of Employees and Employee training

- (a) Adequate screening mechanism, including Know Your Employee / Staff policy, as an integral part of their personnel recruitment/hiring process shall be put in place.
- (b) REs shall endeavour to ensure that the staff dealing with / being deployed for KYC/AML/CFT  matters  have:  high  integrity  and  ethical  standards,  good understanding  of  extant  KYC/AML/CFT  standards,  effective  communication skills  and  ability  to  keep  up  with  the  changing  KYC/AML/CFT  landscape, nationally and internationally. REs shall also strive to develop an environment which fosters open communication and high integrity amongst the staff.
- (c) On-going  employee  training  programme  shall  be  put  in  place  so  that  the members of staff are adequately trained in KYC/AML/CFT policy. The focus

[162   Amended vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:70 -->

of the training shall be different for frontline staff, compliance staff and staff dealing with new customers. The front desk staff shall be specially trained to handle issues arising from lack of customer education. Proper staffing of the audit function with persons adequately trained and well-versed in KYC/AML/CFT  policies  of  the  RE,  regulation  and  related  issues  shall  be ensured.

## 71. 163 Deleted

## Chapter XI

## Repeal Provisions

72. With the issue of these directions, the instructions / guidelines contained in the circulars mentioned in the Appendix, issued by the Reserve Bank stand repealed.
73. All  approvals  /  acknowledgements  given  under  the  above  circulars  shall  be deemed as given under these directions.
74. All the repealed circulars are deemed to have been in force prior to the coming into effect of these directions.

[163   Deleted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:71 -->

## Annex I

## Digital KYC Process

A. The RE shall develop an application for digital KYC process which shall be made available at customer touch points for undertaking KYC of their customers and the KYC process shall be undertaken only through this authenticated application of the REs.

B.  The  access  of  the  Application  shall  be  controlled  by  the  REs  and  it  should  be ensured that the same is not used by unauthorized persons. The Application shall be accessed only through login-id and password or Live OTP or Time OTP controlled mechanism given by REs to its authorized officials. C. The customer, for the purpose of KYC, shall visit the location of the authorized official of the RE or vice-versa. The original OVD shall be in possession of the customer.

D.  The  RE  must  ensure  that  the  Live  photograph  of  the  customer  is  taken  by  the authorized officer and the same photograph is embedded in the Customer Application Form  (CAF).  Further,  the  system  Application  of  the  RE  shall  put  a  water-mark  in readable  form  having  CAF  number,  GPS  coordinates,  authorized  official's  name, unique employee Code (assigned by REs) and Date (DD:MM:YYYY) and time stamp (HH:MM:SS) on the captured live photograph of the customer.

E. The Application of the RE shall have the feature that only live photograph of the customer is captured and no printed or video-graphed photograph of the customer is captured. The background behind the customer while capturing live photograph should be of white colour and no other person shall come into the frame while capturing the live photograph of the customer.

F. Similarly, the live photograph of the original OVD or proof of possession of Aadhaar where offline verification cannot be carried out (placed horizontally), shall be captured vertically from above and water-marking in readable form as mentioned above shall be done. No skew or tilt in the mobile device shall be there while capturing the live photograph of the original documents.

G. The live photograph of the customer and his original documents shall be captured in proper light so that they are clearly readable and identifiable.

H.  Thereafter,  all  the  entries  in  the  CAF  shall  be  filled  as  per  the  documents  and information furnished by the customer. In those documents where Quick Response

<!-- RBI_PAGE:72 -->

(QR) code is available, such details can be auto-populated by scanning the QR code instead  of  manual  filing  the  details.  For  example,  in  case  of  physical  Aadhaar/eAadhaar downloaded from UIDAI where QR code is available, the details like name, gender, date of birth and address can be auto-populated by scanning the QR available on Aadhaar/e-Aadhaar.

I.  Once  the  above  mentioned  process  is  completed, a  One  Time  Password (OTP) message containing the text that 'Please verify the details filled in form before sharing OTP' shall be sent to customer's own mobile number. Upon successful validation of the OTP, it will be treated as customer signature on CAF. However, if the customer does  not have  his/her own  mobile  number,  then mobile number  of his/her family/relatives/known persons may be used for this purpose and be clearly mentioned in CAF. In any case, the mobile number of authorized officer registered with the RE shall not be used for customer signature. The RE must check that the mobile number used in customer signature shall not be the mobile number of the authorized officer.

J.  The authorized officer shall provide a declaration about the capturing of the live photograph of customer and the original document. For this purpose, the authorized official shall be verified with One Time Password (OTP) which will be sent to his mobile number registered with the RE. Upon successful OTP validation, it shall be treated as authorized officer's signature on the declaration. The live photograph of the authorized official shall also be captured in this authorized officer's declaration.

K. Subsequent to all these activities, the Application shall give information about the completion of the process and submission of activation request to activation officer of the RE, and also generate the transaction-id/reference-id number of the process. The authorized  officer  shall  intimate  the  details  regarding  transaction-id/reference-id number to customer for future reference.

L. The authorized officer of the RE shall check and verify that:- (i) information available in  the  picture  of  document  is  matching  with  the  information  entered  by  authorized officer in CAF. (ii) live photograph of the customer matches with the photo available in the document.; and (iii) all of the necessary details in CAF including mandatory field are filled properly.;

M. On Successful verification, the CAF shall be digitally signed by authorized officer of the RE who will take a print of CAF, get signatures/thumb-impression of customer at appropriate place, then scan and upload the same in system. Original hard copy may be returned to the customer.

<!-- RBI_PAGE:73 -->

Banks may use the services of Business Correspondent (BC) for this process.

<!-- RBI_PAGE:74 -->

## Annex II

## File No. 14014/01/2019/CFT Government of India Ministry of Home Affairs CTCR Division

North Block, New Delhi.

Dated: the 2 nd  February, 2021

(Amended vide corrigendum dated March 15, 2023) (Amended vide corrigendum dated August 29, 2023) (Amended vide corrigendum dated April 22, 2024)

## ORDER

## Subject: Procedure  for  implementation  of  Section  51A  of  the  Unlawful Activities (Prevention) Act, 1967.

Section 51A of the Unlawful Activities (Prevention) Act, 1967 (UAPA) reads as under:-

"51A. For the prevention of, and for coping with terrorist activities, the Central Government shall have power to -

- a)  freeze,  seize  or  attach  funds  and  other  financial  assets  or  economic resources held by, on behalf of or at the direction of the individuals or entities listed  in  the  Schedule  to  the  Order,  or  any  other  person  engaged  in  or suspected to be engaged in terrorism;
- b)  prohibit any individual or entity from making any funds, financial assets or economic  resources  or  related  services  available  for  the  benefit  of  the individuals or entities listed in the Schedule to the Order or any other person engaged in or suspected to be engaged in terrorism;
- c)  prevent the entry into or the transit through India of individuals listed in the Schedule to the Order or any other person engaged in or suspected to be engaged in terrorism".

The Unlawful Activities (Prevention) Act, 1967 defines "Order" as under: -

"Order" means the Prevention and Suppression of Terrorism (Implementation of Security Council Resolutions) Order, 2007, as may be amended from time to time.

2. In order to ensure expeditious and effective implementation of the provisions of Section 51A, a revised procedure is outlined below in supersession of earlier orders and guidelines on the subject:
3. Appointment and communication details of the UAPA Nodal Officers :

3.1 The Joint Secretary (CTCR), Ministry of Home Affairs would be the Central [designated] Nodal Officer for the UAPA [Telephone Number: 011-23093124, 011230923465 (Fax), email address:  jsctcr-mha@gov.in].

- 3.2 The Ministry of External Affairs, Department of Economic Affairs, Ministry of

<!-- RBI_PAGE:75 -->

Corporate  Affairs,  Foreigners  Division  of  MHA,  FIU-IND,  Central  Board  of  Indirect Taxes and Customs (CBIC) and Financial Regulators (RBI, SEBI and IRDA) shall appoint a UAPA Nodal Officer and communicate the name and contact details to the Central [designated] Nodal Officer for the UAPA.

3.4 All the States and UTs shall appoint a UAPA Nodal Officer preferably of the rank of the Principal Secretary/Secretary, Home Department and communicate the name and contact details to the Central [designated] Nodal Officer for the UAPA.

3.5 The  Central  [designated]  Nodal  Officer  for  the  UAPA  shall  maintain  the consolidated list of all UAPA Nodal Officers and forward the list to all other UAPA Nodal Officers, in July every year or as and when the list is updated and shall cause the amended list of UAPA Nodal Officers circulated to all the Nodal Officers.

3.6 The Financial  Regulators  shall  forward  the  consolidated  list  of  UAPA  Nodal Officers to the banks, stock exchanges/depositories, intermediaries regulated by SEBI and insurance companies.

3.7 The Regulators of the real estate agents, dealers in precious metals &amp; stones (DPMS) and DNFBPs shall forward the consolidated list of UAPA Nodal Officers to the real estate agents, dealers in precious metals &amp; stones (DPMS) and DNFBPs.

## 4. Communication of the list of designated individuals/entities :

4.1 The Ministry of External Affairs shall update the list of individuals and entities subject to the UN sanction measures whenever changes are made in the lists by the UNSC  1267  Committee  pertaining  to  Al  Qaida  and  Da'esh  and  the  UNSC  1988 Committee pertaining to Taliban. On such revisions, the Ministry of External Affairs would  electronically  forward  the  changes  without  delay  to  the  designated  Nodal Officers  in  the  Ministry  of  Corporate  Affairs,  CBIC,  Financial  Regulators,  FIU-IND, CTCR Division and Foreigners Division in MHA.

4.2 The  Financial  Regulators  shall  forward  the  list  of  designated  persons  as mentioned  in  Para  4(i)  above,  without  delay  to  the  banks,  stock  exchanges/ depositories, intermediaries regulated by SEBI and insurance companies.

4.3 The  Central  [designated]  Nodal  Officer  for  the  UAPA  shall  forward  the designated list as mentioned in Para 4(i) above, to all the UAPA Nodal Officers of States/UTs without delay.

4.4 The  UAPA  Nodal  Officer  in  Foreigners  Division  of  MHA  shall  forward  the designated list as mentioned in Para 4(i) above, to the immigration authorities and security agencies without delay.

4.5 The Regulators of the real estate agents, dealers in precious metals &amp; stones (DPMS) and DNFBPs shall forward the list of designated persons as mentioned in Para 4(i) above, to the real estate agents, dealers in precious metals &amp; stones (DPMS) and DNFBPs without delay.

5. Regarding funds, financial assets or economic resources or related services held in the form of bank accounts, stocks or Insurance policies etc.

<!-- RBI_PAGE:76 -->

5.1  The  Financial  Regulators  will  issue  necessary  guidelines  to  banks,  stock exchanges/depositories, intermediaries regulated by the SEBI and insurance companies requiring them -

(i) To maintain updated designated lists in electronic form and run a check on the given parameters on a daily basis to verify whether individuals or entities listed in the Schedule to the Order, hereinafter, referred to as designated individuals/entities are holding any funds, financial assets or economic resources or related services held in the form of bank accounts, stocks, Insurance policies etc., with them.

(ii) In case, the particulars of any of their customers match with the particulars of designated individuals/entities, the banks, stock exchanges/depositories, intermediaries   regulated by SEBI, insurance companies shall immediately inform full particulars of the funds, financial assets or economic resources or related services held in the form of bank accounts, stocks or Insurance policies etc., held by such customer on their books to the Central [designated] Nodal Officer for the UAPA, at Fax  No.011-23092551  and  also  convey  over  telephone  No.  011-23092548.  The particulars apart from being sent by post shall necessarily be conveyed on email id: jsctcr-mha@gov.in.

(iii) The banks, stock exchanges/depositories, intermediaries regulated by SEBI and insurance companies shall also send a copy of the communication mentioned in 5.1 (ii) above to the UAPA Nodal Officer of the State/UT where the account is held and to Regulators and FIU-IND, as the case may be, without delay.

(iv) In case, the match of any of the customers with the particulars of designated individuals/entities is  beyond  doubt,  the  banks,  stock  exchanges/depositories, intermediaries  regulated  by  SEBI  and  insurance  companies  shall  prevent  such designated persons from conducting financial transactions, under intimation to the Central [designated] Nodal Officer for the UAPA at Fax No.011-23092551 and also convey over telephone No.011-23092548. The particulars apart from being sent by post should necessarily be conveyed on e-mail id: jsctcr-mha@gov.in , without delay.

(v) The banks, stock exchanges/depositories, intermediaries regulated by SEBI, and insurance companies shall file a Suspicious Transaction Report (STR) with FIUIND covering all transactions in the accounts, covered under Paragraph 5.1(ii) above, carried through or attempted as per the prescribed format.

5.2 On receipt of the particulars, as referred to in Paragraph 5 (i) above, the Central [designated] Nodal Officer for the UAPA would cause a verification to be conducted by the State Police and/or the Central Agencies  so  as  to  ensure  that  the individuals/entities identified by the banks, stock exchanges/ depositories, intermediaries and insurance companies are the ones listed as designated individuals/entities and the funds, financial assets or economic resources or related services, reported by banks, stock exchanges/depositories, intermediaries regulated by SEBI and insurance companies are held by the designated individuals/entities. This verification  would  be  completed  expeditiously  from  the  date  of  receipt  of  such particulars.

5.3 In case,  the  results  of  the  verification  indicate  that  the  properties  are owned by or are held for the benefit of the designated individuals/entities, an orders to freeze these assets under Section 51A of the UAPA would be issued by the Central

<!-- RBI_PAGE:77 -->

[designated] nodal officer for the UAPA without delay and conveyed electronically to the concerned bank branch, depository and insurance company under intimation to respective  Regulators  and  FIU-IND.  The  Central  [designated]  nodal  officer  for  the UAPA shall also forward a copy thereof to all the Principal Secretaries/Secretaries, Home Department of the States/UTs and all UAPA nodal officers in the country, so that any individual or entity may be prohibited from making any funds, financial assets or economic resources or related services available for the benefit of the designated individuals/ entities or any other person engaged in or suspected to be engaged in terrorism. The Central [designated] Nodal Officer for the UAPA shall also forward a copy of the order to all Directors General of Police/ Commissioners of Police of all States/UTs  for  initiating  action  under  the  provisions  of  the  Unlawful  Activities (Prevention) Act, 1967.

The order shall be issued without prior notice to the designated individual/entity.

## 6. Regarding  financial  assets  or  economic  resources  of  the  nature  of immovable properties:

6.1 The Central [designated] Nodal Officer for the UAPA shall electronically forward the designated list to the UAPA Nodal Officers of all States and UTs with request to have  the  names  of  the  designated  individuals/entities,  on  the  given  parameters, verified  from  the  records  of  the  office  of  the  Registrar  performing  the  work  of registration of immovable properties in their respective jurisdiction, without delay.

6.2 In  case,  the  designated  individuals/entities  are  holding  financial  assets  or economic resources of the nature of immovable property and if any match with the designated individuals/entities is found, the UAPA Nodal Officer of the State/UT would cause communication of the complete particulars of such individual/entity along with complete  details  of  the  financial  assets  or  economic  resources  of  the  nature  of immovable property to the Central [designated] Nodal Officer for the UAPA without delay at Fax No. 011-23092551 and also convey over telephone No. 011-23092548. The particulars apart from being sent by post would necessarily be conveyed on email id: jsctcr-mha@gov.in .

6.3 The  UAPA  Nodal  Officer  of  the  State/UT  may  cause  such  inquiry  to  be conducted by the State Police so as to ensure that the particulars sent by the Registrar performing  the  work  of  registering  immovable  properties  are  indeed  of  these designated individuals/entities. This verification shall be completed without delay and shall be conveyed within 24 hours of the verification, if it matches with the particulars of  the  designated  individual/entity  to  the  Central  [designated]  Nodal  Officer  for  the UAPA at the given Fax, telephone numbers and also on the email id.

6.4 The  Central  [designated]  Nodal  Officer  for  the  UAPA  may  also  have  the verification conducted by the Central Agencies. This verification would be completed expeditiously.

6.5 In  case,  the  results  of  the  verification  indicates  that  the  particulars  match with those of designated individuals/entities, an order under Section 51A of the UAPA shall be issued by the Central [designated] Nodal Officer for the UAPA without delay and  conveyed  to  the  concerned  Registrar  performing  the  work  of  registering immovable properties and to FIU-IND under intimation to the concerned UAPA Nodal Officer of the State/UT.

<!-- RBI_PAGE:78 -->

The order shall be issued without prior notice to the designated individual/entity.

6.6 Further, the UAPA Nodal Officer of the State/UT shall cause to monitor the transactions/  accounts  of  the  designated  individual/entity  so  as  to  prohibit  any individual or entity from making any funds, financial assets or economic resources or related  services  available  for  the  benefit  of  the  individuals  or  entities  listed  in  the Schedule to the Order or any other person engaged in or suspected to be engaged in terrorism. The UAPA Nodal Officer of the State/UT shall, upon becoming aware of any transactions  and  attempts  by  third  party  immediately  bring  to  the  notice  of  the DGP/Commissioner of Police of the State/UT for initiating action under the provisions of the Unlawful Activities (Prevention) Act, 1967.

## 7. Regarding  the  real-estate  agents,  dealers  of  precious  metals/stones (DPMS)  and  other  Designated  Non-Financial  Businesses  and  Professions (DNFBPs) and any other person:

(i) The Designated Non-Financial Businesses and Professions (DNFBPs), inter alia, include casinos, real estate agents, dealers in precious metals/stones (DPMS), lawyers/notaries, accountants, company service providers and societies/ firms and non-profit  organizations.    The  list  of  designated  entities/individuals  should  be circulated to all DNFBPs by the concerned Regulators without delay.

(a)    The  DNFBPs  are  required  to  ensure  that  if  any  designated  individual/entity approaches  them  for  a  transaction  or  relationship  or  attempts  to  undertake  such transactions, the dealer should not carry out such transactions and, without delay, inform the UAPA Nodal officer of the State/UT with details of the funds/assets held and the details of the transaction, who in turn would follow the same procedure as in para 6.2 to 6.6 above. Further, if the dealers hold any assets or funds of the designated individual/entity, either directly or indirectly, they shall freeze the same without delay and inform the UAPA Nodal officer of the State/UT.

(ii) The CBIC shall advise the dealers of precious metals/stones (DPMS) that if any  designated  individual/entity  approaches  them  for  sale/purchase  of  precious metals/stones or attempts to undertake such transactions the dealer should not carry out such transaction and without delay inform the CBIC, who in turn follow the similar procedure as laid down in the paragraphs 6.2 to 6.5 above.

(iii) The UAPA Nodal Officer of the State/UT shall advise the Registrar of Societies/ Firms/ non-profit organizations that if any designated individual/ entity is a shareholder/ member/ partner/ director/ settler/ trustee/ beneficiary/ beneficial owner of  any  society/  partnership  firm/  trust/  non-profit  organization,  then  the  Registrar should inform the UAPA Nodal Officer of the State/UT without delay, who will, in turn, follow the procedure as laid down in the paragraphs 6.2 to 6.5 above. The Registrar should also be advised that no societies/ firms/ non-profit organizations should be allowed to be registered, if any of the designated individual/ entity is a director/ partner/ office bearer/ trustee/ settler/ beneficiary or beneficial owner of such juridical person and in case such request is received, then the Registrar shall inform the UAPA Nodal Officer of the concerned State/UT without delay, who will, in turn, follow the procedure laid down in the  paragraphs 6.2 to 6.5 above.

<!-- RBI_PAGE:79 -->

(iv) The  UAPA  Nodal  Officer  of  the  State/UT  shall  also  advise  appropriate department  of  the  State/UT,  administering  the  operations  relating  to  Casinos,  to ensure that the designated individuals/ entities should not be allowed to own or have beneficial ownership in any Casino operation. Further, if any designated individual/ entity visits or participates in any game in the Casino and/ or if any assets of such designated individual/ entity is with the Casino operator, and of the particulars of any client  matches  with  the  particulars  of  designated  individuals/  entities,  the  Casino owner shall inform the UAPA Nodal Officer of the State/UT without delay, who shall in turn follow the procedure laid down in paragraph 6.2 to 6.5 above.

(v) The Ministry of Corporate Affairs shall issue an appropriate order to the Institute of Chartered Accountants of India, Institute of Cost and Works Accountants of India and Institute of Company Secretaries of India (ICSI) requesting them to sensitize their respective  members  to  the  provisions  of  Section  51A  of  UAPA,  so  that  if  any designated individual/entity approaches them, for entering/ investing in the financial sector  and/or  immovable  property,  or  they  are  holding  or  managing  any  assets/ resources  of  Designated  individual/  entities,  then  the  member  shall  convey  the complete details of such designated individual/ entity to UAPA Nodal Officer in the Ministry of Corporate Affairs who shall in turn follow the similar procedure as laid down in paragraph 6.2 to 6.5  above.

(vi) The members of these institutes should also be sensitized that if they have arranged for or have been approached for incorporation/ formation/ registration of any company, limited liability firm, partnership firm, society, trust, association where any of  designated  individual/  entity  is  a  director/  shareholder/  member  of  a  company/ society/ association or partner in a firm or settler/ trustee or beneficiary of a trust or a beneficial owner of a juridical person, then the member of the institute  should not incorporate/  form/  register  such  juridical  person  and  should  convey  the  complete details of such designated individual/ entity to UAPA Nodal Officer in the Ministry of Corporate  Affairs  who  shall  in  turn  follow  the  similar  procedure  as  laid  down  in paragraph 6.2 to 6.5 above.

(vii) In addition, the member of the ICSI be sensitized that if he/she is Company Secretary or is holding any managerial position where any of designated individual/ entity  is  a  Director  and/or  Shareholder  or  having  beneficial  ownership  of  any  such juridical  person  then  the  member  should  convey  the  complete  details  of  such designated individual/ entity to UAPA Nodal Officer in the Ministry of Corporate Affairs who shall in turn follow the similar procedure as laid down in paragraph 6.2 to 6.5 above.

(viii) The  Registrar  of  Companies  (ROC)  may  be  advised  that  in  case  any designated  individual/  entity  is  a  shareholder/  director/  whole  time  director  in  any company registered with ROC or beneficial owner of such company, then the ROC should convey the complete details of such designated individual/ entity, as per the procedure  mentioned  in  paragraph  8  to  10  above.  This  procedure  shall  also  be followed  in  case  of  any  designated  individual/  entity  being  a  partner  of  Limited Liabilities Partnership Firms registered with ROC or beneficial owner of such firms. Further the ROC may be advised that no company or limited liability Partnership firm shall  be  allowed  to  be  registered  if  any  of  the  designated  individual/  entity  is  the Director/ Promoter/ Partner or beneficial owner of such company or firm and in case such a request received the ROC should inform the UAPA Nodal Officer in the Ministry of  Corporate  Affairs  who  in  turn  shall  follow  the  similar  procedure  as  laid  down  in paragraph 6.2 to 6.5 above.

<!-- RBI_PAGE:80 -->

(ix)    Any person, either directly or indirectly, holding any funds or other assets of designated individuals or entities, shall, without delay and without prior notice, cause to freeze any transaction in relation to such funds or assets, by immediately informing the nearest Police Station, which shall, in turn, inform the concerned UAPA Nodal Officer of the State/UT along with the details of the funds/assets held. The concerned UAPA Nodal Officer of the State/UT, would follow the same procedure as in para 6.2 to 6.6 above.

## 8. Regarding implementation of requests received from foreign countries under U.N. Security Council Resolution 1373 of 2001:

8.1 The U.N. Security Council Resolution No.1373 of 2001 obligates countries to freeze without delay the funds or other assets of persons who commit, or attempt to commit, terrorist acts or participate in or facilitate the commission of terrorist acts; of entities owned or controlled directly or indirectly by such persons; and of persons and entities acting on behalf of, or at the direction of such persons and entities, including funds or other assets derived or generated from property owned or controlled, directly or indirectly, by such persons and associated persons and entities. Each individual country has the authority to designate the persons and entities that should have their funds  or  other  assets  frozen.  Additionally,  to  ensure  that  effective  cooperation  is developed  among  countries,  countries  should  examine  and  give  effect  to,  if appropriate, the actions initiated under the freezing mechanisms of other countries.

8.2 To  give  effect  to  the  requests  of  foreign  countries  under  the  U.N.  Security Council Resolution 1373, the Ministry of External Affairs shall examine the requests made by the foreign countries and forward it electronically, with their comments, to the Central [designated] Nodal Officer for the UAPA for freezing of funds or other assets.

8.3 The Central [designated] Nodal Officer for the UAPA shall cause the request to be examined without delay, so as to satisfy itself that on the basis of applicable legal principles,  the  requested  designation  is  supported  by  reasonable  grounds,  or  a reasonable basis, to suspect or believe that the proposed designee is a terrorist, one who finances terrorism or a terrorist organization, and upon his satisfaction, request would be electronically forwarded to the Nodal Officers in Regulators, FIU-IND and to the Nodal Officers of the States/UTs. The proposed designee, as mentioned above would be treated as designated individuals/entities.

9. Upon  receipt  of  the  requests  by  these  Nodal  Officers  from  the  Central [designated]  Nodal  Officer  for  the  UAPA,  the  similar  procedure  as  enumerated  at paragraphs 5 and 6 above shall be followed.

The  freezing  orders  shall  be  issued  without  prior  notice  to  the  designated persons involved.

## 10. Regarding exemption, to be granted to the above orders in accordance with UNSCR 1452.

<!-- RBI_PAGE:81 -->

10.1 The above provisions shall not apply to funds and other  financial  assets  or  economic  resources  that  have  been  determined  by  the Central [designated] nodal officer of the UAPA to be:-

(a) necessary  for basic expenses,  including payments  for foodstuff, rent or mortgage, medicines and medical treatment, taxes, insurance premiums and public utility  charges,  or  exclusively  for  payment  of  reasonable  professional  fees  and reimbursement of incurred expenses associated with the provision of legal services or fees or service charges for routine holding or maintenance of frozen funds or other financial assets or economic resources, after notification by the MEA of the intention to authorize, where appropriate, access to such funds, assets or resources and in the absence of a negative decision within 48 hours of such notification;

(b) necessary for extraordinary expenses, provided that such determination has been notified by the MEA;

10.2. The addition may be allowed to accounts of the designated individuals/ entities subject to the provisions of paragraph 10 of:

## (a)   interest or other earnings due on those accounts, or

(b)  payments  due  under  contracts,  agreements  or  obligations  that  arose  prior to the date on which those accounts became subject to the provisions of resolutions 1267 (1999), 1333 (2000), or 1390 (2002),

Provided that any such interest, other earnings and payments continue to be subject to those provisions;

10.3 (a): The designated individual or organization may submit a request to the Central [Designated] Nodal Officer for UAPA under the provisions of Para 10.1 above. The Central [Designated] Nodal Officer for UAPA may be approached by post at 'Joint Secretary  (CTCR),  North  Block,  New  Delhi  -  110001'  or  through  email  to  jsctcrmha@gov.in'

(b): The Central [Designated] Nodal Officer for UAPA shall examine such requests, in consultation with the Law Enforcement Agencies and other Security Agencies and Intelligence Agencies and, if accepted, communicate the same, if applicable, to the Ministry  of  External  Affairs,  Government  of  India  for  notifying  the  committee established pursuant to UNSC Resolution 1267 (1999) of the intention to authorize, access to such funds, assets or resources in terms of Para 10.1 above.

## 11. Regarding  procedure  for  unfreezing  of funds, financial assets or economic  resources  or  related  services  of  individuals/entities  inadvertently affected by the freezing mechanism upon verification that the person or entity is not a designated person:

11.1 Any  individual  or  entity,  if  it  has  evidence  to  prove  that  the  freezing  of funds, financial assets or economic resources or related services, owned/held by them has  been  inadvertently  frozen,  they  shall  move  an  application  giving  the  requisite evidence, in writing, to the concerned  bank, stock exchanges/  depositories, intermediaries  regulated  by  SEBI,  insurance  companies,  Registrar  of  Immovable Properties, ROC, Regulators of DNFBPs and the UAPA Nodal Officers of State/UT.

<!-- RBI_PAGE:82 -->

11.2 The banks, stock exchanges/depositories, intermediaries regulated by SEBI, insurance companies, Registrar of Immovable Properties, ROC, Regulators of DNFBPs and the State/ UT Nodal Officers shall inform and forward a copy of the application together with full details of the asset frozen given by any individual or entity informing of the funds, financial assets or economic resources or related services have been frozen inadvertently, to the Central [designated] Nodal Officer for the UAPA as per the contact details given in Paragraph 3.1 above, within two working days.

11.3 The  Central  [designated]  Nodal  Officer  for  the  UAPA  shall  cause  such verification,  as  may  be  required  on  the  basis  of  the  evidence  furnished  by  the individual/entity, and, if satisfied, he/she shall pass an order, without delay, unfreezing the funds, financial assets or economic resources or related services, owned/held by such applicant, under intimation to the concerned bank, stock exchanges/depositories,  intermediaries  regulated  by  SEBI,  insurance  company, Registrar of Immovable Properties, ROC, Regulators of DNFBPs and the UAPA Nodal Officer of State/UT. However, if it is not possible for any reason to pass an Order unfreezing the assets within 5 working days, the Central [designated] Nodal Officer for the UAPA shall inform the applicant expeditiously.

## 11A. Regarding procedure for unfreezing of funds, financial assets or economic resources  or  related  services  of  individuals/organisations  in  the  event  of delisting by the UNSCR 1267 (1999), 1988 (2011) and 1989 (2011) Committee

Upon making an application in writing by the concerned individual/organisation, to the concerned  bank,  stock  exchanges/depositories,  intermediaries  regulated  by  SEBI, insurance  companies,  Registrar  of  Immovable  Properties,  RoC,  Regulators  of DNFBPs, Department of Posts and the UAPA Nodal Officers of all States/UTs., who in turn shall forward the application along with the full details of the assets frozen to the Central [Designated] Nodal Officer for UAPA within two working days. The Central [Designated] Nodal Officer for UAPA shall examine the request in consultation with the  Law  Enforcement  Agencies  and  other  Security  Agencies  and  Intelligence Agencies and cause such verification as may be required and if satisfied, shall pass an order, without delay, unfreezing the funds, financial assets or economic resources or related services owned or held by the applicant under intimation to concerned bank, stock exchanges/ depositories, intermediaries regulated by SEBI, insurance companies,  Registrar  of  Immovable  Properties,  RoC,  Regulators  of  DNFBPs, Department of Posts and the UAPA Nodal Officers of all States/UTs.

## 12. Regarding prevention of entry into or transit through India:

12.1 As regards prevention of entry into or transit through India of the designated individuals, the UAPA Nodal Officer in the Foreigners Division of MHA, shall forward the designated lists to the immigration authorities and security agencies with a request to prevent the entry into or the transit through India. The order shall take place without prior notice to the designated individuals/entities.

12.2 The immigration authorities shall ensure strict compliance of the order and also communicate the details of entry or transit through India of the designated individuals as prevented by them to the UAPA Nodal Officer in Foreigners Division of MHA.

## 13. Procedure  for  communication  of  compliance  of  action  taken  under Section 51A: The Central [designated] Nodal Officer for the UAPA and the Nodal

<!-- RBI_PAGE:83 -->

Officer in the Foreigners Division, MHA shall furnish the details of funds, financial assets or economic resources or related services of designated individuals/entities frozen by an order, and details of the individuals whose entry into India or transit through  India  was  prevented,  respectively,  to  the  Ministry  of  External  Affairs  for onward communication to the United Nations.

14. Communication  of  the  Order  issued  under  Section  51A  of  Unlawful Activities (Prevention) Act, 1967: The order issued under Section 51A of the Unlawful Activities (Prevention) Act, 1967 by the Central [designated] Nodal Officer for  the  UAPA relating to funds,  financial assets or economic resources or related services, shall be communicated to all the UAPA nodal officers in the country, the Regulators of Financial Services, FIU-IND and DNFBPs, banks, depositories/stock exchanges,  intermediaries  regulated  by  SEBI,  Registrars  performing  the  work  of registering immovable properties through the UAPA Nodal Officer of the State/UT.

15. All concerned are requested to ensure strict compliance of this order.

(Ashutosh Agnihotri) Joint Secretary to the Government of India

To,

- 1)  Governor, Reserve Bank of India, Mumbai
- 2)  Chairman, Securities &amp; Exchange Board of India, Mumbai
- 3)  Chairman, Insurance Regulatory and Development Authority, Hyderabad.
- 4)  Foreign Secretary, Ministry of External Affairs, New Delhi.
- 5)  Finance Secretary, Ministry of Finance, New Delhi.
- 6)  Revenue Secretary, Department of Revenue, Ministry of Finance, New Delhi.
- 7) Secretary, Ministry of Corporate Affairs, New Delhi
- 8)  Chairman, Central Board of Indirect Taxes &amp; Customs, New Delhi.
- 9)  Director, Intelligence Bureau, New Delhi.
- 10)  Additional Secretary, Department of Financial Services, Ministry of Finance, New Delhi.
- 11)  Chief Secretaries of all States/Union Territories
- 12)  Principal Secretary (Home)/Secretary (Home) of all States/ Union Territories
- 13)  Directors General of Police of all States &amp; Union Territories
- 14)  Director General of Police, National Investigation Agency, New Delhi.
- 15)  Commissioner of Police, Delhi.
- 16)  Joint Secretary (Foreigners), Ministry of Home Affairs, New Delhi.
- 17)  Joint Secretary (Capital Markets), Department of Economic Affairs, Ministry of Finance, New Delhi.
- 18)  Joint Secretary (Revenue), Department of Revenue, Ministry of Finance, New Delhi.
- 19)  Director (FIU-IND), New Delhi.

Copy for information to: -

1. Sr. PPS to HS
2. PS to SS (IS)

<!-- RBI_PAGE:84 -->

## 164 Annex III

## F.No.P - 12011/14/2022-ES Cell-DOR Government of India Ministry of Finance Department of Revenue

***

[New Delhi, dated the 1 st  September, 2023](https://rbidocs.rbi.org.in/rdocs/content/pdfs/WMDSeptember012023_17102023.pdf)

## ORDER

Subject:  -  Procedure  for  implementation  of  Section  12A  of  'The  Weapons  of Mass Destruction and their Delivery Systems (Prohibition of Unlawful Activities) Act, 2005' .

Section  12A  of  The  Weapons  of  Mass  Destruction  and  their  Delivery  Systems (Prohibition of Unlawful Activities) Act, 2005 [hereinafter referred to as 'the Act'] reads as under: -

" 12A.  (1)  No  person  shall  finance  any  activity  which  is  prohibited  under  this Act, or under the United Nations (Security Council) Act, 1947 or any other relevant Act for the time being in force, or by an order issued under any such Act, in relation to weapons of mass destruction and their delivery systems.

(2)  For  prevention  of  financing  by  any  person  of  any  activity  which  is  prohibited under this Act, or under the United Nations (Security Council) Act, 1947 or any other relevant Act for the time being in force, or by an order issued under any such Act, in relation  to  weapons  of  mass  destruction  and  their  delivery  systems,  the  Central Government shall have power to-

- a) freeze, seize or attach funds or other financial assets or economic resources-
- i. owned  or  controlled,  wholly  or  jointly,  directly  or  indirectly,  by  such person; or
- ii. held by or on behalf of, or at the direction of, such person; or
- iii. derived or generated from the funds or other assets owned or controlled, directly or indirectly, by such person;

prohibit any person from making funds, financial assets or economic resources or related services available for the benefit of persons related to any activity which is prohibited under this Act, or under the United Nations (Security Council) Act, 1947 or any other relevant Act for the time being in force, or by an order issued under any such Act, in relation to weapons of mass destruction and their delivery systems.

[164  Inserted vide circular DOR.AML.REC.111/14.01.001/2023-24 dated April 28, 2023.](https://www.rbi.org.in/Scripts/NotificationUser.aspx?Id=12497&Mode=0)

<!-- RBI_PAGE:85 -->

(3) The Central Government may exercise its powers under this section through any authority who has been assigned the power under sub-section (1) of section 7. '

II In order to ensure expeditious and effective implementation of the provisions of Section 12A of the Act, the procedure is outlined below.

## 1. Appointment and communication details of Section 12A Nodal Officers:

1.1  In  exercise  of  the  powers  conferred  under  Section  7(1)  of  the  Act,  the  Central Government  assigns      Director,  FIU-India,  Department  of  Revenue,  Ministry  of Finance,  as  the  authority  to  exercise  powers  under  Section  12A  of  the  Act.  The Director, FIU-India shall be hereby referred to as the Central Nodal Officer (CNO) for the purpose of this order. [Telephone Number: 01123314458, 011- 23314435, 01123314459 (FAX), email address: dir@fiuindia.gov.in].

1.2 Regulator under this order shall have the same meaning as defined in Rule 2(fa) of Prevention of Money-Laundering (Maintenance of Records) Rules, 2005. Reporting Entity (RE) shall have the same meaning as defined in Section 2 (1) (wa) of Prevention of  Money-Laundering  Act,  2002.  DNFPBs  is  as  defined  in  section  2(1)  (sa)  of Prevention of Money-Laundering Act, 2002.

1.3 The Regulators, Ministry of Corporate Affairs and Foreigners Division of MHA shall notify a Nodal Officer for implementation of provisions of Section 12A of the Act. The Regulator may notify the Nodal Officer appointed for implementation of provisions of Section 51A of UAPA, also, as the Nodal Officer for implementation of Section 12A of the Act. All the States and UTs shall notify a State Nodal officer for implementation of Section 12A of the Act. A State/UT may notify the State Nodal Officer appointed for implementation of provisions of Section 51A of UAPA, also, as the Nodal Officer for implementation of Section 12A of the Act.

1.4 The CNO shall maintain an updated list of all Nodal Officers, and share the updated list with all Nodal Officers periodically. The CNO shall forward the updated list of all Nodal Officers to all REs.

## 2.  Communication of the lists of designated individuals/entities:

2.1 The Ministry of External Affairs will electronically communicate, without delay, the changes made in the list of designated individuals and entities (hereinafter referred to as 'designated list') in line with section 12A (1) to the CNO and Nodal officers.

2.1.1 Further, the CNO shall maintain the Designated list on the portal of FIU-India. The list would be updated by the CNO, as and when it is updated, as per para 2.1 above, without delay. It shall make available for all Nodal officers, the State Nodal Officers,  and  to  the  Registrars  performing  the  work  of  registration  of  immovable properties, either directly or through State Nodal Officers, without delay.

2.1.2  The  Ministry  of  External  Affairs  may  also  share  other  information  relating  to prohibition / prevention of financing of prohibited activity under Section 12A (after its initial  assessment  of  the  relevant  factors  in  the  case)  with  the  CNO  and  other organizations concerned, for initiating verification and suitable action.

<!-- RBI_PAGE:86 -->

2.1.3 The Regulators shall make available the updated designated list, without delay, to their REs. The REs will maintain the designated list and update it, without delay, whenever changes are made as per para 2.1 above.

2.2 The Nodal Officer for Section 12A in Foreigners Division of MHA shall forward the updated designated list to the immigration authorities and security agencies, without delay.

## 3. Regarding funds, financial assets or economic resources or related services held in the form of bank accounts, stocks or insurance policies, etc.

## 3.1 All Financial Institutions shall -

- i. Verify if the particulars of the entities/individual, party to the financial transactions, match with the particulars of designated list and in case of match, REs  shall  not  carry  out  such  transaction  and  shall  immediately  inform  the transaction details with full particulars of the funds, financial assets or economic resources involved to the CNO by email, FAX and by post, without delay.
- ii. Run a check, on the given parameters, at the time of establishing a relation with a customer and on a periodic basis to verify whether individuals and entities in the  designated  list  are  holding  any  funds,  financial  assets  or  economic resources or related services, in the form of bank accounts, stocks, Insurance policies etc. In case, the particulars of any of their customers match with the particulars of designated list, REs shall immediately inform full particulars of the funds, financial assets or economic resources or related services held in the form of bank accounts, stocks or insurance policies etc., held on their books to the CNO by email, FAX and by post, without delay.
- iii. The REs shall also send a copy of the communication, mentioned in 3.1 (i) and (ii) above, to State Nodal Officer, where the account/transaction is held, and to their Regulator, as the case may be, without delay.
- iv. In case there are reasons to believe beyond doubt that funds or assets held by a customer would fall under the purview of clause (a) or (b) of sub-section (2) of Section 12A, REs shall prevent such individual/entity from conducting financial transactions, under intimation to the CNO by email, FAX and by post , without delay.

3.2 On receipt of the particulars, as referred to in Paragraph 3.1 above, the CNO would cause a verification to be conducted by the State Police and/or the Central Agencies so  as  to  ensure  that  the  individuals/entities  identified  by  the  REs  are  the  ones  in designated  list  and  the  funds,  financial  assets  or  economic  resources  or  related services, reported by REs are in respect of the designated individuals/entities. This verification  would  be  completed  expeditiously  from  the  date  of  receipt  of  such particulars.

3.3 In case, the results of the verification indicate that the assets are owned by, or are held  for  the  benefit  of,  the  designated  individuals/entities,  an  order  to  freeze  these assets under Section 12A would be issued by the CNO without delay and be conveyed electronically to the concerned RE under intimation to respective Regulators. The CNO shall also forward a copy thereof to all the Principal Secretaries/Secretaries, Home Department  of  the  States/UTs  and  All  Nodal  officers  in  the  country,  so  that  any individual  or  entity  may  be  prohibited  from  making  any  funds,  financial  assets  or economic  resources  or  related  services  available  for  the  benefit  of  the  designated individuals / entities. The CNO shall also forward a copy of the order to all Directors General  of  Police/  Commissioners  of  Police  of  all  States/UTs  for  initiating  suitable action.

<!-- RBI_PAGE:87 -->

3.4 The order shall be issued without prior notice to the designated individual/entity.

## 4. Regarding financial assets or economic resources of the nature of immovable properties:

4.1 The Registrars performing work of registration of immovable properties shall --

- i. Verify if the particulars of the entities/individual, party to the transactions, match with the particulars of the designated list, and, in case of match, shall not carry out such transaction and immediately inform the details with full particulars of the assets or economic resources involved to the State Nodal Officer, without delay.
- ii. Verify from the records in their respective jurisdiction, without delay, on given parameters, if the details match with the details of the individuals and entities in the  designated  list.  In  case,  the  designated  individuals/entities  are  holding financial assets or economic resources of the nature of immovable property, and if any match with the designated individuals/entities is found, the Registrar shall  immediately  inform  the  details  with  full  particulars  of  the  assets  or economic resources involved to the State Nodal Officer, without delay.
- iii. In case there are reasons to believe beyond doubt that assets that are held by an  individual/entity  would  fall  under  the  purview  of  clause  (a)  or  (b)  of  subsection (2) of Section 12A, Registrar shall prevent such individual/entity from conducting transactions, under intimation to the State Nodal Officer by email, FAX and by post , without delay.

4.2 the State Nodal Officer would cause communication of the complete particulars of such individual/entity along with complete details of the financial assets or economic resources to the CNO without delay by email, FAX and by post.

4.3  The  State  Nodal  Officer  may  cause  such  inquiry  to  be  conducted  by  the  State Police  so  as  to  ensure  that  the  particulars  sent  are  indeed  of  these  designated individuals/entities.  This  verification  shall  be  completed  without  delay  and  shall  be conveyed, within 24 hours of the verification, if it matches, with the particulars of the designated individual/entity, to the CNO without delay by email, FAX and by post.

4.4 The CNO may also have the verification conducted by the Central Agencies. This verification would be completed expeditiously.

4.5 In case, the results of the verification indicate that the assets are owned by, or are held  for  the  benefit  of,  the  designated  individuals/entities,  an  order  to  freeze  these assets under Section 12A would be issued by the CNO without delay and be conveyed electronically to the concerned Registrar performing the work of registering immovable properties, and to FIU under intimation to the concerned State Nodal Officer. The CNO shall also forward a copy thereof to all the Principal Secretaries/Secretaries, Home Department  of  the  States/UTs  and  All  Nodal  officers  in  the  country,  so  that  any individual  or  entity  may  be  prohibited  from  making  any  funds,  financial  assets  or economic  resources  or  related  services  available  for  the  benefit  of  the  designated individuals / entities. The CNO shall also forward a copy of the order to all Directors General  of  Police/  Commissioners  of  Police  of  all  States/UTs  for  initiating  suitable action.

<!-- RBI_PAGE:88 -->

4.6 The order shall be issued without prior notice to the designated individual/entity.

## 5. Regarding  the  real-estate  agents,  dealers  of  precious  metals/stones (DPMS), Registrar of Societies/ Firms/ non-profit organizations, The Ministry of Corporate Affairs and Designated Non-Financial Businesses and Professions (DNFBPs):

(i) The dealers of precious metals/stones (DPMS) as notified under PML (Maintenance of  Records)  Rules,  2005  and  Real  Estate  Agents,  as  notified  under  clause  (vi)  of Section 2(1) (sa) of Prevention of Money-Laundering Act, 2002, are required to ensure that if any designated individual/entity approaches them for sale/purchase of precious metals/stones/Real  Estate  Assets  or  attempts  to  undertake  such  transactions,  the dealer should not carry out such transaction and, without delay, inform the Section 12A Nodal officer in the Central Board of Indirect Taxes and Customs (CBIC). Also, If the dealers hold any assets or funds of the designated individual/entity, they shall freeze the same without delay and inform the Section 12A Nodal officer in the CBIC, who will, in  turn,  follow  procedure  similar  to  as  laid  down  for  State  Nodal  Officer  in  the paragraphs 4.2 to 4.6.

(ii) Registrar of Societies/ Firms/ non-profit organizations are required to ensure that if any designated individual/ entity is a shareholder/ member/ partner/ director/ settler/ trustee/ beneficiary/ beneficial owner of any society/ partnership firm/ trust/ non-profit organization,  then  the  Registrar  shall  freeze  any  transaction  for  such  designated individual/ entity and shall inform the State Nodal Officer, without delay, and, if such society/  partnership  firm/  trust/  non-profit  organization  holds  funds  or  assets  of designated individual/ entity, follow the procedure as laid down for State Nodal Officer in the paragraphs 4.2 to 4.6 above. The Registrar should also ensure that no societies/ firms/  non-profit  organizations  should  be  allowed  to  be  registered  if  any  of  the designated  individual/  entity  is  a  director/  partner/  office  bearer/  trustee/  settler/ beneficiary or beneficial owner of such juridical person and, in case, such request is received, then the Registrar shall inform the State Nodal Officer, without delay.

(iii) The State Nodal Officer shall also advise appropriate department of the State/UT, administering  the  operations  relating  to  Casinos,  to  ensure  that  the  designated individuals/ entities should not be allowed to own or have beneficial ownership in any Casino operation. Further, if any designated individual/ entity visits or participates in any game in the Casino or if any assets of such designated individual/ entity are with the Casino operator, or if the particulars of any client match with the particulars of designated individuals/ entities, the Casino owner shall inform the State Nodal Officer, without delay, and shall freeze any such transaction.

<!-- RBI_PAGE:89 -->

(iv) The Ministry of Corporate Affairs shall issue an appropriate order to the Institute of Chartered Accountants of India, Institute of Cost and Works Accountants of India and Institute  of  Company  Secretaries  of  India  (ICSI),  requesting  them  to  sensitize  their respective  members  to  the  provisions  of  Section  12A,  so  that,  if  any  designated individual/entity approaches them, for entering/ investing in the financial sector and/or immovable  property,  or  they  are  holding  or  managing  any  assets/  resources  of designated individual/ entities, then the member shall convey the complete details of such  designated  individual/  entity  to  Section  12A  Nodal  Officer  in  the  Ministry  of Corporate Affairs, who shall in turn follow the similar procedure as laid down for State Nodal Officer in paragraph 4.2 to 4.6 above.

(v)  The  members  of  these  institutes  should  also  be  sensitized  by  the  Institute  of Chartered Accountants of India, Institute of Cost and Work Accountants of India and Institute of Company Secretaries of India (ICSI) that if they have arranged for or have been  approached  for  incorporation/  formation/  registration  of  any  company,  limited liability  firm,  partnership  firm,  society,  trust,  association  where  any  designated individual/ entity is a director/ shareholder/ member of a company/ society/ association or partner in a firm or settler/ trustee or beneficiary of a trust or a beneficial owner of a juridical person, then the member of the institute should not incorporate/ form/ register such  juridical  person  and  should  convey  the  complete  details  of  such  designated individual/ entity to Section 12A Nodal Officer in the Ministry of Corporate Affairs.

(vi) In addition, a member of the ICSI shall, if he/she is Company Secretary or is holding any managerial position where any of designated individual/ entity is a Director and/or Shareholder or having beneficial ownership of any such juridical person, convey the complete details of such designated individual/ entity to Section 12A Nodal Officer in the Ministry of Corporate Affairs, who shall follow the similar procedure as laid down in paragraph 4.2 to 4.6 above for State Nodal Officer, if such company, limited liability firm,  partnership  firm,  society,  trust,  or  association  holds  funds  or  assets  of  the designated individual/entity.

(vii) In  case  any  designated  individual/  entity  is  a  shareholder/  director/  whole  time director  in  any  company  registered  with  the  Registrar  of  Companies  (ROC)  or beneficial owner of such company or partner in a Limited Liabilities Partnership Firm registered  with  ROC  or  beneficial  owner  of  such  firm,  the  ROC  should  convey  the complete details of such designated individual/ entity to section 12A Nodal officer of Ministry of Corporate Affairs. If such company or LLP holds funds or assets of the designated  individual/  entity,  he  shall  follow  the  similar  procedure  as  laid  down  in paragraph 4.2 to 4.6 above for State Nodal Officer. Further the ROCs are required to ensure  that  no  company  or  limited  liability  Partnership  firm  shall  be  allowed  to  be registered if any of the designated individual/ entity is the Director/ Promoter/ Partner or beneficial owner of such company or firm, and in case such a request is received, the  ROC should inform the Section 12A Nodal Officer in the Ministry of Corporate Affairs.

(viii) All communications to Nodal officer as enunciated in subclauses (i) to (vii) above should,  inter  alia,  include  the  details  of  funds  and  assets  held  and  the  details  of transaction.

(ix) The Other DNBPs are required to ensure that if any designated individual/entity approaches  them  for  a  transaction  or  relationship  or  attempts  to  undertake  such transactions,  the  dealer  should  not  carry  out  such  transaction  and,  without  delay, inform the Section 12A Central Nodal officer. The communication to the Central Nodal Officer  would  include  the  details  of  funds  and  assets  held  and  the  details  of  the transaction.  Also,  If  the  dealers  hold  any  assets  or  funds  of  the  designated individual/entity, they shall freeze the same without delay and inform the Section 12A Central Nodal officer.

<!-- RBI_PAGE:90 -->

## (DNFBPs shall have the same meaning as the definition in Section 2(1) (sa) of Prevention of Money-Laundering Act,2002.)

5.1.  All  Natural  and  legal  persons  holding  any  funds  or  other  assets  of  designated persons  and  entities,  shall,  without  delay  and  without  prior  notice,  freeze  any transaction in relation to such funds or assets and shall immediately inform the State Nodal officer along with details of the funds/assets held, who in turn would follow the same procedure as in para 4.2 to 4.6 above for State Nodal Officer. This obligation should  extend  to  all  funds  or  other  assets  that  are  owned  or  controlled  by  the designated person or entity, and not just those that can be tied to a particular act, plot or threat of proliferation; those funds or other assets that are wholly or jointly owned or controlled, directly or indirectly, by designated persons or entities; and the funds or other  assets  derived  or  generated  from  funds  or  other  assets  owned  or  controlled directly or indirectly by designated persons or entities, as well as funds or other assets of persons and entities acting on behalf of, or at the direction of designated persons or entities.

5.2 No person shall finance any activity related to the 'designated list' referred to in Para 2.1, except in cases where exemption has been granted as per Para 6 of this Order.

5.3. Further, the State Nodal Officer shall cause to monitor the transactions / accounts of the designated individual/entity so as to prohibit any individual or entity from making any funds, financial assets or economic resources or related services available for the benefit of the individuals or entities in the designated list. The State Nodal Officer shall, upon becoming aware of any transactions and attempts by third party, without delay, bring the incidence to the notice of the CNO and the DGP/Commissioner of Police of the State/UT for initiating suitable action.

5.4 Where the CNO has reasons to believe that any funds or assets are violative of Section 12A (1) or Section 12A (2)(b) of the Act, he shall, by order, freeze such funds or Assets, without any delay, and make such order available to authorities, Financial Institutions, DNFBPs and other entities concerned.

5.5 The CNO shall also have the power to issue advisories and guidance to all persons, including Fls and DNFBPs obligated to carry out sanctions screening. The concerned Regulators shall take suitable action under their relevant laws, rules or regulations for each violation of sanction screening obligations under section 12A of the WMD Act.

## 6. Regarding exemption, to be granted to the above orders

6.1.  The  above provisions  shall  not  apply  to  funds  and  other  financial  assets  or economic resources that have been determined by the CNO to be: -

(a) necessary for basic expenses, including payments for foodstuff, rent or mortgage, medicines  and  medical  treatment,  taxes,  insurance  premiums  and  public  utility charges, or exclusively for payment of reasonable professional fees and reimbursement of incurred expenses associated with the provision of legal services or fees or service charges for routine holding or maintenance of frozen funds or other financial  assets  or  economic  resources,  consequent  to  notification  by  the  MEA authorizing access to such funds, assets or resources.

<!-- RBI_PAGE:91 -->

This shall be consequent to notification by the MEA to the UNSC or its Committee, of the  intention  to  authorize  access  to  such  funds,  assets  or  resources,  and  in  the absence of a negative decision by the UNSC or its Committee within 5 working days of such notification.

(b) necessary for extraordinary expenses, provided that such determination has been notified by the MEA to the UNSC or its Committee, and has been approved by the UNSC or its Committee;

6.2. The accounts of the designated individuals/ entities may be allowed to be credited with:

(a) interest or other earnings due on those accounts, or

(b) payments due under contracts, agreements or obligations that arose prior to the date on which those accounts became subject to the provisions of section 12A of the Act.

Provided that any such interest, other earnings and payments continue to be subject to those provisions under para 3.3;

6.3 Any freezing action taken related to the designated list under this Order should not prevent  a  designated  individual  or  entity  from  making  any  payment  due  under  a contract  entered  into  prior  to  the  listing  of  such  individual  or  entity,  provided that:

(i)  the CNO has determined that the contract is not related to any of the prohibited goods, services, technologies, or activities, under this Act, or under the United Nations (Security Council) Act, 1947 or any other relevant Act for the time being in force, or by an order issued under any such Act, in relation to weapons of mass destruction and their delivery systems;

(ii) the CNO has determined that the payment is not directly or indirectly received by an individual or entity in the designated list under this Order; and

(iii)  the  MEA  has  submitted  prior  notification  to  the  UNSC  or  its  Committee,  of the intention to make or receive such payments or to authorise, where appropriate, he unfreezing of funds, other financial assets or economic resources for this purpose, ten working days prior to such authorization

## 7. Regarding procedure for unfreezing of funds, financial assets or economic resources or related services of individuals/entities inadvertently affected by the freezing  mechanism  upon  verification  that  the  individual  or  entity  is  not  a designated person or no longer meet the criteria for designation:

7.1 Any individual/entity, if it has evidence to prove that the freezing of funds, financial assets or economic resources or related services, owned/held has been inadvertently frozen, an application may be moved giving the requisite evidence, in writing, to the relevant RE/Registrar of Immovable Properties/ ROC/Regulators and the State.

<!-- RBI_PAGE:92 -->

7.2 The RE/Registrar of Immovable Properties/ROC/Regulator and the State Nodal Officer shall inform, and forward a copy of the application, together with full details of the asset frozen, as given by applicant to the CNO by email, FAX and by Post, within two working days. Also, listed persons and entities may petition a request for delisting at the Focal Point Mechanism established under UNSC Resolution.

7.3 The CNO shall cause such verification, as may be required on the basis of the evidence  furnished  by  the  individual/entity,  and,  if  satisfied,  it  shall  pass  an  order, without delay, unfreezing the funds, financial assets or economic resources or related services,  owned/held  by  such  applicant,  under  intimation  to  all  RE/Registrar  of Immovable Properties/ROC/Regulators and the State Nodal Officer. However, if it is not possible, for any reason, to pass an Order unfreezing the assets within 5 working days, the CNO shall inform the applicant expeditiously.

7.4  The  CNO  shall,  based  on  de-listing  of  individual  and  entity  under  UN  Security Council Resolutions, shall pass an order, if not required to be designated in any other order, without delay, unfreezing the funds, financial assets or economic resources or related services, owned/held by such applicant, under intimation to all RE/Registrar of Immovable Properties/ROC/Regulators and the State Nodal Officer.

8. Procedure for communication of compliance of action taken under Section 12A: The CNO and the Nodal Officer in the Foreigners Division, MHA shall furnish the details  of  funds,  financial  assets  or  economic  resources  or  related  services  of designated individuals/entities, frozen by an order, and details of the individuals whose entry into India or transit through India was prevented, respectively, to the Ministry of External Affairs, for onward communication to the United Nations.

9. Communication of the Order issued under Section 12A: The Order issued under Section 12A of the Act by the CNO relating to funds, financial assets or economic resources  or  related  services,  shall  be  communicated  to  all  nodal  officers  in  the country.

10. This order is issued in suppression of F.No.P-12011/14/2022-ES Cell-DOR, dated 30 th  January 2023.

11.  All concerned are requested to ensure strict compliance of this order.

(Manoj Kumar Singh) Director (HQ)

To,

1)Governor, Reserve Bank of India, Mumbai

2)Chairman, Securities &amp; Exchange Board of India, Mumbai

3)Chairman, Insurance Regulatory and Development Authority, Hyderabad.

4)Foreign Secretary, Ministry of External Affairs, New Delhi.

5)Finance Secretary, Ministry of Finance, New Delhi.

<!-- RBI_PAGE:93 -->

- 6)Revenue Secretary, Department of Revenue, Ministry of Finance, New Delhi.
- 7)Secretary, Ministry of Corporate Affairs, New Delhi
- 8)Chairman, Central Board of Indirect Taxes &amp; Customs, New Delhi.
- 9)Director, Intelligence Bureau, New Delhi.
- 10)Additional Secretary, Department of Financial Services, Ministry of Finance, New Delhi.
- 11)Chief Secretaries of all States/Union Territories
- 12)Principal Secretary (Home)/Secretary (Home) of all States/ Union Territories
- 13)Directors General of Police of all States &amp; Union Territories
- 14)Director General of Police, National Investigation Agency, New Delhi.
- 15)Commissioner of Police, Delhi.
- 16)Joint Secretary (Foreigners), Ministry of Home Affairs, New Delhi.
- 17)Joint  Secretary  (Capital  Markets),  Department  of  Economic  Affairs,  Ministry  of Finance, New Delhi.
- 18)Joint  Secretary  (Revenue),  Department  of  Revenue,  Ministry  of  Finance,  New Delhi.
- 19)Director (FIU-IND), New Delhi.

Copy for information to: -

1. Sr. PPS to HS
2. PS to SS (IS)

<!-- RBI_PAGE:94 -->

Annex IV

## KYC documents for eligible FPIs under PIS

|                                                                     |                                                                                                     | FPI Type                                                                                  | FPI Type                                                                            | FPI Type                                                                                              |
|---------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------|
| Document Type                                                       | Document Type                                                                                       | Category I                                                                                | Category II                                                                         | Category III                                                                                          |
| Entity Level                                                        | Constitutive Documents (Memorandu m and Articles of Association, Certificate of Incorporation etc.) | Mandatory                                                                                 | Mandatory                                                                           | Mandatory                                                                                             |
| Entity Level                                                        | Proof of Address                                                                                    | Mandatory (Power of Attorney {PoA} mentioning the address is acceptable as address proof) | Mandatory (Power of Attorney mentioning the address is acceptable as address proof) | Mandatory other than Power of Attorney                                                                |
| Entity Level                                                        | PAN 165                                                                                             | Mandatory                                                                                 | Mandatory                                                                           | Mandatory                                                                                             |
| Entity Level                                                        | Financial Data                                                                                      | Exempted *                                                                                | Exempted *                                                                          | Mandatory                                                                                             |
| Entity Level                                                        | SEBI Registration Certificate                                                                       | Mandatory                                                                                 | Mandatory                                                                           | Mandatory                                                                                             |
| Entity Level                                                        | Board Resolution @@                                                                                 | Exempted *                                                                                | Mandatory                                                                           | Mandatory                                                                                             |
|                                                                     | List                                                                                                | Mandatory                                                                                 | Mandatory                                                                           | Mandatory                                                                                             |
| Senior Manageme nt (Whole Time Directors/ Partners/ Trustees/ etc.) | Proof of Identity                                                                                   | Exempted *                                                                                | Exempted *                                                                          | Entity declares* on letter head full name, nationality, date of birth or submits photo identity proof |
| Senior Manageme nt (Whole Time Directors/ Partners/ Trustees/ etc.) | Proof of Address                                                                                    | Exempted *                                                                                | Exempted *                                                                          | Declaration on Letter Head *                                                                          |

<!-- RBI_PAGE:95 -->

|                                 | Photographs         | Exempted                                                                                         | Exempted                                                                                         | Exempted *                   |
|---------------------------------|---------------------|--------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------|------------------------------|
| Authorized Signatories          | List and Signatures | Mandatory - list of Global Custodian signatories can be given in case of PoA to Global Custodian | Mandatory - list of Global Custodian signatories can be given in case of PoA to Global Custodian | Mandatory                    |
| Authorized Signatories          | Proof of Identity   | Exempted *                                                                                       | Exempted *                                                                                       | Mandatory                    |
| Authorized Signatories          | Proof of Address    | Exempted *                                                                                       | Exempted *                                                                                       | Declaration on Letter Head * |
| Authorized Signatories          | Photographs         | Exempted                                                                                         | Exempted                                                                                         | Exempted *                   |
| Ultimate Beneficial Owner (UBO) | List                | Exempted *                                                                                       | Mandatory                                                                                        | Mandatory                    |
|                                 | Proof of Identity   | Exempted *                                                                                       | Exempted *                                                                                       | Mandatory                    |
|                                 | Proof of Address    | Exempted *                                                                                       | Exempted *                                                                                       | Declaration on Letter Head * |
|                                 | Photographs         | Exempted                                                                                         | Exempted                                                                                         | Exempted *                   |

* Not required while opening the bank account. However, FPIs concerned may submit an  undertaking  that  upon  demand  by  Regulators/Law  Enforcement  Agencies  the relative document/s would be submitted to the bank.

@@ FPIs from certain jurisdictions where the practice of passing Board Resolution for the purpose of opening bank accounts etc. is not in vogue, may submit 'Power of Attorney granted to Global Custodian/Local Custodian in lieu of Board Resolution'

<!-- RBI_PAGE:96 -->

| Category   | Eligible Foreign Investors                                                                                                                                                                                                                                                                                                                                                                                                                                           |
|------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| I.         | Government and Government related foreign investors such as Foreign Central Banks, Governmental Agencies, Sovereign Wealth Funds, International/ Multilateral Organizations/ Agencies.                                                                                                                                                                                                                                                                               |
| II.        | a) Appropriately regulated broad based funds such as Mutual Funds, Investment Trusts, Insurance /Reinsurance Companies, Other Broad Based Funds etc. b) Appropriately regulated entities such as Banks, Asset Management Companies, Investment Managers/ Advisors, Portfolio Managers etc. c) Broad based funds whose investment manager is appropriately regulated. d) University Funds and Pension Funds. e) University related Endowments already registered with |
| III.       | All other eligible foreign investors investing in India under PIS route not eligible under Category I and II such as Endowments, Charitable Societies/Trust, Foundations, Corporate Bodies, Trusts, Individuals, Family Offices, etc.                                                                                                                                                                                                                                |

<!-- RBI_PAGE:97 -->

Appendix

## List of Circulars or part thereof repealed with the issuance of Master Direction

|   Sr. No. | Circular No.                         | Date               |
|-----------|--------------------------------------|--------------------|
|        1. | DBOD.BP.BC.92/C.469-76               | August 12, 1976    |
|        2. | DBOD.GC.BC.62/c.408(A)/87            | November 11, 1987  |
|        3. | DBOD.BP.BC.114/C.469 (81)-91         | April 19, 1991     |
|        4. | DBOD.FMC.No.153/27.01.003/93-94      | September 1, 1993  |
|        5. | DBOD.GC.BC.193/17.04.001/93          | November 18, 1993  |
|        6. | DBOD.GC.BC.202/17.04.001/93          | December 6, 1993   |
|        7. | DBOD.No.GC.BC.46/17.04.001           | April 22, 1994     |
|        8. | DBOD.BP.BC.106/21.01.001/94          | September 23,1994  |
|        9. | DBOD.BP.BC.102/21.01.001/95          | September 20, 1995 |
|       10. | DBOD.BP.BC.42/21.01.001/96           | April 6, 1996      |
|       11. | DBOD.No.BP.BC.12/21.01.023/98        | February 11, 1998  |
|       12. | DBOD.BP.52/21.01.001/2001-02         | December 5, 2001   |
|       13. | DBOD.AML.BC.89/14.01.001/2001-02     | April 15, 2002     |
|       14. | DBOD.AML.BC.No.102/14.01.001/2001-02 | May 10, 2002       |
|       15. | DBOD.AML.BC.18/14.01.001/2002-03     | August 16, 2002    |
|       16. | DBOD.NO.AML.BC.58/14.01.001/2004-05  | November 29, 2004  |
|       17. | DBOD.NO.AML.BC.28 /14.01.001/2005-06 | August 23, 2005    |
|       18. | DBOD.NO.AML.BC.63/14.01.001/2005-06  | February 15, 2006  |
|       19. | DBOD.AML.BC. No.77/14.01.001/2006-07 | April 13, 2007     |
|       20. | DBOD.AML.BC.No. 63/14.01.001/2007-08 | February 18, 2008  |
|       21. | DBOD.AML.BC.No. 85/14.01.001/2007-08 | May 22, 2008       |
|       22. | DBOD.AML.BC.No.12/14.01.001/2008-09  | July 1, 2008       |
|       23. | DBOD.AML.BC.No.2/14.01.001/2009-10   | July 1, 2009       |

<!-- RBI_PAGE:98 -->

|   24. | DBOD.AML.BC.No.43/14.01.001/2009-10    | September 11, 2009   |
|-------|----------------------------------------|----------------------|
|   25. | DBOD.AML.BC.No.44/14.01.001/2009-10    | September 17, 2009   |
|   26. | DBOD.AML.BC.No.68/14.01.001/2009-10    | January 12, 2010     |
|   27. | DBOD.AML.BC.No.80/14.01.001/2009-10    | March 26, 2010       |
|   28. | DBOD.AML.BC.No.95/14.01.001/2009-10    | April 23, 2010       |
|   29. | DBOD.AML.BC.No.108/14.01.001/2009-10   | June 9, 2010         |
|   30. | DBOD.AML.BC.No.109/14.01.001/2009-10   | June 10, 2010        |
|   31. | DBOD.AML.BC.No.111/14.01.001/2009-10   | June 15, 2010        |
|   32. | DBOD.AML.BC.No.113/14.01.001/2009-10   | June 29, 2010        |
|   33. | DBOD.AML.BC.No.38/14.01.001/2010-11    | August 31, 2010      |
|   34. | DBOD.AML.BC.No.50/14.01.001/2010-11    | October 26, 2010     |
|   35. | DBOD.AML.BC.No.65/14.01.001/2010-11    | December 7, 2010     |
|   36. | DBOD.AML.BC.No.70/14.01.001/2010-11    | December 30, 2010    |
|   37. | DBOD.AML.BC.No.77/14.01.001/2010-11    | January 27, 2011     |
|   38. | DBOD.AML.BC. No.36/14.01.001/2011-12   | September 28, 2011   |
|   39. | DBOD.AML BC.No.47/14.01.001/2011-12    | November 4, 2011     |
|   40. | DBOD. AML.BC. No.65/14.01.001/2011-12  | December 19, 2011    |
|   41. | DBOD AML BC No. 70/14.01.001/2011-12   | December 30, 2011    |
|   42. | DBOD. AML.BC. No 93/14.01.001/2011-12  | April 17, 2012       |
|   43. | DBOD. AML.BC. No 109/14.01.001/2011-12 | June 8, 2012         |
|   44. | DBOD. AML.BC. No 110/14.01.001/2011-12 | June 8, 2012         |
|   45. | DBOD.AML.BC. No. 39/14.01.001/2012-13  | September 7, 2012    |
|   46. | DBOD.AML.BC. No. 49/14.01.001/2012-13  | September 7, 2012    |
|   47. | DBOD.AML.BC. No. 65/14.01.001/2012-13  | December 10, 2012    |
|   48. | DBOD.AML.BC. No.71/14.01.001/2012-13   | January 18, 2013     |
|   49. | DBOD.AML.BC. No. 78/14.01.001/2012-13  | January 29, 2013     |
|   50. | DBOD.AML.BC. No.87/14.01.001/2012-13   | March 28, 2013       |

<!-- RBI_PAGE:99 -->

|   51. | DBOD. AML.BC. No.101/14.01.001/2011-12   | May 31, 2013      |
|-------|------------------------------------------|-------------------|
|   52. | DBOD.AML.BC. No.29/14.01.001/2013-14     | July 12, 2013     |
|   53. | DBOD.AML.BC. No. 34/14.01.001/2013-14    | July 23, 2013     |
|   54. | DBOD.AML.BC.No.44/14.01.001/2013-14      | September 2, 2013 |
|   55. | DBOD.AML.BC.No.45/14.01.001/2013-14      | September 2, 2013 |
|   56. | DBOD. AML.BC. No. 50/14.01.001/2013-14   | September 3, 2013 |
|   57. | DBOD.AML.BC.No.63/14.01.001/2013-14      | October 29, 2013  |
|   58. | DBOD.AML.BC. No.80/14.01.001/2013-14     | December 31, 2013 |
|   59. | DBOD.AML.BC.No. 100/14.01.001/2013-14    | March 4, 2014     |
|   60. | DBOD. AML. No. 16415/14.01.001/2013-14   | March 28, 2014    |
|   61. | DBOD.AML.BC.No.103/14.01.001/2013-14     | April 3, 2014     |
|   62. | DBOD.AML.BC. No. 119/14.01.001/2013-14   | June 9, 2014      |
|   63. | DBOD. AML.BC. No.124/14.01.001/2013-14   | June 26, 2014     |
|   64. | DBOD.AML.BC.No.26/14.01.001/2014-15      | July 17, 2014     |
|   65. | DBOD.AML.BC.No. 39/14.01.001/2014-15     | September 4, 2014 |
|   66. | DBOD. AML. BC. No. 44/14.01.001/2014-15  | October 21, 2014  |
|   67. | DBR.AML.BC.No.77/14.01.001/2014-15       | March 13, 2015    |
|   68. | DBR. AML. BC. No.104/14.01.001/ 2014-15  | June 11, 2015     |
|   69. | DBR.AML.BC.No.36/14.01.001/2015-16       | August 28, 2015   |
|   70. | DBR. AML.BC. No. 46/14.01.001/2015-16    | October 29, 2015  |
|   71. | DBR.AML.BC.No.60/14.01.001/2015-16       | November 26, 2015 |
|   72. | DBOD.NO.BC.23/21.01.001/92               | September 9, 1992 |
|   73. | DBOD.BP.BC No. 56/21.01.001/2005-06      | January 23, 2006  |
|   74. | DBOD.BP.BC.No. 50/21.01.001/2011-12      | November 4, 2011  |
|   75. | DBOD.BP.BC.No.87/21.01.001//2013-14      | January 22, 2014  |
|   76. | DBOD.No.BP.BC.110/21.02.051/98           | November 18, 1998 |
|   77. | UBD.BPD.(PCB)Cir.No.69/14.01.062/2013-14 | June 10, 2014     |

<!-- RBI_PAGE:100 -->

|   78. | UBD.BPD.PCB).Cir.No.9/14.01.062/2013-14     | May 26, 2014       |
|-------|---------------------------------------------|--------------------|
|   79. | UBD.BPD.(PCB).Cir.No.54/14.01.062/2013-14   | April 7, 2014      |
|   80. | UBD.BPD.(PCB).Cir.No.50/14.01.062/2013-14   | March 6, 2014      |
|   81. | UBD.BPD.(PCB).Cir.No.48/14.01.062/2013-14   | February 18, 2014  |
|   82. | UBD.BPD.(PCB).Cir.No.32/14.01.062/2013-14   | October 22, 2013   |
|   83. | UBD.BPD.(PCB).Cir.No.15/14.01.062/2013-14   | September 17, 2013 |
|   84. | UBD.BPD(AD).Cir.No.4/14.01.062/2013-14      | September 10, 2013 |
|   85. | UBD.BPD.(PCB).Cir.No.11/14.01.062/2013-14   | September 05, 2013 |
|   86. | UBD.BPD.(PCB).Cir.No.2/14.01.062/2013-14    | July 31, 2013      |
|   87. | UBD.BPD(PCB)Cir.No.54/14.01.062/2012-13     | June 6, 2013       |
|   88. | UBD.BPD(PCB)Cir.No.46/14.01.062/2012-13     | April 03, 2013     |
|   89. | UBD.BPD(PCB)Cir.No.39/14.01.062/2012-13     | March 07, 2013     |
|   90. | UBD.CO.PCB.Cir.No.37/14.01.062/2012-13      | February 25, 2013  |
|   91. | UBD.BPD(PCB)Cir.No.34/14.01.062/2012-13     | January 28, 2013   |
|   92. | UBD.BPD(PCB)Cir.No.28/14.01.062/2012-13     | December 19, 2012  |
|   93. | UBD.BPD.(PCB).Cir.No.14/14.01.062/2012-13   | October 9, 2012    |
|   94. | UBD.BPD.(PCB).Cir.No.8/14.01.062/2012-13    | September 13, 2012 |
|   95. | UBD.CO.BPD(PCB).No.34/12.05.001/2011-12     | May 11, 2012       |
|   96. | UBD.CO.BPD.No.24/12.05.001/2011-12          | March 5, 2012      |
|   97. | UBD.BPD.(PCB).Cir.No.20/14.01.062/2011-12   | March 1, 2012      |
|   98. | UBD.CO.BPD.No. 10/12.05.001/2011-12         | November 9, 2011   |
|   99. | UBD.BPD.PCB.No. 8/12.05.001/2011-12         | November 9, 2011   |
|  100. | UBD.CO.BPD.(PCB).Cir.No.9/14.01.062/2010-11 | May 2, 2011        |
|  101. | UBD.CO.BPD.(PCB).Cir.No.8/14.01.062/2010-11 | May 2, 2011        |
|  102. | UBD.CO.BPD.(PCB).Cir.No.7/14.01.062/2010-11 | March 17, 2011     |
|  103. | UBD.CO.BPD.(PCB)Cir.No.6/14.01.062/2010-11  | March 17, 2011     |
|  104. | UBD.BPD (PCB) No.38/12.05.001/2010-11       | March 15, 2011     |

<!-- RBI_PAGE:101 -->

|   105. | UBD.BPD(PCB).No.37/12.05.001/2010-11          | February 18, 2011   |
|--------|-----------------------------------------------|---------------------|
|   106. | UBD.CO.BPD.No.35/12.05.001/2010-11            | January 10, 2011    |
|   107. | UBD.BPD.(PCB).No.32/12.05.001/2010-11         | December 28, 2010   |
|   108. | UBD.BPD.(PCB).Cir.No.17/14.01.062/2010-11     | October 25, 2010    |
|   109. | UBD.BPD.(PCB).Cir.No.12/12.05.001/2010-11     | September 15, 2010  |
|   110. | UBD.BPD.(PCB)No.11/12.05.001/2010-11          | August 25, 2010     |
|   111. | UBD.BPD.(PCB).No.10/12.05.001/2010-11         | August 23, 2010     |
|   112. | UBD.BPD.(PCB).No.9/12.05.001/2010-11          | August 23, 2010     |
|   113. | UBD.BPD.(PCB).Cir.No.7/14.01.062/2010-11      | August 12, 2010     |
|   114. | UBD.BPD(PCB).Cir.No.71/12.05.001/2009-10      | June 15, 2010       |
|   115. | UBD.BPD.CO.53/14.01.062/2009-2010             | April 1, 2010       |
|   116. | UBD. BPD. (PCB).Cir. No. 41/12.05.001/2009-10 | February 3, 2010    |
|   117. | UBD.BPD.CO.NSB1/38/1203.000/2009-10           | December 23, 2009   |
|   118. | UBD.(PCB).CO.BPD.Cir.No.36/14.01.062/2009-10  | December 18, 2009   |
|   119. | UBD.(PCB).CO.BPD.Cir.No.35/14.01.062/2009-10  | December 17, 2009   |
|   120. | UBD.(PCB).CO.BPD.Cir.No.33/14.01.062/2009-10  | December 17, 2009   |
|   121. | UBD.CO.BPD.PCB.Cir.No.23/12.05.001/2009-10    | November 16, 2009   |
|   122. | UBD.CO.BPD.PCB.Cir.No.21/12.05.001/2009-10    | November 16, 2009   |
|   123. | UBD.BPD.CO./NSB1/11/12.03.000/ 2009-10        | September 29, 2009  |
|   124. | UBD.CO.BPD.PCB.Cir.No.9/12.05.001/2009-10     | September 16, 2009  |
|   125. | UBD.CO.BPD(PCB).No.1/12.05.001/2008-09        | July 2, 2008        |
|   126. | UBD.CO.BPD.(PCB).No.32/09.39.000/2007-08      | February 25, 2008   |
|   127. | UBD.CO.BPD.(PCB).No.45/12.05.001/2006-07      | May 25, 2007        |
|   128. | UBD.BPD.Cir.No.38./09.16.100/2005-06          | March 21, 2006      |
|   129. | UBD.BPD.PCB.Cir.11/09.161.00/2005-06          | August 23, 2005     |
|   130. | UBD.PCB.Cir.No.6/09.161.00/2005-06            | August 03, 2005     |
|   131. | UBD.PCB.Cir. 30/09.161.00/2004-05             | December 15, 2004   |

<!-- RBI_PAGE:102 -->

|   132. | UBD.BPD.PCB.Cir.02/09.161.00/2004-05              | July 9, 2004       |
|--------|---------------------------------------------------|--------------------|
|   133. | UBD.BPD.PCB.Cir.48/09.161.00/2003-04              | May 29, 2004       |
|   134. | UBD.No.BPD.PCB.Cir.41/09.161.00/2003-04           | March 26, 2004     |
|   135. | UBD.No.DS.PCB.Cir.17/13.01.00/2002-03             | September 18, 2002 |
|   136. | RPCD.RRB.RCB.AML.BC.No.112/07.51.018/2013-14      | June 16, 2014      |
|   137. | RPCD.RRB.RCB.AML.BC.No.111/07.51.018/2013-14      | June 12, 2014      |
|   138. | RPCD.RRB.RCB.AML.BC.No.97/07.51.018/2013-14       | April 25, 2014     |
|   139. | RPCD.RRB.RCB.AML.BC.No.92/07.51.018/2013-14       | March 13, 2014     |
|   140. | RPCD.RRB.RCB.AML.BC.No.75/07.51.018/2013-14       | January 9, 2014    |
|   141. | RPCD.CO.RRB.RCB.BC.No.48/07.51.010/2013-14        | October 29, 2013   |
|   142. | RPCD.RRB.RCB.AML.BC.No.37/07.51.018/2013-14       | September 18, 2013 |
|   143. | RPCD.RRB.RCB.AML.BC.No.31/07.51.018/2013-14       | September 16, 2013 |
|   144. | RPCD.RRB.RCB.AML.BC.No.32/07.51.018/2013-14       | September 10, 2013 |
|   145. | RPCD.RRB.RCB.BC.No.84/07.51.018/2013-14           | July 25, 2013      |
|   146. | RPCD.RCB.RRB.AML.BC.No.76/07.51.018/2012-13       | June 4, 2013       |
|   147. | RPCD.RCB.RRB.AML.BC.No.71/07.51.018/2012-13       | April 1, 2013      |
|   148. | RPCD.RRB.RCB.BC.No.63/07.51.018/2012-13           | January 30, 2013   |
|   149. | RPCD.RRB.RCB.BC.No.59/07.51.018/2012-13           | January 22, 2013   |
|   150. | RPCD.CO.RRB.RCB.AML.No.6097/7.51.018/2012-13      | December 13, 2012  |
|   151. | RPCD.CO.RRB.RCB.AML.BC.No.36/03.05.33(E)/2012- 13 | October 15, 2012   |
|   152. | RPCD.CO.RRB.RCB.AML.BC.No.29/03.05.33(E)/2012- 13 | September 18, 2012 |
|   153. | RPCD.CO.RRB.RCB.AML.BC.No.82/03.05.33(E)/2011- 12 | June 11, 2012      |
|   154. | RPCD.CO.RRB.RCB.AML.BC.No.81/07.40.00/2011-12     | June 11, 2012      |
|   155. | RPCD.CO.RRB.RCB.AML.BC.No.70/07.40.00/2011-12     | April 18, 2012     |
|   156. | RPCD.CO.RCB.AML.BC.No.52/07.40.00/2011-12         | January 4, 2012    |
|   157. | RPCD.CO.RRB.AML.BC.No.51/03.05.33(E)/2011-12      | January 2, 2012    |
|   158. | RPCD.CO.RCB.AML.BC.No.50/07.40.00/2011-12         | December 30, 2011  |

<!-- RBI_PAGE:103 -->

|   159. | RPCD.CO.RRB.AML.BC.No.46/03.05.33(E)/2011-12   | December 21, 2011   |
|--------|------------------------------------------------|---------------------|
|   160. | RPCD.CO.RRB.AML.BC.NO.31/03.05.33(E)/2011-12   | November 16, 2011   |
|   161. | RPCD.CO.RCB.AML.BC.No.23/07.40.00/2011-12      | October 17, 2011    |
|   162. | RPCD.CO.RRB.AML.BC.No.21/03.05.33(E)/2011-12   | October 13,2011     |
|   163. | RPCD.CO.RRB.AML.BC.No.15/03.05.33(E)/2011-12   | August 8, 2011      |
|   164. | RPCD.CO.RCB.AML.BC.No.63/07.40.00/2010-11      | April 26, 2011      |
|   165. | RPCD.CO.RCB.AML.BC.No.50/07.40.00/2010-11      | February 2, 2011    |
|   166. | RPCD.CO.RRB.AML.BC.No.46/03.05.33(E)/2010-11   | January 12, 2011    |
|   167. | RPCD.CO.RCB.AML.BC.No.39/07.40.00/2010-11      | December 27, 2010   |
|   168. | RPCD.CO.RRB.AML.BC.No.40/03.05.33(E)/2010-11   | December 24, 2010   |
|   169. | RPCD.CO.RCB.AML.BC.No.37/07.40.00/2010-11      | December 10, 2010   |
|   170. | RPCD.CO.RRB.AML.BC.No.31/03.05.33(E)/2010-11   | December 6, 2010    |
|   171. | RPCD.CO.RF.AML.BC.No.20/07.40.00/2010-11       | September 13, 2010  |
|   172. | RPCD.CO.RRB.AML.BC.No.19/03.05.33(E)/2010-11   | September 9, 2010   |
|   173. | RPCD.CO.RF.AML.BC.No.12/4007.40.00/2010-11     | July 20, 2010       |
|   174. | RPCD.CO.RRB.AML.BC.No.13/03.05.33(E)/2010-11   | July 22, 2010       |
|   175. | RPCD.CO.RF.AML.BC.No.11/07.40.00/2010-11       | July 20, 2010       |
|   176. | RPCD.CO.RF.AML.BC.No.89/07.40.00/2009-10       | June 25, 2010       |
|   177. | RPCD.CORRB.AML.BC.No.87/03.05.33(E)/2009-10    | June 23, 2010       |
|   178. | RPCD.CO.RF.AML.BC.No.88/07.40.00/2009-10       | June 25, 2010       |
|   179. | RPCD.CO.RRB.AML.BC.No.86/03.05.33(E)/2009-10   | June 21, 2010       |
|   180. | RPCD.CO.RF.AML.BC.No.84/07.40.00/2009-10       | May 14, 2010        |
|   181. | RPCD.CO.RF.AML.BC.No.83/07.40.00/2009-10       | May 12, 2010        |
|   182. | RPCD.CO.RRB.AML.No.67/03.05.33(E)/2009-10      | April 9, 2010       |
|   183. | RPCD.CO.RF.AML.BC.No.83/07.40.00/2009-10       | March 3, 2010       |
|   184. | RPCD.CO.RRB.No.39/03.05.33(E)/2009-10          | November 5, 2009    |
|   185. | RPCD.CO.RF.AML.BC.No.34/07.40.00/2009-10       | October 29, 2009    |

<!-- RBI_PAGE:104 -->

| 186.   | RPCD.CO.RF.AML.BC.No.28/07.40.00/2009-10    | September 30, 2009   |
|--------|---------------------------------------------|----------------------|
| 187.   | RPCD.CO.RRB.BC.No.27/03.05.33(E)/2009-10    | September 29, 2009   |
| 188.   | RPCD.CO.RCB.AML.BC.No.81/07.40.00/2007-08   | June 25, 2008        |
| 189.   | RPCD.CO.RRB.No.BC.77/03.05.33(E)/2007-08    | June 18, 2008        |
| 190.   | RPCD.CO.RF.AML.BC.No.51/07.40.00/2007-08    | February 28, 2008    |
| 191.   | RPCD.CO.RRB.No.BC.50/03.05.33(E)/2007-08    | February 27, 2008    |
| 192.   | RPCD.CO.RRB.AML.BC.No.98/03.05.28-A/2006-07 | May 21, 2007         |
| 193.   | RPCD.CO.RF.AML.BC.No.96/07.40.00/2006-07    | May 18, 2007         |
| 194.   | RPCD.CO.RRB.AML.BC.68/03.05.33(E)/2005-06   | March 9, 2006        |
| 195.   | RPCD.CO.RF.AML.BC.No.65/07.40.00/2005-06    | March 3, 2006        |
| 196.   | RPCD.No.RRB.BC.33/03.05.33(E)/2005-06       | August 23, 2005      |
| 197.   | RPCD.RF.AML.BC.No.30/07.40.00/2005-06       | August 23, 2005      |
| 198.   | RPCD.AML.BC.No.80/07.40.00/2004-05          | February 18, 2005    |
| 199.   | RPCD.No.RRB.BC.81/03.05.33 (E)/2004-05      | February 18, 2005    |
| 200.   | DNBS (PD) CC.No.46/02.02(RNBC)/2004-05      | December 30, 2004    |
| 201.   | DNBS(PD). CC 48/10.42/2004-05               | February 21, 2005    |
| 202.   | DNBS(PD).CC No. 58/10.42/2005-06            | October 11, 2005     |
| 203.   | DNBS.PD. CC No. 64/03.10.042/2005-06        | March 7, 2006        |
| 204.   | DNBS (PD). CC 113/03.10.042/2007- 08        | April 23, 2008       |
| 205.   | DNBS (PD). CC 163/03.10.042/2009-10         | November 13, 2009    |
| 205A   | DNBS.(PD).CC.164/03.10.042/2009-10          | November 13, 2009    |
| 206.   | DNBS (PD).CC. No 166/03.10.42/2009-10       | December 2, 2009     |
| 206A   | DNBS.(PD).CC.No.171/03.10.42/2009-10        | April 23, 2010       |
| 207.   | DNBS. (PD) CC No 192/03.10.42/2010-11       | August 9, 2010       |
| 208.   | DNBS. (PD) CC No 193/03.10.42/2010-11       | August 9, 2011       |
| 209.   | DNBS (PD).CC. No 201/03.10.42/2010-11       | September 22,2010    |
| 210.   | DNBS (PD).CC. No 202/03.10.42/2010-11       | October 4, 2010      |

<!-- RBI_PAGE:105 -->

|   211. | DNBS(PD).CC.No 209/03.10.42/2010-11   | January 28, 2011   |
|--------|---------------------------------------|--------------------|
|   212. | DNBS(PD).CC.No 210/03.10.42/2010-11   | February 14, 2011  |
|   213. | DNBS.(PD)CC No 212/03.10.42/2010-11   | March 8, 2011      |
|   214. | DNBS(PD).CC. No. 216/03.10.42/2010-11 | May 2, 2011        |
|   215. | DNBS(PD).CC.No 218/03.10.42/2010-11   | May 4, 2011        |
|   216. | DNBS.(PD)CC No 215/03.10.42/2010-11   | April 5, 2011      |
|   217. | DNBS (PD).CC. No 242/03.10.42/2011-12 | September 15, 2011 |
|   218. | DNBS (PD).CC. No 244/03.10.42/2011-12 | September 22, 2011 |
|   219. | DNBS (PD).CC. No 251/03.10.42/2011-12 | December 26, 2011  |
|   220. | DNBS (PD).CC. No 257/03.10.42/2011-12 | March 14, 2012     |
|   221. | DNBS (PD).CC. No 264/03.10.42/2011-12 | March 21, 2012     |
|   222. | DNBS(PD).CC. No.270/03.10.42/2011-12  | April 4, 2012      |
|   223. | DNBS (PD).CC. No 275/03.10.42/2011-12 | May 29, 2012       |
|   224. | DNBS (PD).CC. No 294/03.10.42/2012-13 | July 5, 2012       |
|   225. | DNBS (PD).CC. No 295/03.10.42/2012-13 | July 11, 2012      |
|   226. | DNBS (PD).CC. No 296/03.10.42/2012-13 | July 11, 2012      |
|   227. | DNBS (PD).CC. No 298/03.10.42/2012-13 | July 26, 2012      |
|   228. | DNBS (PD).CC. No 302/03.10.42/2012-13 | September 7, 2012  |
|   229. | DNBS (PD).CC. No 304/03.10.42/2012-13 | September 17, 2012 |
|   230. | DNBS (PD).CC. No 305/03.10.42/2012-13 | October 3, 2012    |
|   231. | DNBS (PD).CC. No 306/03.10.42/2012-13 | October 3, 2012    |
|   232. | DNBS (PD).CC. No 310/03.10.42/2012-13 | November 22, 2012  |
|   233. | DNBS (PD).CC. No 313/03.10.42/2012-13 | December 10, 2012  |
|   234. | DNBS (PD).CC. No 318/03.10.42/2012-13 | December 28, 2012  |
|   235. | DNBS (PD).CC. No 319/03.10.42/2012-13 | December 28, 2012  |
|   236. | DNBS (PD).CC. No 321/03.10.42/2012-13 | February 27, 2013  |
|   237. | DNBS (PD).CC. No 323/03.10.42/2012-13 | April 18, 2013     |

<!-- RBI_PAGE:106 -->

|   238. | DNBS (PD).CC. No 324/03.10.42/2012-13   | May 2, 2013      |
|--------|-----------------------------------------|------------------|
|   239. | DNBS (PD).CC. No 325/03.10.42/2012-13   | May 3, 2013      |
|   240. | DNBS(PD).CC.No.351/03.10.42/2013-14     | July 4, 2013     |
|   241. | DNBS (PD).CC. No 352/03.10.42/2013-14   | July 23, 2013    |
|   242. | DNBS(PD).CC.No 357/03.10.42/2013-14     | October 3, 2013  |
|   243. | DNBS(PD).CC NO 358/03.10.42/2013-14     | October 3, 2013  |
|   244. | DNBS(PD).CC.No.364/03.10.42/2013-14     | January 1, 2014  |
|   245. | DNBS(PD).CC.No.366/03.10.42/2013-14     | January 10, 2014 |
|   246. | DNBS (PD).CC. No 370/03.10.42/2013-14   | March 19, 2014   |
|   247. | DNBS(PD).CC.No.375/03.10.42/2013-14     | April 22 , 2014  |
|   248. | DNBS (PD).CC. No 401/03.10.42/2014-15   | July 25 , 2014   |
|   249. | DNBS (PD).CC. No 402/03.10.42/2014-15   | August 1, 2014   |
|   250. | DNBS (PD).CC. No 404/03.10.42/2014-15   | August 1, 2014   |
|   251. | DNBR.CC.PD.No.010/03.10.01/2014-15      | January 9, 2015  |
|   252. | DNBR(PD).CC.No.034/03.10.42/2014-15     | April 30, 2015   |
|   253. | DBOD.No.IBS.1816/23.67.001/98-99        | February 4, 1999 |

<!-- RBI_PAGE:107 -->

## List of Circulars Repealed Partially, with the issuance of Master Direction

|   Sr. No. | Circular No.                                                                              | Date          |
|-----------|-------------------------------------------------------------------------------------------|---------------|
|        1. | DBOD.BP.BC.57/21.01.001/95 - Paragraph 2(b)                                               | May 4, 1995   |
|        2. | DBS.FGV.BC.56.23.04.001/98-99 Paragraph '(b) Concept of "Know Your Customer" (para. 9.2)' | June 21, 1999 |

## List of Circulars, or part thereof, repealed after the issuance of Master Direction

|   Sr. No. | Circular No.                       | Date         |
|-----------|------------------------------------|--------------|
|        1. | DBR.AML.BC.No.16/14.08.001/2015-16 | July 1, 2015 |