<!-- RBI_PAGE:1 -->

RBI/2019-20/68

Master Direction DCM (CC) No.G-4/03.35.01/2019-20

<!-- image -->

## HR Rud RESERVE BANK OF INDIA

July 01, 2019

(Updated as on October 03, 2019)

1. The Chairman &amp; Managing Director/Chief Executive Officer (All Banks having Currency Chests)
2. The Director of Treasuries (State Governments)

Madam / Dear Sir

Master  Direction  on  Levy  of  Penal  Interest  for  Delayed  Reporting  /  Wrong Reporting  /  Non-Reporting  of  Currency  Chest  Transactions  and  Inclusion  of Ineligible Amounts in Currency Chest Balances

In terms of the Preamble, under Section 45 of the RBI Act, 1934 and 35 A of the Banking Regulation  Act,  1949,  the  Bank  issues  guidelines  /  instructions  for  realising the objectives of our Clean Note Policy.  With a view to sustaining these efforts and ensure discipline  among  the  banks  on  timely  and  accurate  reporting  of  currency  chest transactions, we have issued instructions on the subject.

2. The  Master  Direction  enclosed  incorporates  updated  guidelines  /  circulars  on  the subject. The Direction will be updated from time to time as and when fresh instructions are issued.
2. 3 . This Master Direction has been placed on RBI website at www.rbi.org.in.

Yours faithfully,

(Manas Ranjan Mohanty) Chief General Manager

Encl : As above www.rbi.org.in

<!-- RBI_PAGE:2 -->

## 1 . Penal  interest  for  Delayed  Reporting  /  Wrong  Reporting  /  Non-Reporting  of Currency Chest Transactions

## 1.1 Reporting of Currency Chest Transactions

The minimum amount of deposit into / withdrawal from currency chest will be ` 1,00,000 and thereafter, in multiples of ` 50,000.

## 1.2 Time limit for Reporting

- 1.2.1 The currency chests / Link Offices should invariably report all transactions through CyM - CC portal on the same day by 7 pm .
- 1.2.2 The  Sub-Treasury  Offices  (STOs)  should  report  all  transactions  directly  to  the Issue Office of the Reserve Bank by 7 pm on the same day.

## 1.2.3 Relaxation in respect of strike period in banks

Relaxation in the reporting period on account of strike situation will be considered on case-to-case basis.

## 1.3 Levy of penal interest -

## 1.3.1 Delay in Reporting -

In the event of delay in reporting currency chest transactions, penal interest at the rate  indicated  in  paragraph  3  of  this  circular  will  be  levied  on  the amount due from  the  chest  holding  bank  for  the  period  of  delay.  Penal  interest  will  be calculated on T+0 basis i.e. penal interest will be levied in respect of transactions not  reported  by  currency  chests  /  Link  Offices  to  the  Issue  Office  on  the  same business day within the time limit prescribed above.

Penal interest will also be charged for delay in reporting by STOs directly linked to Issue Department of the circle.

## 1.3.2  Wrong reporting

Penal interest will  be  levied  in  respect  of  cases  of  wrong  reporting  in  the  same manner  till  the  date  of  receipt  of  corrected  advice  by  Reserve  Bank.  As debits/credits to banks' current accounts are raised on the basis of the transactions  reported  by  the  currency  chests  /  Link  Offices,  penal  interest  will invariably  be  levied  in  all  cases  of  wrong  reporting  by  the  currency  chests.  It  is expected  that  currency  chests  /  Link  Offices  would  ensure the  correctness  of figures reported on the CyM - CC portal. Particular care should be taken to ensure that remittances of fresh notes/notes to the currency chests are not reported as 'deposit' transactions on the portal .

<!-- RBI_PAGE:3 -->

## 1.3.3 Penal  interest  for  inclusion  of  ineligible  amounts  in  the  currency  chest balances

- (i) Penal interest will be levied in all cases where the bank has enjoyed 'ineligible' credit  in  its  current  account  with  Reserve  Bank  on  account of wrong reporting / delayed  reporting  /  non-reporting  of  transactions.    Penal  measures  will  also  be taken  in  cases  of  shortages  in  chest  balances  /  remittances,  shortages  due  to pilferage / frauds, counterfeit banknotes detected in chest balances / remittances as per the prevailing 'Scheme of Penalties'.
- (ii) Further, only cash held in the custody of joint custodians and 'freely available' to them  is  eligible  for  inclusion  in  the  chest  balances.  Thus,  cash  kept  for  safe custody in sealed covers for whatever reasons/cash in trunks/bins under the lock and key of any official/s other than the Joint Custodians or bearing a third lock put by any official in addition to the two locks of the Joint Custodians is not eligible for being included in the chest balances. If such amounts are included in the chest balances,  these  will  be  treated  as  instances  of  wrong  reporting  and  will  attract penal interest at the rate specified in Para 3.
- (iii) In  all  the  above  cases  (excepting  shortages  in  chest  balances  /  remittances, shortages  due  to  pilferage  /  frauds,  counterfeit  banknotes  detected  in  chest balances / remittances), penal interest will be levied from the date of inclusion of 'ineligible' amounts in chest balances till the exclusion of such amounts from chest balances.    Penal  measures  for  shortages  in  chest  balances  /  remittances, shortages  due  to  pilferage  /  frauds,  counterfeit  banknotes  detected  in  chest balances  /  remittances  will  be  taken  on  the  basis  of  prevailing  'Scheme  of Penalties'.

## 2 Levy of penalty

## 2.1 Reporting of Soiled note remittances to RBI

Soiled note remittances to RBI should not be shown as withdrawal by chest/s / link offices. In case such remittances to RBI are wrongly reported as 'withdrawals', a  penalty  of ` 50,000  will  be  levied  irrespective  of  the  value  of  remittance  and period of such wrong reporting.

## 2.2 Reporting of diversions in CyM - CC portal

All  currency  chest  diversions  (both  between  chests  of  the  same  bank  and between chests of different banks) have to be reported through 'Diversion Module' of  CyM-CC  Portal.  The  CC  sending  the  diversion  should  initiate  the  diversion entry. The receiving CC should acknowledge the same. Diversions must not be reported  as  Deposit/Withdrawal.    A  penalty  of ` 50,000  will  be  levied  for  such wrong reporting.

<!-- RBI_PAGE:4 -->

## 2.3 Delayed reporting where currency chests had 'Net Deposit'

Penal interest at the prevailing rate for delayed reporting of the instances where the currency chest had reported 'net deposit' may not be charged.  However, in order to  ensure proper discipline in reporting currency chest transactions,  a flat penalty of ` 50,000 may be levied on the currency chests for delayed reporting irrespective of the value of net deposit.

## 3. Rate of penal interest

Penal interest shall be levied at the rate of 2% over the prevailing Bank Rate for the period of delayed reporting/wrong reporting/non-reporting /inclusion of ineligible amounts in chest balances.

## 4. Levy of penal interest in respect of currency chests at treasuries

The  above  instructions  shall  be  applicable  to  currency  chests  at  treasury/subtreasury offices also.

## 5. Representations

- 5.1 As the sole criterion for levy of penal interest for delayed reporting is the number of days of delay, there should ordinarily be no occasion for banks to request for reconsideration  of  the  Reserve  Bank's  decision  in  individual  cases.  However, representations,  if  any,  on  account  of  genuine  difficulties  faced  by  chests especially in hilly/remote areas and those affected by natural calamities, etc., may be made to the Issue Office concerned through the Head / Controlling office of the bank concerned within a month from the date of debit of the bank concerned.
- 5.2 In the case of wrong reporting representations for waiver will not be considered. {cf. para 1.3.2 above}.
- 5.3 As the intention behind the levy of penal interest is to inculcate discipline among banks  so  as  to  ensure  prompt/correct  reporting,  pleas  by  banks  for  waiver  of penal  interest  on  grounds  that  delayed/wrong/non-reporting  did  not  result  in utilization  of  the  Reserve  Bank's  funds  or  shortfall  in  the  maintenance  of CRR/SLR  or  that  they  were  the  result  of    clerical  mistakes,  unintentional  or arithmetical errors, first time error, inexperience of staff etc., will not be considered as valid grounds for waiver of penal interest.  Further, we will take a serious view of all such lapses.

-------------------------