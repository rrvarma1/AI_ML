<!-- RBI_PAGE:1 -->

RBI/2019-20/69

Master Direction DCM (CC) No.G-6/03.41.01/2019-20

The Chairman and Managing Director / Chief Executive Officers, All Banks

Madam / Dear Sir,

Master Direction on Currency Distribution &amp; Exchange Scheme (CDES) based on performance in rendering customer service to the members of public

In terms of the Preamble, under Section 45 of the RBI Act, 1934 and 35 A of the Banking Regulation Act, 1949, the Bank issues guidelines / instructions for realising the objectives of  our  Clean  Note  Policy.  With  a  view  to  sustaining  these  objectives,  the  Bank  has formulated  a  scheme  of  incentives  titled  Currency  Distribution  and  Exchange  Scheme (CDES)  in  order  to  ensure  that  all  bank  branches  provide  better  customer  services  to members of public.

2. The Master Direction enclosed incorporates updated guidelines / circulars on the subject. The Direction will be updated from time to time as and when fresh instructions are issued.
3. This Master Direction has been placed on RBI website at www.rbi.org.in .

Yours faithfully,

(Manas Ranjan Mohanty) Chief General Manager

Encl: As above www.rbi.org.in July 01, 2019

<!-- image -->

## भारतीय �रज़वर् ब�क

## RESERVE BANK OF INDIA

BANK

(Updated as on January 6, 2020)

<!-- RBI_PAGE:2 -->

## Circular on 'Currency Distribution &amp; Exchange Scheme (CDES)' for bank branches including currency chests based on performance in rendering customer service to members of public

1.  The Currency Distribution &amp; Exchange Scheme (CDES) for  bank branches including currency chests has been formulated in order to ensure that all bank branches provide better customer service to members of public with regard to exchange of notes and coins, in keeping with the objectives of Clean Note Policy.

## 2. Incentives

As per the scheme, banks are eligible for the following financial incentives for providing facilities for exchange of notes and coins:

| Sr. No.   | Nature of Service                                                                                                  | Particulars of Incentives                                                                                                                                                                                                                                                                                                                                                                                                                |
|-----------|--------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| i)        | Opening of and maintaining currency chests at centers having population of less than 1 lakh in under banked States | a. Capital Cost: Reimbursement of 50% of capital expenditure subject to a ceiling of ₹ 50 lakh per currency chest. In the North Eastern region up to 100% of capital expenditure is eligible for reimbursement subject to the ceiling of ₹ 50 lakh. b. Revenue cost: Reimbursement of 50% of revenue expenditure for the first 3 years. In the North Eastern region 50% of revenue expenditure will be reimbursed for the first 5 years. |
| ii)       | Exchange of soiled notes/ adjudication of mutilated banknotes over the counter at bank branches                    | a. Exchange of soiled notes - ₹ 2 per packet for exchange of soiled notes up to denomination ₹ 50 b. Adjudication of mutilated notes - ₹ 2 per piece                                                                                                                                                                                                                                                                                     |

<!-- RBI_PAGE:3 -->

| iii)   | Distribution of coins over counter   | i. ₹ 25 per bag for distribution of coins over the counter. ii. The incentives would be paid on the basis of withdrawal from currency chest, without waiting for claims from banks. iii. Banks may put in place a system of checks and balances to ensure that coins are distributed to retail customers in small lots and not to bulk customers. iv. The distribution of coins shall be verified by RBI Regional Offices through inspection of currency chest / incognito visits to branches etc.   |
|--------|--------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## 3. Operational Guidelines to avail performance -based incentives -

i) The incentives will be paid on the soiled notes actually received in the Issue Office of the RBI. Banks need not submit a separate claim in this regard. Currency chest branch will have to pass on the incentive to the linked branches for the soiled notes tendered / coins distributed by them on a pro-rata basis.

ii) Similarly, incentive will be paid in respect of the adjudicated notes received along with the soiled note remittances / sent separately by registered / insured post in a sealed cover to the RBI. No separate claim is required to be made.

-------------------------------------