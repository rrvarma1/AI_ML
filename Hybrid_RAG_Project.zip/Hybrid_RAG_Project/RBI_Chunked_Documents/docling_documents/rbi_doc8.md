<!-- RBI_PAGE:1 -->

OF

<!-- image -->

## भारतीय �रज़वर् ब�क RESERVE BANK OF INDIA

[www.rbi.org.in](http://www.rbi.org.in/)

RBI/FIDD/2016-17/34

Master Direction FIDD.CO.Plan.2/04.09.01/2016-17

The Chairman All Regional Rural Banks

Dear Sir/ Madam,

## MASTER DIRECTION-REGIONAL RURAL BANKS-PRIORITY SECTOR LENDINGTARGETS AND CLASSIFICATION

The guidelines for priority sector lending by Regional Rural Banks were revised by the Reserve Bank of  India  vide  circular  dated  December  3,  2015.  The  Master  Direction  enclosed  incorporates  the updated  guidelines/  instructions/  circulars  on  the  subject.  The  list  of  circulars  consolidated  in  this Master Direction is indicated in the Appendix . The Direction will be updated from time to time as and when  fresh  instructions  are  issued.  This  Master  Direction  has  been  placed  on  the  RBI  website  at www.rbi.org.in.

2. The revised guidelines on priority sector lending by Regional Rural Banks were made operational with  effect  from  January  1,  2016.  Accordingly,  the  priority  sector  loans  sanctioned  under  the guidelines issued prior to this date will continue to be classified under priority sector till repayment/ maturity/ renewal.

Yours faithfully,

(Gautam Prasad Borah) Chief General Manager - in - Charge

�वत्  तीय समावेशन और �वकास �वभाग , क� द्र�य कायार्लय ,10 वी मंिजल , क� द्र�य कायार्लय भवन , पो.बा.सं.10014,मुंबई 400 001 टेल�फोन /Tel No: 91-22-22661000 फै क्स /Fax No: 91-22-22621011/22610948/22610943 ई -मेल / Email  : cgmincfidd@rbi.org.in

Financial Inclusion &amp; Development Department , Central Office , 10 th Floor , C.O. Building , Post Box No .10014 , Mumbai 400 001

## �हंद� आसान है , इसका प्रयोग बढ़ाइये

' चेतावनी  : -�रज़वर् ब�क द्वारा मेल, डाक , एसएमएस या फोन कॉल क े  ज�रए �कसी क� भी व्  यिक्तगत जानकार� जैसे ब�क क े  खाते का ब् यौरा , पासवडर् आ�द नह�ं मांगी जाती है। यह धन रखने या देने का प्रस् ताव भी नह�ं करता है। ऐसे प्रस् ताव� का �कसी भी तर�क े  से जवाब मत द�िजए। "

Caution: RBI never sends mails, SMSs or makes calls asking for personal information like bank account details,   passwords, etc. It never keeps or offers funds to anyone. Please do not respond in any manner to such offers.

<!-- image -->

PRud

BANK

OF

July 7, 2016

(Updated as on June 18, 2019)

<!-- RBI_PAGE:2 -->

## Master Direction- Reserve Bank of India (Regional Rural Banks-Priority Sector Lending -Targets and Classification) Directions, 2016

In  exercise  of  the  powers  conferred  by  Sections  21  and  35  A  of  the  Banking  Regulation  Act, 1949, the Reserve Bank of India being satisfied that it is necessary and expedient in the public interest to do so, hereby, issues the Directions hereinafter specified.

## CHAPTER - I

## PRELIMINARY

## 1. Short Title and Commencement

- (a)  These  Directions  shall  be  called  the  Reserve  Bank  of  India  (Regional  Rural  Banks  Priority Sector Lending - Targets and Classification) Directions, 2016.
- (b) These Directions shall come into effect on the day they are placed on the official website of the Reserve Bank of India.

## 2. Applicability

The provisions of these Directions shall apply to every Regional Rural Bank (RRB) licensed to operate in India by the Reserve Bank of India.

## 3. Clarification:

All other expressions unless defined herein shall have the same meaning as have been assigned to them under the Banking Regulation Act or the Reserve Bank of India Act, or any statutory modification or re-enactment thereto or as used in commercial parlance, as the case may be.

## CHAPTER II

## CATEGORIES AND TARGETS UNDER PRIORITY SECTOR

## 4. The categories under priority sector are as follows:

- i. Agriculture
- ii. Micro, Small and Medium Enterprises (MSMEs)
- iii. Education
- iv. Housing

<!-- RBI_PAGE:3 -->

- v. Social Infrastructure
- vi. Renewable Energy
- vii. Others

The details of eligible activities under the above categories are specified in Chapter III.

## 5. Targets /Sub-targets for Priority sector:

RRBs will have a target of 75 per cent of their outstanding advances for priority sector lending and sub-sector targets as indicated in table below.

| Categories                 | Targets                           |
|----------------------------|-----------------------------------|
| Total Priority Sector      | 75 per cent of total outstanding* |
| Agriculture                | 18 per cent of total outstanding  |
| Small and Marginal Farmers | 8 percent of total outstanding    |
| Micro Enterprises          | 7.5 per cent of total outstanding |
| Weaker Sections            | 15 per cent of total outstanding  |

* The overall Priority Sector target should be achieved across all prescribed categories viz.
-  Agriculture,  MSME,  Education,  Housing,  Social  Infrastructure,  Renewable  Energy  and Others.  However,  lending  to  Medium  Enterprises,  Social  Infrastructure  and  Renewable Energy  shall  be  reckoned  for  priority  sector  achievement  only  up  to  15  per  cent  of  total outstanding.

The computation of priority sector targets/sub-targets achievement will be based on the total outstanding as on the corresponding date of the preceding year.

<!-- RBI_PAGE:4 -->

## CHAPTER III DESCRIPTION OF ELIGIBLE CATEGORIES UNDER PRIORITY SECTOR

## 6. Agriculture

The lending to agriculture sector will be categorized as (i) Farm Credit (which will include short-term crop loans and medium/long-term credit to farmers) (ii) Agriculture Infrastructure and  (iii)  Ancillary  Activities.  A  list  of  eligible  activities  under  the  three  sub-categories  is indicated below:

| 6.1 Farm credit   | A. Loans to individual farmers [including Self Help Groups(SHGs) or Joint Liability Groups (JLGs), i.e. groups of individual farmers, provided banks maintain disaggregated data of such loans], directly engaged in Agriculture and Allied Activities, viz., dairy, fishery, animal husbandry, poultry, bee- keeping and sericulture. This will include: (i) Crop loans to farmers which will include traditional/non-traditional plantations and horticulture, and, loans for allied activities . (ii) Medium and long-term loans to farmers for agriculture and allied activities ( e.g . purchase of agricultural implements and machinery, loans for irrigation and other developmental activities undertaken in the farm, and developmental loans for allied activities.) (iii) Loans to farmers for pre and post-harvest activities, viz ., spraying, weeding, harvesting, sorting, grading and transporting of their own farm produce. (iv) Loans to farmers up to ₹ 5 million against pledge/ hypothecation of agricultural produce (including warehouse receipts) for a period not exceeding 12 months. (v) Loans to distressed farmers indebted to non-institutional lenders. (vi) Loans to farmers under Kisan Credit Card Scheme. (vii) Loans to small and marginal farmers for purchase of land for agricultural purposes. B. Loans to corporate farmers, farmers' producer organizations/companies of individual farmers, partnership firms and co-operatives of farmers directly engaged in Agriculture and Allied Activities, viz ., dairy, fishery, animal husbandry, poultry, bee-keeping and sericulture up to an aggregate limit of ₹ 20 million per borrower. This will include: (i) Crop loans to farmers which will include traditional/non-traditional plantations and horticulture, and, loans for allied activities. (ii) Medium and long-term loans to farmers for agriculture and allied   |
|-------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

<!-- RBI_PAGE:5 -->

|                                 | activities ( e.g . purchase of agricultural implements and machinery, loans for irrigation and other developmental activities undertaken in the farm, and developmental loans for allied activities.) (iii) Loans to farmers for pre and post-harvest activities, viz ., spraying, weeding, harvesting, sorting, grading and transporting of their own farm produce. (iv) Loans up to ₹ 5 million against pledge/hypothecation of agricultural produce (including warehouse receipts) for a period not exceeding 12 months.                                     |
|---------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 6.2. Agriculture infrastructure | i) Loans for construction of storage facilities (warehouses, market yards, godowns and silos) including cold storage units/cold storage chains designed to store agriculture produce/products, irrespective of their location. ii) Soil conservation and watershed development. iii) Plant tissue culture and agri-biotechnology, seed production, production of bio-pesticides, bio-fertilizer, and vermi composting. For the above loans, an aggregate sanctioned limit of ₹ 1 billion per borrower from the banking system, will apply.                      |
| 6.3.Ancillary activities        | (i) Loans up to ₹ 50 million to co-operative societies of farmers for disposing of the produce of members. (ii) Loans for setting up of Agriclinics and Agribusiness Centres. (iii) Loans for Food and Agro-processing up to an aggregate sanctioned limit of ₹ 1 billion per borrower from the banking system. (iv) Loans to Custom Service Units managed by individuals, institutions or organizations who maintain a fleet of tractors, bulldozers, well-boring equipment, threshers, combines, etc., and undertake farm work for farmers on contract basis. |

For the purpose of computation of achievement of the sub-target, Small and Marginal Farmers will include following:-

- -Farmers  with  landholding  of  up  to  1  hectare  are  considered  as  Marginal  Farmers. Farmers  with  a  landholding  of  more  than  1  hectare  and  up  to  2  hectares  are considered as Small Farmers.

<!-- RBI_PAGE:6 -->

- -Landless  agricultural  labourers,  tenant  farmers,  oral  lessees  and  share-croppers, whose  share  of  landholding  is  within  the  limits  prescribed  for  small  and  marginal farmers.
- -Loans to Self Help Groups (SHGs) or Joint Liability Groups (JLGs), i.e. groups of individual  Small  and  Marginal  farmers  directly  engaged  in  Agriculture  and  Allied Activities provided banks maintain disaggregated data of such items.
- -Loans  to  farmers'  producer  companies  of  individual  farmers,  and  co-operatives  of farmers directly engaged in Agriculture and Allied Activities, where the membership of  Small  and  Marginal  Farmers  is  not  less  than  75  per  cent  by  number  and  whose land-holding share is also not less than 75 per cent of the total land-holding.

## 7. Micro, Small and Medium Enterprises (MSMEs)

7.1. The limits for investment in plant and machinery/equipment for manufacturing / service enterprise, as notified by Ministry of Micro, Small and Medium  Enterprises, vide S.O.1642(E) dated September 9, 2006 are as under:-

| Manufacturing Sector   |                                                                         |
|------------------------|-------------------------------------------------------------------------|
| Enterprises            | Investment in plant and machinery                                       |
| Micro Enterprises      | Does not exceed twenty five lakh rupees                                 |
| Small Enterprises      | More than twenty five lakh rupees but does not exceed five crore rupees |
| Medium Enterprises     | More than five crore rupees but does not exceed ten crore rupees        |
| Service Sector         |                                                                         |
| Enterprises            | Investment in equipment                                                 |
| Micro Enterprises      | Does not exceed ten lakh rupees                                         |
| Small Enterprises      | More than ten lakh rupees but does not exceed two crore rupees          |
| Medium Enterprises     | More than two crore rupees but does not exceed five crore rupees        |

Bank  loans  to  Micro,  Small  and  Medium  Enterprises,  for  both  manufacturing  and  service sectors are eligible to be classified under the priority sector as per the following norms:

## 7.2. Manufacturing Enterprises

The  Micro,  Small  and  Medium  Enterprises  engaged  in  the  manufacture  or  production  of goods  to  any  industry  specified  in  the  first  schedule  to  the  Industries  (Development  and Regulation)  Act,  1951  and  as  notified  by  the  Government  from  time  to  time.  The Manufacturing Enterprises are defined in terms of investment in plant and machinery.

<!-- RBI_PAGE:7 -->

## 7.3. Service Enterprises

All bank loans to MSMEs, engaged in providing or rendering of services as defined in terms of  investment  in  equipment  under  MSMED  Act,  2006,  shall  qualify  under  priority  sector without any credit cap.

## 7.4. Khadi and Village Industries Sector (KVI)

All loans to units in the KVI sector will be eligible for classification under the sub-target of 7.5 per cent prescribed for Micro Enterprise under priority sector.

## 7.5. Other Finance to MSMEs

- (i) Loans to entities involved in assisting the decentralized sector in the supply of inputs to and marketing of outputs of artisans, village and cottage industries.
- (ii) Loans to co-operatives of producers in the decentralized sector viz. artisans, village and cottage industries.
- (iii) Credit  outstanding  under  General  Credit  Cards (including Artisan  Credit  Card,  Laghu Udyami Card, Swarojgar Credit Card, and Weaver's Card etc. in existence and catering to the non-farm entrepreneurial credit needs of individuals).

7.6 . To ensure that MSMEs do not remain small and medium units merely to remain eligible for priority sector status, the MSME units will continue to enjoy the priority sector lending status up to three years after they grow out of the MSME category concerned.

## 7.7 Overdrafts under PMJDY:

In  terms  of  revised  guidelines  issued  by  Department  of  Financial  Services,  Ministry  of Finance,  dated    September  24,  2018,  Overdraft  limit  to  Pradhan  Mantri  Jan-Dhan  Yojana (PMJDY) account holder  has been raised to ₹10,000/ -,  age  limit  of  18-60  years  has  been revised  to  18-65  years  and  there  will  not  be  any  conditions  attached  for  overdraft  up  to ₹2,000/ -.    These  overdrafts  will  qualify  as  achievement  of  the  target  for  lending  to  Micro Enterprises.

## 8. Education

Loans to individuals for educational purposes including vocational courses upto ₹ 1 million irrespective of the sanctioned amount will be considered as eligible for priority sector.

<!-- RBI_PAGE:8 -->

## 9. Housing

(i) Loans to individuals up to ₹ 3.5  million in metropolitan centres (with population of one million and above) and ₹ 2.5 million in other centres for purchase/construction of a dwelling unit per family provided the overall cost of the dwelling unit in the metropolitan centres and at  other  centres  does  not  exceed ₹ 4.5  million and ₹  3 million  respectively.  The  housing loans to banks' own employees will be excluded.

(ii) Loans for repairs to damaged dwelling units of families up to ₹ 0.2 million.

- (iii) Bank loans to any governmental agency for construction of dwelling units or for slum clearance and rehabilitation of slum dwellers subject to a ceiling of ₹ 1 million per dwelling unit.

(iv)  The  loans  sanctioned  by  banks  for  housing  projects  exclusively  for  the  purpose  of construction of houses for Economically Weaker Sections (EWS) and Low Income Groups (LIG), the total cost of which does not exceed ₹ 1 million per dwelling unit. For the purpose of identifying the economically weaker sections and low income groups, the family income limit is revised to ₹ 0.3 million per annum for EWS and ₹ 0.6 million per annum for LIG, in alignment with the income criteria specified under the Pradhan Mantri Awas Yojana.

## 10. Social Infrastructure

Bank loans up to a limit of ₹ 50 million per borrower for building social infrastructure for activities namely schools, health care facilities, drinking water facilities, sanitation facilities, construction/refurbishment of household toilets and household level water improvements in Tier II to Tier VI centres.

## 11. Renewable Energy

Bank loans up to a limit of ₹ 150 million to borrowers for purposes like solar based power generators,  biomass  based  power  generators,  wind  mills,  micro-hydel  plants  and  for  nonconventional  energy  based  public  utilities  viz.  street  lighting  systems,  and  remote  village electrification. For individual households, the loan limit will be ₹ 1 million per borrower.

## 12. Others

12.1 Loans not exceeding ₹ 50,000/- per borrower provided directly by banks to individuals and their SHG/JLG, provided the individual borrower's household annual income in rural areas does not exceed ₹ 0.1 million and for non-rural areas it does not exceed ₹ 0.16 million.

<!-- RBI_PAGE:9 -->

- 12.2 Loans to distressed persons [other than farmers already included under 6.1(A) (v)] not exceeding ₹ 0.1 million per borrower to prepay their debt to non-institutional lenders.
- 12.3 Loans  sanctioned  to  State  Sponsored  Organisations  for  Scheduled  Castes/  Scheduled Tribes for the specific purpose of purchase and supply of inputs and/or the marketing of the outputs of the beneficiaries of these organisations.

## 13. Weaker Sections

Priority sector loans to the following borrowers will be considered under Weaker Sections category:-

| No.    | Category                                                                                                                                                                                                              |
|--------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| (i)    | Small and Marginal Farmers                                                                                                                                                                                            |
| (ii)   | Artisans, village and cottage industries where individual credit limits do not exceed ₹ 0.1 million                                                                                                                   |
| (iii)  | Beneficiaries under Government Sponsored Schemes such as National Rural Livelihood Mission (NRLM), National Urban Livelihood Mission (NULM) and Self Employment Scheme for Rehabilitation of Manual Scavengers (SRMS) |
| (iv)   | Scheduled Castes and Scheduled Tribes                                                                                                                                                                                 |
| (v)    | Beneficiaries of Differential Rate of Interest (DRI) scheme                                                                                                                                                           |
| (vi)   | Self Help Groups                                                                                                                                                                                                      |
| (vii)  | Distressed farmers indebted to non-institutional lenders                                                                                                                                                              |
| (viii) | Distressed persons other than farmers, with loan amount not exceeding ₹ 0.1 million per borrower to prepay their debt to non-institutional lenders                                                                    |
| (ix)   | Individual women beneficiaries up to ₹ 0.1 million per borrower                                                                                                                                                       |
| (x)    | Persons with disabilities                                                                                                                                                                                             |
| (xi)   | Overdraft limit to PMJDY account holder upto ₹ 10,000/ - with age limit of 18-65 years                                                                                                                                |
| (xii)  | Minority communities as may be notified by Government of India from time to time                                                                                                                                      |

In States, where one of the minority communities notified is, in fact, in majority, item (xii) will cover only the other notified minorities. These States/ Union Territories are Jammu &amp; Kashmir, Punjab, Meghalaya, Mizoram, Nagaland and Lakshadweep.

<!-- RBI_PAGE:10 -->

## CHAPTER IV MISCELLANEOUS

## 14.  Priority Sector Lending Certificates

The  outstanding  priority  sector  lending  certificates  bought  by  banks  will  be  eligible  for classification under respective categories of priority sector provided the assets are originated by banks, are eligible to be classified as priority sector advances and fulfil the Reserve Bank of India guidelines on Priority Sector Lending Certificates issued vide Circular FIDD.CO.Plan.BC.23/04.09.001/2015-16 dated April 7, 2016.

## 15. Monitoring:

The data on priority sector advances has to be furnished by RRBs to NABARD at quarterly and  annual  intervals.  The  quarterly  and  annual  reporting  formats  are  annexed.  For  the purpose of calculation of priority sector lending targets, total outstanding will be calculated as on corresponding date of the previous year. (i.e. for reporting PSL data for quarter ending June  2019, total outstanding will be considered as on June 30 2018).

## 16. Other Guidelines

RRBs  can  issue  Inter  Bank  Participation  Certificates  (IBPCs)  to  Scheduled  Commercial Banks in respect of their priority sector advances in excess of 75 per cent of their outstanding advances.

## 17. Common guidelines for priority sector loans

RRBs should comply with the following common guidelines for all categories of advances under the priority sector.

## (i) Rate of interest

The  rate  of  interest  on  bank  loans  will  be  as  per  directives  issued  by  our  Department  of Banking Regulation from time to time.

## (ii) Service charges

No loan related  and  adhoc  service  charges/inspection  charges  should  be  levied  on  priority sector  loans  up  to ₹ 25,000.  In  case  of  lending  to  SHGs/JLGs,  the  loan  limit  shall  be applicable per member of SHG/JLG and not to the group as a whole.

<!-- RBI_PAGE:11 -->

## (iii) Receipt, Sanction/Rejection/Disbursement Register

A register/ electronic record should be maintained by the bank, wherein the date of receipt, sanction/rejection/disbursement with reasons thereof, etc., should be recorded. The register/electronic record should be made available to all inspecting agencies.

## (iv) Issue of Acknowledgement of Loan Applications

Banks should provide acknowledgement for loan applications received under priority sector loans.  Bank  Boards  should  prescribe  a  time  limit  within  which  the  bank  communicates  its decision in writing to the applicants.

## 18. Amendments

These directions are subject to any further instructions that may be issued by the RBI from

time to time.

Banks should ensure that loans extended under priority sector are for approved purposes and the end use is continuously monitored. The banks should put in place proper internal controls and systems in this regard.

*********************

<!-- RBI_PAGE:12 -->

## LIST OF CIRCULARS CONSOLIDATED

|   S.No. | Circular No.                        | Date             | Subject                                                                   |
|---------|-------------------------------------|------------------|---------------------------------------------------------------------------|
|       1 | FIDD.CO Plan.BC.18/04.09.01/2018-19 | May 6, 2019      | Priority Sector Lending - Targets and Classification                      |
|       2 | FIDD.CO.Plan.BC.18/04.09.01/2017-18 | March 1, 2018    | Priority Sector Lending - Targets and Classification                      |
|       3 | FIDD.CO.Plan.BC.23/04.09.01/2015-16 | April 7, 2016    | Priority Sector Lending Certificates                                      |
|       4 | FIDD.CO.Plan.BC.14/04.09.01/2015-16 | December 3, 2015 | Regional Rural Banks- Priority Sector Lending- Targets and Classification |

## APPENDIX