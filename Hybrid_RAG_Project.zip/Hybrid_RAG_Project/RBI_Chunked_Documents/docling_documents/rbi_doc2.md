<!-- RBI_PAGE:1 -->

RBI/2019-20/01

DCM (FNVD) G -1/16.01.05/2019-20                                                       July 1, 2019

The Chairman/ Managing Director /Chief Executive Officer All Banks and Director of Treasuries of all States

Dear Sir / Madam,

## Master Circular - Detection and Impounding of Counterfeit Notes

Please refer to the Master Circular DCM (FNVD) G - 1/16.01.05/2018-19 dated July 2,  2018  consolidating  the  instructions  issued  till  July  2,  2018,  relating  to  Detection and Impounding of Counterfeit Notes. The Master Circular has since been updated by  incorporating  the  instructions  issued  till  date  and  has  been  placed  on  the  RBI website www.rbi.org.in.

The Master Circular is a compilation of the instructions issued by RBI on the above subject which are operational as on the date of this Circular.

Yours faithfully,

(Manas Ranjan Mohanty) Chief General Manager

Encl: Master Circular www.rbi.org.in

<!-- image -->

## HR Rud RESERVE BANK OF INDIA.

<!-- RBI_PAGE:2 -->

<!-- image -->

PRurd

## INDEX

## CONTENTS

|   Para No | Particulars                                                                                               |
|-----------|-----------------------------------------------------------------------------------------------------------|
|         1 | Authority to Impound Counterfeit Notes                                                                    |
|         2 | Detection of Counterfeit Notes                                                                            |
|         3 | Impounding of Counterfeit Notes                                                                           |
|         4 | Issue of Receipt to Tenderer                                                                              |
|         5 | Detection of Counterfeit Notes - Reporting to Police and other bodies                                     |
|         6 | Examination of Banknotes Before Issuing over Counters, Feeding ATMs and Remitting to Issue Offices of RBI |
|         7 | Designating Nodal Bank Officer                                                                            |
|         8 | Establishment of Forged Notes Vigilance Cell at Head Office of Banks                                      |
|         9 | Provision of Ultra - Violet Lamps and other Infrastructure                                                |
|        10 | Reporting of Data to RBI / Government                                                                     |
|        11 | Preservation of Counterfeit Notes Received from Police Authorities                                        |
|        12 | Detection of Counterfeit Notes - Training of Staff                                                        |
|           | Annex I                                                                                                   |
|           | Annex II                                                                                                  |
|           | Annex III                                                                                                 |
|           | Annex IV                                                                                                  |
|           | Annex V                                                                                                   |
|           | Annex VI                                                                                                  |
|           | Annex VII                                                                                                 |
|           | Annex VIII                                                                                                |

<!-- RBI_PAGE:3 -->

<!-- image -->

## RESERVE BANK OF INDIA DEPARTMENT OF CURRENCY MANAGEMENT MASTER CIRCULAR - 2019-20

## Detection and Impounding of Counterfeit Notes

## Para 1- Authority to Impound Counterfeit Notes

The Counterfeit Notes can be impounded by

- (i) All Banks
- (ii) All Treasuries and Sub-Treasuries.
- (iii) Issue Offices of Reserve Bank of India.

## Para 2 - Detection of Counterfeit Notes

Banknotes  tendered  over  the  counter  should  be  examined  for  authenticity  through machines.

Similarly, banknotes received directly at the back office / currency chest through bulk tenders should also be examined through machines.

No credit to customer's account is to be given for Counterfeit Notes, if any, detected in the tender received over the counter or at the back-office / currency chest.

In no case, the Counterfeit Notes should be returned to the tenderer or destroyed by the  bank  branches  /  treasuries.  Failure  of  the  banks  to  impound  Counterfeit  Notes detected at their end will be construed as wilful involvement of the bank concerned in circulating Counterfeit Notes and penalty will be imposed.

## Para 3  -  Impounding of Counterfeit Notes

Notes determined as counterfeit shall be stamped as "COUNTERFEIT NOTE" and impounded in the prescribed format (Annex I). Each such impounded note shall be recorded under authentication, in a separate register.

## Para 4 -  Issue of Receipt to Tenderer

When a banknote tendered at the counter of a bank branch/back office and currency chest  or  treasury  is  found  to  be  counterfeit,  an  acknowledgement  receipt  in  the prescribed format (Annex II) must be issued to the tenderer, after stamping the note as in Paragraph  3 ibid. The  receipt, in running serial numbers,  should be authenticated by the cashier and tenderer. Notice to this effect should be displayed prominently at the offices / branches for information of the public. The receipt is to be issued even in cases where the tenderer is unwilling to countersign it.

<!-- RBI_PAGE:4 -->

<!-- image -->

## Para 5 - Detection of Counterfeit Notes - Reporting to Police and other bodies

The following procedure should be followed while reporting incidence of detection of Counterfeit Note to the Police:

For cases of detection of Counterfeit Notes up to 4 pieces, in a single transaction, a consolidated report in the prescribed format (Annex III) should be sent by the Nodal Bank  Officer  to  the  police  authorities  or  the  Nodal  Police  Station,  along  with  the suspect Counterfeit Notes, at the end of the month.

For  cases  of  detection  of  Counterfeit  Notes  of  5  or  more  pieces,  in  a  single transaction,  the  Counterfeit  Notes  should  be  forwarded immediately by  the  Nodal Bank Officer to the local police authorities or the Nodal Police Station for investigation by filing FIR in the prescribed format (Annex IV).

A  copy  of  the  monthly  consolidated  report  /  FIR  shall  be  sent  to  the  Forged  Note Vigilance Cell constituted at the Head Office of the bank (only in the case of banks), and in the case of the treasury, it should be sent to the Issue Office of the Reserve Bank concerned.

Acknowledgement of the police authorities concerned has to be obtained for note/s forwarded to them both as consolidated monthly statement and for filing of FIR. If the Counterfeit Notes are sent to the police by insured post, acknowledgement of receipt thereof  by  the  police  should  be  invariably  obtained  and  kept  on  record.  A  proper follow-up of receipt of acknowledgement from the police authorities is necessary. In case any difficulty is faced by the Offices / Branches due to reluctance of the police to receive monthly consolidated statement / file FIRs, the matter may be sorted out in consultation  with  the  Nodal  Officer  of  the  police  authority  designated  to  coordinate matters  relating  to  investigation  of  Counterfeit  Banknotes  cases.  The  list  of  Nodal Police Stations may be obtained from the Regional Office concerned of the Reserve Bank of India.

In order to facilitate identification of people abetting circulation of Counterfeit Notes, banks  are  advised  to  cover  the  banking  hall  /  area  and  counters  under  CCTV surveillance and recording and preserve the recording.

Banks  should  also  monitor  the  patterns  /  trends  of  such  detection  and  suspicious trends  /  patterns  should  be  brought  to  the  notice  of  RBI  /  Police  authorities immediately.

The  progress  made  by  banks  in  detection  and  reporting  of  Counterfeit  Notes  to Police, RBI, etc. and problems thereof, should be discussed regularly in the meetings of  various  State  Level  Committees  viz.  State  Level  Bankers'  Committee  (SLBC), Standing  Committee  on  Currency  Management  (SCCM),  State  Level  Security Committee (SLSC) etc.

<!-- RBI_PAGE:5 -->

<!-- image -->

The data on detection of counterfeit Indian  notes at  bank  branches and treasuries should  be  included  in  the  monthly  returns  forwarded  to  the  Reserve  Bank  Issue Offices as indicated in para 10 below.

The  definition  of  'counterfeiting'  in  the  Indian  Penal  Code  covers  currency  notes issued  by  a  foreign  government  authority  as  well.  In  case  of  suspected  foreign currency  note  received  for  opinion  from  the  police  and  government  agencies,  etc., they should be advised to forward the case to the Interpol Wing of the CBI, New Delhi after prior consultation with them.

The Government of India has framed Investigation of High Quality Counterfeit Indian Currency Offences Rules, 2013 under Unlawful Activities (Prevention) Act (UAPA), 1967. The Third Schedule of the Act defines High Quality Counterfeit Indian Currency Note.  Activity  of  production,  smuggling  or  circulation  of  High  Quality  Counterfeit Indian Notes has been brought under the ambit of UAPA, 1967.

## Para 6 - Examination of the Banknotes before Issuing over Counters, Feeding ATMs and Remitting to Issue Offices of the Reserve Bank

The banks should re-align their cash management in such a manner so as to ensure that  cash  receipts  in  the  denominations  of  ₹100  an d  above  are  not  put  into  recirculation  without  the  notes  being  machine  processed  for  authenticity.  The  said instructions  shall  be  applicable  to  all  bank  branches,  irrespective  of  the  volume  of daily cash receipt. Any non-compliance will be construed as violation of the Directive No.3158/09.39.00 (Policy)/2009-10 dated November 19, 2009 issued by the Reserve Bank.

In order to obviate complaints regarding receipt of Counterfeit Notes through ATMs, and  to  curb  circulation  of  counterfeits,  it  is  imperative  to  put  in  place  adequate safeguards  /  checks  before  loading  ATMs  with  notes.  Dispensation  of  Counterfeit Notes  through  the  ATMs  would  be  construed  as  an  attempt  to  circulate  the Counterfeit Notes by the bank concerned.

Detection of counterfeits in chest remittances is also liable to be construed as wilful involvement  of  the  chest  branches  concerned  in  circulating  Counterfeit  Notes  and may  attract special investigation by police authorities, and other action like suspending the operation of the chest concerned.

Penalty at 100% of the notional value of Counterfeit Notes, in addition to the recovery of loss to the extent of the notional value of such notes, will be imposed under the following circumstances:

- a) When Counterfeit Notes are detected in the soiled note remittance of the bank.
- b) If Counterfeit Notes are detected in the currency chest balance of a bank during Inspection / Audit by RBI.

<!-- RBI_PAGE:6 -->

<!-- image -->

In  terms  of  DPSS.CO.OD.No.1916/06.07.011/2018-19  dated  March  7,  2019,  all guidelines, safeguards, standards and control measures applicable to banks relating to  (a)  currency  handling,  and  (b)  cyber-security  framework  for  ATMs,  shall  also  be applicable to the WLA Operators.

## Para 7 - Designating Nodal Bank Officer

Each bank should designate a Nodal Bank Officer, district-wise and notify the same to the Regional Office of RBI concerned and Police Authorities. All cases of reporting of  Counterfeit  Note  detection  as  indicated  in  Para  5  should  be  done  through  the Nodal Bank Officer. The Nodal Bank Officer will also serve as the contact point for all Counterfeit Note detection related activities.

## Para 8 - Establishment of Forged Notes Vigilance Cell at Head Office of Bank

Each bank shall establish at its Head Office, a Forged Note Vigilance (FNV) Cell to undertake the following functions:

- i. Dissemination  of  instructions  issued  by  the  Reserve  Bank  on  Counterfeit Notes to bank's branches. Monitoring the implementation of these instructions. Compilation of data on detection of Counterfeit Notes, and its submission to Reserve Bank, FIU-IND and National Crime Records Bureau (NCRB) as per extant  instructions.  Follow-up  of  cases  of  Counterfeit  Notes,  with  police authorities / designated nodal officer.
- ii. Sharing of the information thus compiled with bank's CVO and report to him / her all cases of acceptance / issue of Counterfeit Notes over the counters.
- iii. Conducting  periodic  surprise  checks  at  currency  chests  where  shortages  / defective / Counterfeit Notes etc. are detected.
- iv. Ensuring operation of Note Sorting Machines of appropriate capacity at all the currency  chests  / back  offices and  closely  monitoring  the  detection  of Counterfeit Notes and maintaining the record of the same. Ensuring that only properly  sorted  and  machine  examined  banknotes  are  fed  into  the  ATMs  / issued over the counters and to put in place adequate safeguards, including surprise checks, both during the processing and in transit of notes.

FNV  Cell  shall  submit  status  report  on  a  quarterly  basis  covering  the  aforesaid aspects  to  the  Chief  General  Manager,  Department  of  Currency  Management, Reserve Bank of India, Central Office, Amar Building, Fourth Floor, Sir P. M. Road, Fort,  Mumbai 400 001 / to (email) and to the Issue office of the Regional office of Reserve Bank under whose jurisdiction the FNV Cell is functioning, within a fortnight from the conclusion of the quarter under report. The said report should be sent by email. No hard copy need be sent.

In  order  to  update  the  record  of  the  addresses  of  the  FNV  Cells,  the  bank  shall furnish by e-mail, in the prescribed format (Annex V), the particulars to the Reserve Bank every year, as on 1st July. No hard copy need be sent.

<!-- RBI_PAGE:7 -->

<!-- image -->

## Para 9 - Provision of Ultra-Violet Lamp and Other Infrastructure

With  a  view  to  facilitating  the  detection  of  Counterfeit  Notes,  all  bank  branches  / identified back offices should be equipped with ultra-violet lamps / other appropriate banknote  sorting  /  detection  machines.  In  addition,  all  currency  chest  branches should be equipped with verification, processing and sorting machines and should be used to their optimum capacity. Such machines should conform to the guidelines on 'Note  Authentication  and  Fitness  Sorting  Parameters'  prescribed  by  the  Reserve Bank.

The  banks  shall  maintain  a  daily  record  of  the  notes  processed  through  the  Note Sorting machines, including the number of counterfeits detected.

The banks should also consider providing at least one counting machine (with dual display facility) for public use at the counter.

## Para 10 - Reporting of Data to RBI / NCRB / FIU-IND

## By All Bank branches

Data on Counterfeit Notes detected by all the branches of the bank shall be reported in  the  prescribed  format,  on  a  monthly  basis.  A  statement  (Annex  VI)  showing  the details of Counterfeit Notes detected in the bank branches during the month shall be compiled  and  forwarded  to  the  Issue  Office  of  Reserve  Bank  concerned  so  as  to reach them by 7th of the next month. A 'nil 'report may be sent in case no counterfeit note has been detected during the month.

Under  Rule  8  (1)  of  Prevention  of  Money  Laundering  (Maintenance  of  Records) Amendment  Rules,  2013,  Principal  Officers  of  banks  are  also  required  to  report information  on  cash  transactions  where  forged  notes  have  been  detected  to  The Director, FIU-IND,  Financial Intelligence UnitIndia, 6th Floor, Hotel  Samrat, Chanakyapuri,  New  Delhi-110021,  by  the  15 th day  of  the  succeeding  month, by uploading  the  information  on  the  FINnet  Portal .  Similarly,  data  on  Counterfeit Note detection is also to be uploaded on the web-enabled software of National Crime Records Bureau, New Delhi at their website .

## Para 11- Preservation of Counterfeit Notes Received from Police Authorities

All  Counterfeit  Notes  received  back  from  the  police  authorities  /  courts  may  be carefully  preserved  in  the  safe  custody  of  the  bank  and  a  record  thereof  be maintained  by  the  branch  concerned.  FNV  Cell  of  the  bank  shall  also  maintain  a branch-wise consolidated record of such Counterfeit Notes.

These Counterfeit Notes at branches should be subjected to verification on a halfyearly  basis  (on  31st  March  and  30th  September)  by  the  Officer-in-Charge  of  the bank office concerned. They should be preserved for a period of three years from the date of receipt from the police authorities.

<!-- RBI_PAGE:8 -->

<!-- image -->

BANK

OF

They may thereafter be sent to the Issue Office of Reserve Bank of India concerned with full details.

Counterfeit Notes, which are the subject matter of litigation in the court of law should be preserved with the branch concerned for three years after conclusion of the court case.

## Para 12 - Detection of Counterfeit Notes - Training of Staff

It is necessary to ensure that the cash handling staff in banks and treasuries / subtreasuries are fully conversant with the security features of a banknote.

With  a  view  to  educating  the  branch  staff  on  detection  of  Counterfeit  Notes,  the design  and  security  features  of  all  the  banknotes  shown  in  Annex  VII  have  been supplied to all the banks / treasuries with instructions to display them prominently at the branches for information of the public. Posters of the 2005-06 series of banknotes have  also  been  supplied  to  bank  branches  for  display  at  the  branches.  Details  of security features of the New Design banknotes of ` 2000, ` 500, ` 200, ` 100, ` 50, ` 20 and `10 are available at the link https://www.paisaboltahai.rbi.org.in

Details  of  other  banknotes  are  also  available  under  'Know  your  Banknotes'  at  the above link.

The  Controlling  Offices  /  Training  Centers  should  also  organise  /  conduct  training programmes on the security  features  of  banknotes  for  members  of  staff  to  enable detection of Counterfeit Notes at the point of receipt itself. The banks should ensure that all bank personnel handling cash are trained on features of genuine Indian bank notes. These trainings should cover detection, impounding and reporting of Counterfeit Notes. The Reserve Bank will also provide faculty support and training materials.

<!-- RBI_PAGE:9 -->

<!-- image -->

PRurd

## Annex I (Paragraph 3)

Each  banknote,  which,  on  examination  of  various  security  features  /  parameters,  is determined  as  a  counterfeit  one,  shall  be  branded  with  a  stamp  "COUNTERFEIT BANKNOTE". For this purpose, a stamp with a uniform size of 5 cm x 5 cm with the following inscription may be used.

COUNTERFEIT BANKNOTE IMPOUNDED

BANK / TREASURY/ SUB-TREASURY

BRANCH / CURRENCY CHEST

SIGNATURE

DATE

<!-- RBI_PAGE:10 -->

<!-- image -->

PRurd

Annex II (Paragraph 4)

## Format - Acknowledgement Receipt to be issued to the tenderer of Counterfeit Notes

Name of the Bank / Treasury/ Sub-treasury: Address:

Serial Number of the Receipt: \_\_\_\_\_\_\_\_

Date: \_\_\_\_\_\_\_\_\_\_

The  note  (s)  described  below  received  from…………………………….  (Name  and Address of the tenderer) is/are counterfeit and has/have therefore been impounded and stamped accordingly.

| Serial number of the note deemed as counterfeit   | Denomination   | Parameters on which the note is deemed as counterfeit   |
|---------------------------------------------------|----------------|---------------------------------------------------------|

Total number of Counterfeit Notes:

(Signature of the Tenderer)                                        (Signature of the Counter Staff)

(Official Seal)

<!-- RBI_PAGE:11 -->

Name of the Bank:

District:

Name and Address of the Nodal Bank Officer:

Ref. No. …………

The Inspector of Police \_\_\_\_\_\_\_\_\_\_\_Police Station,

Consolidated Monthly Report for the month of \_\_\_\_\_\_\_\_

Detail of Counterfeit Notes:

| Date of detection   | Name of branch / currency chest   | Details of tenderer   | Denominations / pieces / serial numbers   | Security features breached   | Unique Reference Number (URN) generated by the NCRB Portal   |
|---------------------|-----------------------------------|-----------------------|-------------------------------------------|------------------------------|--------------------------------------------------------------|

4. The Counterfeit Notes are enclosed for information and necessary action.
5. Kindly acknowledge receipt.

(Authorised signatory)

(Official Seal) Encl:

<!-- image -->

PRurd

Annex III (Paragraph 5)

Date:    \_\_\_\_\_\_\_\_\_\_\_\_\_

<!-- RBI_PAGE:12 -->

<!-- image -->

PRurd

Annex- IV (Paragraph 5)

Date:    \_\_\_\_\_\_\_\_\_\_\_\_\_

Name of the Bank:

District:

Name and Address of the Nodal Bank Officer:

Ref. No. …………

The Inspector of Police \_\_\_\_\_\_\_\_\_\_\_Police Station,

Dear Sir,

## Detection of Counterfeit Note/s - Request for investigation

We enclose the following Counterfeit Notes detected in our office on \_\_\_\_\_\_\_\_. The details of the Counterfeit Notes are furnished below.

2. As the printing and/or circulation of forged Indian Currency Notes is an offence under Sections  489A  to  489E  of  the  Indian  Penal  Code,  we  request  you  to  lodge  FIR  and conduct the necessary investigation. In case it is decided to file criminal proceedings in the  court  of  law,  you  may  first  arrange  to  send  the  notes  to  any  of  the  Note  Printing Presses, Forensic Science Laboratories etc. in terms of the provisions of Section 292(1) and  292(3)  of  the  Code  of  Criminal  Procedure  for  examination.  The  expert  opinion furnished may be produced in the court as evidence under Section 292 of the Criminal Procedure Code. The forged notes may please be returned to us after the completion of the investigation and/or proceedings in the court of law along with the detailed report of the investigation / decision of the court.

| Denomination / Number of pieces   | Serial number of Counterfeit Note   | Notional Value   | Details of tenderer   | Name & address of the branch /currency chest where detection took place   | Bank's Entry No.   | Unique Reference Number (URN) generated in the NCRB Portal   |
|-----------------------------------|-------------------------------------|------------------|-----------------------|---------------------------------------------------------------------------|--------------------|--------------------------------------------------------------|

3. The Counterfeit Notes are enclosed.
4. Please acknowledge receipt.

Yours faithfully,

Authorised Signatory Official Seal Encl:

<!-- RBI_PAGE:13 -->

<!-- image -->

PRurd

Annex V

(Paragraph 8)

## FORMAT FOR FURNISHING ADDRESS ETC. PARTICULARS OF FORGED NOTE VIGILANCE CELL (FNVC) TO RBI

(TO BE FURNISHED BY E-MAIL ON 1ST JULY EVERY YEAR)

| NAME OF THE BANK   | ADDRESS OF FNVC (WITH PIN CODE)   | NAME AND DESIGNATION OF OFFICER- IN-CHARGE   | TELEPHONE NO (WITH CODE).   | FAX NO. (WITH CODE)   | E-mail Address of the FNVC   |
|--------------------|-----------------------------------|----------------------------------------------|-----------------------------|-----------------------|------------------------------|

We note to intimate immediately the changes, if any, in the particulars furnished above

Name of Authorised Official:

Designation

Date:

NB:  The completed format, in MS-Excel, should be transmitted by e-mail

( No hard copy need be sent )

<!-- RBI_PAGE:14 -->

<!-- image -->

SERVE

BANK

30

Annex VI (Paragraph 10)

Date: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Name of the bank / District:

Statement showing the details of Counterfeit Banknotes detected in the \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ during the month of \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## A)  Details of Counterfeit Notes detected:

| Name of branch / currency chest   | Type of detection                   | Denomination-wise Details in pieces   | Denomination-wise Details in pieces   | Denomination-wise Details in pieces   | Denomination-wise Details in pieces   | Denomination-wise Details in pieces   | Denomination-wise Details in pieces   | Denomination-wise Details in pieces   | Denomination-wise Details in pieces   |   Denomination-wise Details in pieces | Denomination-wise Details in pieces   | Denomination-wise Details in pieces   |   Denomination-wise Details in pieces |   Denomination-wise Details in pieces |
|-----------------------------------|-------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|---------------------------------------|
| Name of branch / currency chest   | Type of detection                   | 10 Old                                | 10 New                                | 20 Old                                | 20 New                                | 50 Old                                | 50 New                                | 100 Old                               | 100 New                               |                                   200 | 500 Old                               | 500 New                               |                                  1000 |                                  2000 |
|                                   | FIR (FICN pieces )                  |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |
|                                   | Non-FIR (FICN pieces)               |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |
|                                   | Total Pieces of banknotes processed |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |                                       |

## B) Details of FIR cases filed with police:

|                                                                    | Pending with Police at the beginning of the month (Cumulative Total)   | Sent to Police during the month   | Returned by the Police during the month   | Pending with the Police at the end of the month (Cumulative Total)   |
|--------------------------------------------------------------------|------------------------------------------------------------------------|-----------------------------------|-------------------------------------------|----------------------------------------------------------------------|
| No. of cases* where FIR was filed                                  |                                                                        |                                   |                                           |                                                                      |
| Total pieces of Counterfeit Notes involved in all the cases of FIR |                                                                        |                                   |                                           |                                                                      |

## Forwarded to: -

1. The General Manager/Deputy General Manager, Reserve Bank of India, Issue Department, \_\_\_\_\_\_\_\_\_\_\_\_

Name &amp; Designation of the Authorised Official

(Signature) Official Seal

<!-- RBI_PAGE:15 -->

Annex VII (Paragraph 12)

<!-- image -->

PRurd

## Designs of Bank Notes Issued by the Reserve Bank of India since 1967

| Year          | Size          | Watermark                                                                                                                                                                                                                  | Front                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | Back                                                                                                                                      |
|---------------|---------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------|
| I. ` 10 notes | I. ` 10 notes | I. ` 10 notes                                                                                                                                                                                                              | I. ` 10 notes                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | I. ` 10 notes                                                                                                                             |
| 1967          | 137 x 63 mm   | Ashoka Pillar                                                                                                                                                                                                              | Purple colour. Numeral 10 in the centre.                                                                                                                                                                                                                                                                                                                                                                                                                                                               | Value of the note in 14 languages. The oval seascape with country craft.                                                                  |
| 1968          | -do-          | -do-                                                                                                                                                                                                                       | Blue-black colour. Promise clause, guarantee clause and signature printed in bilingual.                                                                                                                                                                                                                                                                                                                                                                                                                | -do- RBI's name in Hindi added.                                                                                                           |
| 1969          | -do-          | -do-                                                                                                                                                                                                                       | Blue Black colour. 'Ten Rupees' instead of 'Rupees Ten'.                                                                                                                                                                                                                                                                                                                                                                                                                                               | Mahatma Gandhi's Portrait.                                                                                                                |
| 1970          | -do-          | Ashoka Pillar with spinning wheels.                                                                                                                                                                                        | Hindi version of RBI incorporated in place of English and vice versa. Hindi rendering of Guarantee clause, promise clause and Governor's signature have been interchanged. सत्यमेव जयते incorporated. Watermark window and numbering panel enlarged.                                                                                                                                                                                                                                                   | Bilingual seal incorporated                                                                                                               |
| 1975          | -do-          | -do-                                                                                                                                                                                                                       | Dark brown, umber and blue colour. Numeral '10' printed in dark brown. Intaglio printing. Languages scroll on left and Ashoka Pillar emblem on right.                                                                                                                                                                                                                                                                                                                                                  | Pale brown, Ochre blue and green colour. A circle with two Peacocks on branch of a tree. Deer, horses, bird and lotus.                    |
| 1992          | -do-          | -do-                                                                                                                                                                                                                       | Overall colour scheme in pale pink, magenta and yellow                                                                                                                                                                                                                                                                                                                                                                                                                                                 | Shalimar garden                                                                                                                           |
| 1996          | -do-          | Portrait of Mahatma Gandhi with multidirection al lines in the watermark window.                                                                                                                                           | Overall colour scheme in mauve brown, orange and pink. Portrait of Mahatma Gandhi. Embedded security thread containing the words ' भारत RBI' readable on both sides when held against light.                                                                                                                                                                                                                                                                                                           | Intricate guilloche and floral patterns with profiles of an elephant, rhinoceros and tiger's faces. Value of note in 15 Indian languages. |
| 2006          | -do-          | The portrait of Mahatma Gandhi, the multidirection al lines, and an electrotype mark showing the denomination al numeral 10 appear in this section and these can be viewed better when the banknote is held against light. | Machine readable windowed demetalised clear text magnetic security thread with inscriptions 'Bharat' (in Hindi) and RBI which fluoresces in yellow on both sides under UV light. (Generic). Width: 1.4 mm Dual coloured optical fibres. The small floral design printed both on the front (hollow) and back (filled up) of the note in the middle of the vertical band next to the Watermark has an accurate back-to-back registration so that the numeral appears as one when seen against the light. | Year of printing is incorporated at the printing stage on the reverse of the banknote.                                                    |

<!-- RBI_PAGE:16 -->

<!-- image -->

| 2011            | -do-            |                 | -do-                                                                                                                          | -do- In addition, ` symbol was introduced on the obverse of the banknote, on the top left and top right corner (along with the denominational numeral).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | The banknotes will continue to have year of printing on the reverse. In addition, ` symbol was introduced on the reverse of the banknotes, on the top left and top right corner (along with the denominational numeral).                          |
|-----------------|-----------------|-----------------|-------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2016            | -do-            |                 | -do-                                                                                                                          | -do- In addition, the numerals in both the number panels of these banknotes will be in ascending size from left to right, while the first three alphanumeric characters (prefix) will remain constant in size                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |                                                                                                                                                                                                                                                   |
| 2018            | 63 mm 123 mm    | x               | ₹ 10 denomination banknotes in the Mahatma Gandhi (New) Series having Mahatma Gandhi portrait and electrotype (10) watermarks | The base colour of the note is Chocolate Brown. The note has other designs, geometric patterns aligning with the overall colour scheme, both at the obverse and reverse. See through register with denominational numeral 10 Denominational numeral १० in Devnagari, Portrait of Mahatma Gandhi at the centre, Micro letters 'RBI', ' भारत ', 'INDIA' and '10', Windowed demetalised security thread with inscriptions ' भारत ' and RBI, Guarantee Clause, Governor's signature with Promise Clause and RBI emblem towards right of Mahatma Gandhi portrait, Ashoka Pillar emblem on the right, Number panel with numerals growing from small to big on the top left side and bottom right side. | The new denomination has motif of Sun Temple, Konark on the reverse, depicting the country's cultural heritage. Year of printing of the note on the left, Swachh Bharat logo with slogan, Language panel, Denominational numeral १० in Devnagari. |
| II. ` .20 notes | II. ` .20 notes | II. ` .20 notes | II. ` .20 notes                                                                                                               | II. ` .20 notes                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | II. ` .20 notes                                                                                                                                                                                                                                   |
| 1972            | 147X6 3mm       |                 | Ashoka Pillar                                                                                                                 | Saffron colour. Ashoka Pillar emblem on the right and language panel on the left side.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           | Bold lettering in Hindi appears centrally in a horizontal panel, flanked by figures 20 at the corner. Picture of Parliament House. On the left value in Indian languages.                                                                         |
| 1975            | -do-            |                 | Small Ashoka Pillar with chain of spinning wheels. Resin treated paper                                                        | Red, blue, mauve and pale yellow colour. Numerical 20 in dark mauve on a light yellow lotus shaped design. Language scroll on the left and Ashoka Pillar emblem on right. The printing bleeds off on all sides but not in corners, which are paper white. Bilingual names, clauses and signature.                                                                                                                                                                                                                                                                                                                                                                                                | Dry offset printing. Red, blue and mauve colour. Chariot wheel of Konark Sun temple at the centre. Watermark window in pale blue is surrounded by an ornamental design in perfect register with corresponding design on obverse of the note.      |
| 2001            | -do-            |                 | Mahatma Gandhi Portrait                                                                                                       | The security thread totally embedded with the letters "Bharat" (in Hindi) and "RBI" The colour is predominantly reddish orange. The Ashoka Pillar has been replaced by the Mahatma Gandhi's Portrait in dark red while the Ashoka Pillar has been shifted to the left side bottom corner and the size is smaller.                                                                                                                                                                                                                                                                                                                                                                                | The central theme depicts the Indian coastal line with coconut grooves. The value of the note appears in 15 languages in a vertical panel in the left hand side.                                                                                  |

<!-- RBI_PAGE:17 -->

<!-- image -->

|      |      |                                                                                                                                                                                                                           | The numeral 20, RBI seal, Mahatma Gandhi's Portrait, RBI Legend, Guarantee and Promise clauses, Governor's Signature and Ashoka Pillar inset are in intaglio. The words RBI and the numeral 20 in Micro letters appear alternatively behind the Mahatma Gandhi's Portrait. An identification mark by way of a small vertical rectangle in raised form appears on the left side of the note to facilitate the visually impaired to identify the denomination of the note. The numbers in the number panel are printed in red.                                                                                                                                                                                                                                                                               |                                                                                                                                                                                                                          |
|------|------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2006 | -do- | The portrait of Mahatma Gandhi, the multidirection al lines, and an electrotype mark showing the denomination al numeral 20 appear in this section and these can be viewed better when the banknote is held against light | Machine readable windowed demetalised clear text magnetic security thread with inscriptions 'Bharat' (in Hindi) and RBI which fluoresces in yellow on both sides under UV light (Generic). Width: 1.4 mm Dual coloured optical fibres. The small floral design printed both on the front (hollow) and back (filled up) of the note in the middle of the vertical band next to the Watermark has an accurate back-to-back registration so that the numeral appears as one when seen against the light.                                                                                                                                                                                                                                                                                                      | Year of printing is incorporated at the printing stage on the reverse of the banknote.                                                                                                                                   |
| 2012 | -do- | -do-                                                                                                                                                                                                                      | -do- In addition, ` symbol was introduced on the obverse of the banknote, on the top left and top right corner (along with the denominational numeral).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    | The banknotes will continue to have year of printing on the reverse. In addition, ` symbol was introduced on the reverse of the banknotes, on the top left and top right corner (along with the denominational numeral). |
| 2016 | -do- | -do-                                                                                                                                                                                                                      | The numerals in both the number panels will be in ascending size from left to right while the first three alpha-numeric characters (prefix) will remain constant in size. The numeral '20', RBI seal, Mahatma Gandhi's portrait, RBI legend, Guarantee and promise clause, Governor's signature, Ashoka Pillar emblem which were hitherto printed in intaglio (raised printing) are now being printed in offset (without any raised printing). Further, rectangular identification mark on the left of the banknote has been removed. While there is no change in the colour at the reverse, the colour at the obverse is lighter (due to removal of intaglio printing). The vertical band on the right side of the Mahatma Gandhi's portrait hitherto contained a latent image showing the denominational | -do-                                                                                                                                                                                                                     |

<!-- RBI_PAGE:18 -->

<!-- image -->

|                 |                 |                                                                                                                                                                                                       | numeral '20'. The latent image was visible only when the banknote was held horizontally at eye level. This feature is no longer present.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |                                                                                                                                                                                                             |
|-----------------|-----------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2019            | 63x12 9mm       | ₹ 20 denomination banknotes in the Mahatma Gandhi (New) Series having Mahatma Gandhi portrait and electrotype (20) watermarks                                                                         | See through register with denominational numeral 20. Denominational numeral २० in Devnagari. Portrait of Mahatma Gandhi at the centre. Micro letters 'RBI', ' भारत ', 'INDIA' and '20'. Windowed demetalised security thread with inscriptions ' भारत ' and RBI. Guarantee Clause, Governor's signature with Promise Clause and RBI emblem towards right of Mahatma Gandhi portrait. Ashoka Pillar emblem on the right. Mahatma Gandhi portrait and electrotype (20) watermarks. Number panel with numerals growing from small to big on the top left side and bottom right side.                                                                                                                                                                                | Year of printing of the note on the left. Swachh Bharat logo with slogan. Language panel. Motif of Ellora Caves. Denominational numeral २० in Devnagari.                                                    |
| III. ` 50 notes | III. ` 50 notes | III. ` 50 notes                                                                                                                                                                                       | III. ` 50 notes                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | III. ` 50 notes                                                                                                                                                                                             |
| 1975            | 147X7 3mm       | Ashoka Pillar with chain of wheels.                                                                                                                                                                   | Mauve colour with hues of blue green and purple. Numeral 50 in dark brown. Language scroll on left and Ashoka Pillar emblem on right. Printing bleeds off on all sides except at corners.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | Mauve, brown and yellow colours. Parliament House at the centre. Watermark window in pale mauve, surrounded by an ornamental design, which is in perfect register with corresponding design on the obverse. |
| 1981            | -do-            | -do-                                                                                                                                                                                                  | Intaglio-fast blue, yellow red. Ashoka Pillar and languages in deep violet colours, rest in deep green and brown colours. सत्यमेव जयते below Ashoka Pillar emblem.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | Dry offset-yellowish brown and body in deep purple colour. Parliament House with National flag on top                                                                                                       |
| 1997            | -do-            | Portrait of Mahatma Gandhi with multidirection al lines in the window.                                                                                                                                | Yellow, blue and violet colour. Ashoka Pillar replaced by Mahatma Gandhi Portrait in blue. Security thread totally embedded inside the note the letters ' भारत ' and 'RBI'. A small black solid square on the left hand side of the watermark to help the visually impaired to identify the denomination of the note.                                                                                                                                                                                                                                                                                                                                                                                                                                            | A panoramic view of India's Parliament House with floral patterns above and filigree patterns on the sides. The value of the note in 15 Indian languages.                                                   |
| 2005            | -do-            | The portrait of Mahatma Gandhi, the multidirection al lines, and an electrotype mark showing the denominational numeral 50 appear in this section and these can be viewed better when the banknote is | Machine readable windowed demetalised clear text magnetic security thread with inscriptions 'Bharat' (in Hindi) and RBI which fluoresces in yellow on both sides under U.V.light -width 1.4 mm. The Intaglio Printing i.e. raised prints is more prominent in the name of the Bank in Hindi and English, the Reserve Bank Seal, guarantee and promise clause, Ashoka Pillar Emblem on the left, RBI Governor's signature. A square in intaglio on the left of the watermark window with increased depth of engraving helps the visually impaired to identify the denomination. Optical fibres are in dual colour. The small floral design printed both on the front (hollow) and back (filled up) of the banknote in the middle of the vertical band next to the | Year of printing is incorporated at the printing stage on the reverse of the banknote.                                                                                                                      |

<!-- RBI_PAGE:19 -->

<!-- image -->

|      |                | held against light                                                                                                            | watermark window has an accurate back-to- back registration so that the numeral appears as one when seen against the light.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                                                                                                                                                                                                                          |
|------|----------------|-------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2012 | -do-           | -do-                                                                                                                          | -do- In addition, ` symbol was introduced on the obverse of the banknote, on the top left and top right corner (along with the denominational numeral).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | The banknotes will continue to have year of printing on the reverse. In addition, ` symbol was introduced on the reverse of the banknotes, on the top left and top right corner (along with the denominational numeral). |
| 2015 | -do-           | - do-                                                                                                                         | -do- In addition, the numerals in both the number panels of these banknotes will be in ascending size from left to right, while the first three alphanumeric characters (prefix) will remain constant in size                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               | -do-                                                                                                                                                                                                                     |
| 2016 | -do-           | - do-                                                                                                                         | The numeral '50', RBI seal, Mahatma Gandhi's portrait, RBI legend, Guarantee and promise clause, Governor's signature, Ashoka Pillar emblem which were hitherto printed in intaglio (raised printing) are now being printed in offset (without any raised printing). Further, square-shaped identification mark on the left of the banknote has been removed. While there is no change in the colour at the reverse, the colour at the obverse is lighter (due to removal of intaglio printing). The vertical band on the right side of the Mahatma Gandhi's portrait hitherto contained a latent image showing the denominational numeral '50'. The latent image was visible only when the banknote was held horizontally at eye level. This feature is no longer present. | -do-                                                                                                                                                                                                                     |
| 2017 | 66 mm x 135 mm | ₹ 50 denomination banknotes in the Mahatma Gandhi (New) Series having Mahatma Gandhi portrait and electrotype (50) watermarks | The base colour of the note is Fluorescent Blue. See through register with denominational numeral 50, Denominational numeral ५० in Devnagari, Portrait of Mahatma Gandhi at the centre, Micro letters 'RBI', ' भारत ', 'INDIA' and '50', Windowed demetalised security thread with inscriptions ' भारत ' and RBI, Guarantee Clause, Governor's signature with Promise Clause and RBI emblem towards right of Mahatma Gandhi portrait, Ashoka Pillar emblem on the right, Mahatma Gandhi portrait and electrotype (50) watermarks, Number panel with numerals growing from small to big on the top left side and bottom right side.                                                                                                                                          | Year of printing of the note on the left, Swachh Bharat logo with slogan, Language panel, Motif of Hampi with Chariot, Denominational numeral ५० in Devnagari.                                                           |

<!-- RBI_PAGE:20 -->

<!-- image -->

BANK OF

|   1967 | 157X7 3mm   | Ashoka Pillar                                                                                                                                                                                                               | Blue colour. Numeral 100 appears prominently in centre. Ashoka Pillar emblem on the right.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              | Vertical panel of 14 Indian languages on left. Hirakud Dam in the background in a circular frame.                                                                                                                                               |
|--------|-------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|   1969 | -do-        | -do-                                                                                                                                                                                                                        | Blue colour and promise clause, Guarantee clause and Governor's signature in bilingual.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | Picture of Mahatma Gandhi in a sitting posture with Sevagram Ashram in the background in a circular frame.                                                                                                                                      |
|   1975 | -do-        | Ashoka Pillar with spinning wheels.                                                                                                                                                                                         | Intaglio deep blue with hues of blue, brown, pink and dark green. Numeral 100 in dark blue. Watermark window light blue. RBI's name, promise clause, Guarantee clause and Governor's signature in bilingual. Language scroll on left and Ashoka Pillar emblem on right. Printing bleeds off on all sides except at corners.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             | Intaglio deep blue and brown shade of corn, agricultural operations, Tea plantation and hydroelectric power project. 'Watermark' window is surrounded by an ornamental design, which is in perfect register with similar design on the obverse. |
|   1979 | -do-        | -do-                                                                                                                                                                                                                        | One side intaglio blue, red and deep green, Tints of reddish and yellowish green shade. सत्यमेव जयते below Ashoka Pillar emblem.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | Dry-offset. Black and maroon colours. Tint design in greenish blue and brownish shades.                                                                                                                                                         |
|   1996 | -do-        | Portrait of Mahatma Gandhi with multidirection al lines in the watermark window.                                                                                                                                            | Printed with the combination of offset and intaglio process. overall colour is predominantly blue, grey and green. Portrait of Mahatma Gandhi. A windowed security thread partly visible from the front but totally embedded inside. Letters ' भारत ' and 'RBI' printed on the thread. A small black solid triangle in intaglio on left hand side of the watermark to help the visually impaired to identify the denomination of the note.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              | Central theme depicts a panoramic view of the Kanchangunga range with floral patterns above and filigree patterns on the sides. The value of note appears in 15 languages on the left hand side.                                                |
|   2005 | -do-        | The portrait of Mahatma Gandhi, the multidirection al lines, and an electrotype mark showing the denomination al numeral 100 appear in this section and these can be viewed better when the banknote is held against light. | Machine-readable windowed demetalised clear text magnetic security thread with inscriptions 'Bharat' (in Hindi) and RBI on notes of Rs.100 with exclusive colour shift. Colour of the thread shall shift from green to blue when viewed from different angles. It will fluoresce in yellow on the reverse and the text will fluoresce on the obverse under U.V.light - width - 2 m.m. The Intaglio Printing i.e. raised prints is more prominent in the name of the Bank in Hindi and English, the Reserve Bank Seal, guarantee and promise clause, Ashoka Pillar Emblem on the left, RBI Governor's signature. A triangle in intaglio on the left of the watermark window with increased depth of engraving helps the visually impaired to identify the denomination. Optical fibres are in dual colour. The small floral design printed both on the front (hollow) and back(filled up) of the banknote in the middle of the vertical band next to the watermark window has an accurate back to back registration so that the numeral appears as one when seen against | Year of printing is incorporated at the printing stage on the reverse of the banknote.                                                                                                                                                          |

<!-- RBI_PAGE:21 -->

<!-- image -->

Ru

VE

ED

BANK OF

|                                              |                                              |                                                                                                                                 | the light.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |                                                                                                                                                                                                                                                 |
|----------------------------------------------|----------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2011                                         | -do-                                         | -do-                                                                                                                            | -do- In addition, ` symbol was introduced on the obverse of the banknotes, on the top left and top right corner (along with the denominational numeral).                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | The banknotes will continue to have year of printing on the reverse. In addition, ` symbol was introduced on the reverse of the banknotes on the top left and top right corner (along with the denominational numeral).                         |
| 2015                                         | -do-                                         | -do-                                                                                                                            | -do- In addition, the numerals in both the number panels of these banknotes will be in ascending size from left to right, while the first three alphanumeric characters (prefix) will remain constant in size. In addition, easy to identify markings for visually impaired in the form of four angular bleed lines on both left and right of the obverse side of banknotes. Increase in size of the identification mark (triangle) by 50 per cent.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 | -do-                                                                                                                                                                                                                                            |
| 2018                                         | 66× 142 mm.                                  | ₹ 100 denomination banknotes in the Mahatma Gandhi (New) Series having Mahatma Gandhi portrait and electrotype (100) watermarks | See through register with denominational numeral 100.Latent image with denominational numeral 100. Denominational numeral १०० in Devnagari. Portrait of Mahatma Gandhi at the centre. Micro letters 'RBI', ' भारत ' , 'India' and '100'. Windowed security thread with inscriptions ' भारत' and RBI with colour shift; Colour of the thread changes from green to blue when the note is tilted. Guarantee Clause, Governor's signature with Promise Clause and RBI emblem towards right of Mahatma Gandhi portrait. Ashoka Pillar emblem on the right. Mahatma Gandhi portrait and electrotype (100) watermarks. Number panel with numerals in ascending font on the top left side and bottom right side. For visually impaired intaglio or raised printing of Mahatma Gandhi portrait, Ashoka Pillar emblem, raised triangular identification mark with micro-text 100, four angular bleed lines both on the right and left sides. | Year of printing of the note on the left. Swachh Bharat logo with slogan. Language panel. Motif of RANI KI VAV. Denominational numeral १०० in Devnagari.                                                                                        |
| V. ` 200 Notes - Mahatma Gandhi (New) Series | V. ` 200 Notes - Mahatma Gandhi (New) Series | V. ` 200 Notes - Mahatma Gandhi (New) Series                                                                                    | V. ` 200 Notes - Mahatma Gandhi (New) Series                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | V. ` 200 Notes - Mahatma Gandhi (New) Series                                                                                                                                                                                                    |
| 2017                                         | 66 mm × 146 mm                               | ₹ 200 denomination banknotes in the Mahatma Gandhi (New) Series having Mahatma Gandhi                                           | The base colour of the note is Bright Yellow. The note has other designs, geometric patterns aligning with the overall colour scheme, both at the obverse and reverse. See through register with denominational numeral 200 Latent image with denominational numeral 200 Denominational numeral २०० in Devnagari                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    | Motif of Sanchi Stupa on the reverse, depicting the country's cultural heritage. Year of printing of the note on the left Swachh Bharat logo with slogan Language panel Motif of Sanchi Stupa Denominational numeral २०० in Devnagari Dimension |

<!-- RBI_PAGE:22 -->

<!-- image -->

|                                                   |                                                   | portrait and electrotype (200) watermarks                  | Portrait of Mahatma Gandhi at the centre Micro letters 'RBI', ' भारत ', 'India' and '200' Windowed security thread with inscriptions ' भारत ' and RBI with colour shift. Colour of the thread changes from green to blue when the note is tilted Guarantee Clause, Governor's signature with Promise Clause and RBI emblem towards right of Mahatma Gandhi portrait Denominational numeral with Rupee Symbol, ₹ 200 in colour changing ink (gre en to blue) on bottom right Ashoka Pillar emblem on the right Number panel with numerals growing from small to big on the top left side and bottom right side For visually impaired Intaglio or raised printing of Mahatma Gandhi portrait, Ashoka Pillar emblem, raised Identification mark H with micro- text ₹ 200, four angular bleed lines with two circles in between the lines both on the right and left sides   |                                                                                                                                                                                                                                                                                   |
|---------------------------------------------------|---------------------------------------------------|------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| VI. ` 500 notes - Mahatma Gandhi (New) Series     | VI. ` 500 notes - Mahatma Gandhi (New) Series     | VI. ` 500 notes - Mahatma Gandhi (New) Series              | VI. ` 500 notes - Mahatma Gandhi (New) Series                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |                                                                                                                                                                                                                                                                                   |
| 2016                                              | 66mm x150 mm                                      | Mahatma Gandhi portrait and electrotype (500) watermarks   | Issued in the Mahatma Gandhi (New) Series, the new ₹ 500 banknotes are different from the earlier specified bank note (SBN) series in colour, size, theme, location of security features and design elements. The colour of the note is stone grey. The orientation and relative position of the Mahatma Gandhi portrait has changed. The banknote also has features (intaglio printing of Mahatma Gandhi portrait, Ashoka Pillar emblem, bleed lines, circle with ₹ 500 in the right, and the identification mark) which enable the visually impaired person to identify the denomination.                                                                                                                                                                                                                                                                              | The new theme is the Indian heritage site Red Fort with the Indian flag. The year of printing '2016' and Swachh Bharat logo is printed on the reverse. The 15 language panel is towards the centre.                                                                               |
| VII. ` 2000/- notes - Mahatma Gandhi (New) Series | VII. ` 2000/- notes - Mahatma Gandhi (New) Series | VII. ` 2000/- notes - Mahatma Gandhi (New) Series          | VII. ` 2000/- notes - Mahatma Gandhi (New) Series                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |                                                                                                                                                                                                                                                                                   |
| 2016                                              | 66mm x 166 mm                                     | Mahatma Gandhi portrait and electrotype (2000) watermarks. | Issued in the Mahatma Gandhi (New) Series. The base colour of the note is magenta. The note has other designs, geometric patterns aligning with the overall colour scheme, both at the obverse and reverse. The salient features are : 1. See through register with denominational numeral 2000 2. Latent image with denominational numeral 2000 3. Denominational numeral २००० in Devnagari 4. Portrait of Mahatma Gandhi at the centre 5. Micro letters 'RBI' and '2000' on the left side of the banknote 6. Windowed security thread with inscriptions ' भारत ', RBI and 2000 on banknotes with colour shift. Colour of the thread changes from green to blue when the note is tilted                                                                                                                                                                                 | The salient features are : 1. Year of printing of the note on the left 2. Swachh Bharat logo with slogan 3. Language panel towards the centre 4. Motif of Mangalayan depicting the country's first venture into interplanetary space. 5. Denominational numeral २००० in Devnagari |

<!-- RBI_PAGE:23 -->

<!-- image -->

| 7. Guarantee Clause, Governor's signature with Promise Clause and RBI emblem towards right 8. Denominational numeral with Rupee Symbol, ₹ 2000 in colour changing ink (green to blue) on bottom right 9. Ashoka Pillar emblem on the right Mahatma Gandhi portrait and electrotype (2000) watermarks 10. Number panel with numerals growing from small to big on the top left side and bottom right side. For visually impaired Intaglio or raised printing of Mahatma Gandhi portrait, Ashoka Pillar emblem, bleed lines and identity mark 11. Horizontal rectangle with ₹ 2000 in raised print on the right 12. Seven angular bleed lines on left and right side in raised print.   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

<!-- RBI_PAGE:24 -->

<!-- image -->

RE

ESERVE

BANK

OF

## List of Circulars Consolidated in this Master Circular

|   SN | Circular Ref. No.                                | Date       | Subject                                                                                         | Para of Master Circular   |
|------|--------------------------------------------------|------------|-------------------------------------------------------------------------------------------------|---------------------------|
|    1 | DCM FNVD G 16/16.01.01/2003-04                   | 18-Dec-03  | Issue of Forged Notes through ATM                                                               | Para 6                    |
|    2 | DCM FNVD G 31/16.01.01/2003-04                   | 8-Apr-04   | Detection of Forged Notes - Issue of receipt to tenderers                                       | Para 4                    |
|    3 | DCM FNVD G 3/16.02.03/2004-05                    | 6-Jul-04   | Detection of Forged Notes - Issue of receipts                                                   | Para 4                    |
|    4 | DCM FNVD G 23/16.01.01/2005-06                   | 7-Dec-05   | Issue of Counterfeit Banknotes through ATMs - Constitution of Forged Note Vigilance Cell        | Para 6 & 8                |
|    5 | DCM FNVD G 37/16.08.08/2006-07                   | 28-Mar-06  | Detection of Counterfeit Banknotes at ATMs of the banks                                         | Para 6 & 8                |
|    6 | DCM FNVD G 18/16.08.08/2006-07                   | 1-Jun-07   | Detection of Counterfeit Banknotes in chest remittances received from banks                     | Para 6                    |
|    7 | DCMNo.Dir.NPD.3158/09.39.00/2009-10              | 19-Nov-09  | Sorting of Notes - Installation of Note Sorting Machines                                        | Para 6                    |
|    8 | DCM.No.Cir.NPD.3161/09.39.00 (Policy)/2009- 2010 | 19-Nov-09  | Sorting / Processing of Notes - Installation of Note Sorting Machines                           | Para 9                    |
|    9 | DCM(R&D)No.G-26/18.00.14/2009-10                 | 11-May-10  | Installation of Note Sorting Machines- Note Authentication and Fitness Sorting Parameters       | Para 9                    |
|   10 | DCMFNVD No.502/16.01.05/2011-12                  | 25-Jul-11  | Detection of Counterfeit Bank Notes - Revised Procedure                                         | Para 5                    |
|   11 | DCM(FNV)No.5063/16.02.22/2011-12                 | 9-May-12   | Detection and Reporting Mechanism of Counterfeit Notes - Monetary Policy 2012- 13               | Para 6                    |
|   12 | DCMFNVD No.2165/16.21.005/2012-13                | 16-Nov-12  | Detection and Reporting of Counterfeit Notes - Second Quarter Review of Monetary Policy 2012-13 | Para 6                    |
|   13 | DCMFNVD No.776/16.01.05/2015-16                  | 27-Aug-15  | Detection of Counterfeit Notes - Review                                                         | Para 2                    |
|   14 | DCM FNVD No.1134/16.01.05/2016-17                | 27-Oct-16  | Detection and Impounding of Counterfeit Notes                                                   | Para 5                    |
|   15 | DCM (FNVD) G-7/16.01.05/17-18                    | 15-Jan-18  | Detection and Impounding of Counterfeit Notes - Filing of FIR                                   | Para 5                    |
|   16 | DPSS.CO.OD.No.1916/06.07.011/2018-19             | 7-Mar-2019 | White Label ATMs (WLAs) in India - Review of Guidelines                                         | Para 6                    |

## Annex VIII