# RBI Cleaned Extraction Layer

This layer is derived from the loss-minimized raw extraction. It removes repeated positional headers/footers, margin page numbers, standalone RBI navigation text, exact duplicate extraction blocks, broken line wraps, soft hyphens, line-end hyphenation, empty blocks, and excess whitespace. It conservatively preserves regulatory numbering, clause lettering, definitions, legal qualifiers, footnotes, tables, annexures, and amendment notes.

Every removed line/block appears in `cleaning_audit.jsonl` with its source page and bounding box. The raw extraction remains unchanged.
