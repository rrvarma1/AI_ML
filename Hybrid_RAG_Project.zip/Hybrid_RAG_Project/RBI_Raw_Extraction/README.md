# RBI Raw Extraction Layer

Loss-minimized page/block extraction of the supplied RBI PDF corpus. Each document JSON preserves document metadata, page dimensions, native and sorted text, text blocks, lines, font spans, bounding boxes, table detections, image references, links, and page-level warnings. Extracted embedded images are stored under `assets/`. No semantic chunking or text cleanup has been applied.
