# Answer

The interest on STBD and MLTGD shall be calculated in Indian Rupees with reference to the value of gold at the time of deposit [E1, E2]. Before April 5, 2021, the principal on STBD and MLTGD shall be denominated in gold [E1]. However, with effect from April 5, 2021, interest in respect of STBD shall be denominated and paid in Indian Rupee only [E3]. The redemption of principal at maturity will, at the option of the depositor, be either in Indian Rupee equivalent of the deposited gold based on the prevailing price of gold at the time of redemption, or in gold [E3]. The interest on premature closure of the deposit due to default of loan taken against MLTGD before and after lock-in period will be calculated [E3]. The amount payable to the depositor shall be calculated as a sum of (A) and (B), as indicated below: (A) Actual market value of the gold deposit on the day of withdrawal and (B) Interest payable on the value of the gold for the period of deposit at the applicable rate [E3]. The applicable interest rate shall be as under: [E3]

## Conditions and exceptions

- However, all deposits prior to this date will continue to be governed by the 0.2% (of the notional redemption amount as on the maturity date in terms of INR) administrative charge in case of redemption in gold [E7].

## Regulatory status

The regulatory status is current as per the provided evidence [E1, E2, E3, E4, E5, E6, E7].

## Sources

- [E1] Gold Monetization Scheme, 2015 — 2.1.1 General — page 3 — rbi_doc3__chunk_0009 — status: current
- [E2] Gold Monetization Scheme, 2015 — 1.3 Definitions — pages 2–3 — rbi_doc3__chunk_0008 — status: current
- [E3] Gold Monetization Scheme, 2015 — Where, ARI = Annual Rate of Interest D = Number of days 16 — page 6 — rbi_doc3__chunk_0025 — status: current
- [E4] Gold Monetization Scheme, 2015 — 2.2.1 Short Term Bank Deposit (STBD) — page 6 — rbi_doc3__chunk_0022 — status: current
- [E5] Gold Monetization Scheme, 2015 — ii.  Redemption in Gold — pages 13–14 — rbi_doc3__chunk_0061 — status: current
- [E6] Gold Monetization Scheme, 2015 — Where, ARI = Annual Rate of Interest D = Number of days 16 — page 6 — rbi_doc3__chunk_0024 — status: current
- [E7] Gold Monetization Scheme, 2015 — 2.2.2    Medium and Long Term Government Deposit (MLTGD) — page 10.0 — rbi_doc3__chunk_0042 — status: current
