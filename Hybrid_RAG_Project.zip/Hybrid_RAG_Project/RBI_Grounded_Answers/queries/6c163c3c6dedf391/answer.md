# Answer

REs shall maintain all necessary records of transactions between the RE and the customer, both domestic and international, for at least five years from the date of transaction [E8][E2]

## Conditions and exceptions

No additional conditions or exceptions were established by the supplied evidence.

## Regulatory status

The current regulatory status is established by [E1: Master Direction - Know Your Customer (KYC) Direction, 2016] as of 2019-05-29.

## Sources

- [E8] Master Direction - Know Your Customer (KYC) Direction, 2016 — Record Management — page 49 — rbi_doc7__chunk_0212 — status: current
- [E2] Master Direction - Know Your Customer (KYC) Direction, 2016 — 45.  S — pages 48–49 — rbi_doc7__chunk_0209 — status: current
