# Answer

The customer due diligence requirements, as outlined in [E1], involve obtaining the following information from an individual: 

*   Aadhaar number if the individual is desirous of receiving a subsidy or voluntarily submits it, or proof of possession of Aadhaar number where offline verification can be carried out, or proof of possession of Aadhaar number where offline verification cannot be carried out or any OVD or the equivalent e-document thereof containing the details of his identity and address; or KYC Identifier with an explicit consent to download records from CKYCR.
*   Permanent Account Number or the equivalent e-document thereof or Form No. 60 as defined in Income-tax Rules, 1962.
*   Such other documents including in respect of the nature of business and financial status of the customer, or the equivalent e-documents, as may be required by the RE.

Specifically, if a customer has submitted an Aadhaar number to a bank or RE, the bank or RE shall carry out authentication of the Aadhaar number using the e-KYC authentication facility provided by the Unique Identification Authority of India [E1]. The RE must also obtain the aggregate balance of all deposit accounts and the aggregate of all credits in a financial year, in all the deposit accounts taken together, shall not exceed rupees two lakh. [E2]. Enhanced due diligence measures are required for PEPs, including obtaining approval from senior management and monitoring transactions [E6]. Accounts opened using Aadhaar OTP based e-KYC, in non-face-to-face mode, are subject to specific conditions, such as obtaining consent for OTP authentication, sending transaction alerts to the registered mobile number, and limiting the aggregate balance to one lakh rupees [E2]. The RE has the ultimate responsibility for customer due diligence and undertaking enhanced due diligence measures [E1]. The RE shall rely on the CDD done by a third party, subject to certain conditions, including the third party being regulated, supervised, and having compliance measures in place [E1]. The third party shall not be based in a country or jurisdiction assessed as high risk [E1].

## Conditions and exceptions

No additional conditions or exceptions were established by the supplied evidence.

## Regulatory status

current status is established by [E1]

## Sources

- [E1] Master Direction - Know Your Customer (KYC) Direction, 2016 — Customer Identification Procedure (CIP) — pages 22–23 — rbi_doc7__chunk_0094 — status: current
- [E2] Master Direction - Know Your Customer (KYC) Direction, 2016 — Part I - Customer Due Diligence (CDD) Procedure in case of Individuals — pages 26–27 — rbi_doc7__chunk_0109 — status: current
- [E3] Master Direction - Know Your Customer (KYC) Direction, 2016 — A. Enhanced Due Diligence — pages 45–46 — rbi_doc7__chunk_0201 — status: current
- [E4] Master Direction - Know Your Customer (KYC) Direction, 2016 — Part I - Customer Due Diligence (CDD) Procedure in case of Individuals — page 26 — rbi_doc7__chunk_0107 — status: current
- [E5] Master Direction - Know Your Customer (KYC) Direction, 2016 — Part V - On-going Due Diligence — pages 38–39 — rbi_doc7__chunk_0168 — status: current
- [E6] Master Direction - Know Your Customer (KYC) Direction, 2016 — 42.  Client accounts opened by professional intermediaries: — page 47 — rbi_doc7__chunk_0205 — status: current
- [E7] Master Direction - Know Your Customer (KYC) Direction, 2016 — Part I - Customer Due Diligence (CDD) Procedure in case of Individuals — pages 24–25 — rbi_doc7__chunk_0100 — status: current
