# Answer

The borrower categories eligible under the KCC Scheme are:

- Farmers - individual/joint borrowers who are owner cultivators;
- Tenant farmers, oral lessees &amp; share croppers;
- Self Help Groups (SHGs) or Joint Liability Groups (JLGs) of farmers including tenant farmers, share croppers etc. [E2][E1]

## Conditions and exceptions

No additional conditions or exceptions were established by the supplied evidence.

## Regulatory status

The evidence indicates the current regulatory status of the KCC Scheme as of 2018-07-04.

## Sources

- [E2] Master Circular - Kisan Credit Card (KCC) Scheme — 3 Objective / Purpose — pages 2.0–3.0 — rbi_doc1__chunk_0005 — status: current
- [E1] Master Circular - Kisan Credit Card (KCC) Scheme — 2 Applicability of the Scheme — page 2 — rbi_doc1__chunk_0004 — status: current
