# RBI Regulatory Document Hierarchy

## Where the hierarchy is stored

- `document_hierarchy.json`: combined nested hierarchy for all documents.
- `document_hierarchies/<document_id>.hierarchy.json`: authoritative per-document tree, flat node registry, and block mapping.
- `block_heading_map.jsonl`: fast lookup from every cleaned block to its full heading path and citation anchor.
- `structured_documents/<document_id>.structured.json`: cleaned blocks with `heading_path`, `heading_path_text`, and `citation_anchor` embedded directly. This is the recommended input to Step 6 chunking.

During chunking, copy the block-derived `heading_path`, `active_heading_node_id`, page range, title, and source URL into each chunk's metadata. Retrieval can then return this metadata directly, and citation generation can display `title > heading path > page` without reparsing the PDF.
