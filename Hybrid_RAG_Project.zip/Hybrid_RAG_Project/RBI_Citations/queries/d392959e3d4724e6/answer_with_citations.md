# Answer with verified citations

The borrower categories eligible under the KCC Scheme are:

- Farmers - individual/joint borrowers who are owner cultivators;
- Tenant farmers, oral lessees &amp; share croppers;
- Self Help Groups (SHGs) or Joint Liability Groups (JLGs) of farmers including tenant farmers, share croppers etc. [E2][E1]

## Conditions and exceptions

No additional conditions or exceptions were established by the supplied evidence.

## Sources

- [E2] Master Circular - Kisan Credit Card (KCC) Scheme — 3 Objective / Purpose — 3 Objective / Purpose — pages 2.0–3.0 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc1__chunk_0005`
- [E1] Master Circular - Kisan Credit Card (KCC) Scheme — 2 Applicability of the Scheme — 2 Applicability of the Scheme — page 2 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc1__chunk_0004`

## Claim-to-chunk mapping

### ANS-001 — answer_summary

The borrower categories eligible under the KCC Scheme are:

- Farmers - individual/joint borrowers who are owner cultivators;
- Tenant farmers, oral lessees &amp; share croppers;
- Self Help Groups (SHGs) or Joint Liability Groups (JLGs) of farmers including tenant farmers, share croppers etc. [E2][E1]

Supporting chunks: `rbi_doc1__chunk_0005`, `rbi_doc1__chunk_0004`

### CLM-001 — material_claim

The borrower categories eligible under the KCC Scheme are:

- Farmers - individual/joint borrowers who are owner cultivators;
- Tenant farmers, oral lessees &amp; share croppers;
- Self Help Groups (SHGs) or Joint Liability Groups (JLGs) of farmers including tenant farmers, share croppers etc.

Supporting chunks: `rbi_doc1__chunk_0005`, `rbi_doc1__chunk_0004`

### CLM-002 — material_claim

Farmers - individual/joint borrowers who are owner cultivators

Supporting chunks: `rbi_doc1__chunk_0005`, `rbi_doc1__chunk_0004`

### CLM-003 — material_claim

Tenant farmers, oral lessees &amp; share croppers

Supporting chunks: `rbi_doc1__chunk_0005`, `rbi_doc1__chunk_0004`

### CLM-004 — material_claim

Self Help Groups (SHGs) or Joint Liability Groups (JLGs) of farmers including tenant farmers, share croppers etc.

Supporting chunks: `rbi_doc1__chunk_0005`, `rbi_doc1__chunk_0004`

### STAT-001 — regulatory_status_note

The evidence indicates the current regulatory status of the KCC Scheme as of 2018-07-04.

Supporting chunks: `rbi_doc1__chunk_0005`, `rbi_doc1__chunk_0004`
