# Answer with verified citations

For an unincorporated association or body of individuals, the beneficial owner is the natural person(s), who, whether acting alone or together, or through one or more juridical person, has/have ownership of/entitlement to more than 15 percent of the property or capital or profits of the unincorporated association or body of individuals . Where no natural person is identified under (a), (b) or (c) above, the beneficial owner is the relevant natural person who holds the position of senior managing official . This applies to bodies of individuals including societies .  and  confirms this definition. [E2][E1]

## Conditions and exceptions

No additional conditions or exceptions were established by the supplied evidence.

## Sources

- [E2] Master Direction - Know Your Customer (KYC) Direction, 2016 — 3.  Definitions — 3.  Definitions — pages 5–6 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc7__chunk_0023`
- [E1] Master Direction - Know Your Customer (KYC) Direction, 2016 — 3.  Definitions — 3.  Definitions — page 6 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc7__chunk_0024`

## Claim-to-chunk mapping

### ANS-001 — answer_summary

For an unincorporated association or body of individuals, the beneficial owner is the natural person(s), who, whether acting alone or together, or through one or more juridical person, has/have ownership of/entitlement to more than 15 percent of the property or capital or profits of the unincorporated association or body of individuals . Where no natural person is identified under (a), (b) or (c) above, the beneficial owner is the relevant natural person who holds the position of senior managing official . This applies to bodies of individuals including societies .  and  confirms this definition. [E2][E1]

Supporting chunks: `rbi_doc7__chunk_0023`, `rbi_doc7__chunk_0024`

### CLM-001 — material_claim

For an unincorporated association or body of individuals, the beneficial owner is the natural person(s), who, whether acting alone or together, or through one or more juridical person, has/have ownership of/entitlement to more than 15 percent of the property or capital or profits of the unincorporated association or body of individuals . Where no natural person is identified under (a), (b) or (c) above, the beneficial owner is the relevant natural person who holds the position of senior managing official . This applies to bodies of individuals including societies .  and  confirms this definition.

Supporting chunks: `rbi_doc7__chunk_0023`, `rbi_doc7__chunk_0024`

### STAT-001 — regulatory_status_note

The information is based on the Master Direction - Know Your Customer (KYC) Direction, 2016 as of 2019-05-29, as amended on October 17, 2023 and April 28, 2023 [E1, E2, E3, E4, E5, E6, E7, E8].

Supporting chunks: `rbi_doc7__chunk_0023`, `rbi_doc7__chunk_0024`
