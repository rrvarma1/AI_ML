# Answer with verified citations

The customer due diligence requirements, as outlined in [E1], involve obtaining the following information from an individual: 

*   Aadhaar number if the individual is desirous of receiving a subsidy or voluntarily submits it, or proof of possession of Aadhaar number where offline verification can be carried out, or proof of possession of Aadhaar number where offline verification cannot be carried out or any OVD or the equivalent e-document thereof containing the details of his identity and address; or KYC Identifier with an explicit consent to download records from CKYCR.
*   Permanent Account Number or the equivalent e-document thereof or Form No. 60 as defined in Income-tax Rules, 1962.
*   Such other documents including in respect of the nature of business and financial status of the customer, or the equivalent e-documents, as may be required by the RE.

Specifically, if a customer has submitted an Aadhaar number to a bank or RE, the bank or RE shall carry out authentication of the Aadhaar number using the e-KYC authentication facility provided by the Unique Identification Authority of India [E1]. The RE must also obtain the aggregate balance of all deposit accounts and the aggregate of all credits in a financial year, in all the deposit accounts taken together, shall not exceed rupees two lakh. [E2]. Enhanced due diligence measures are required for PEPs, including obtaining approval from senior management and monitoring transactions [E6]. Accounts opened using Aadhaar OTP based e-KYC, in non-face-to-face mode, are subject to specific conditions, such as obtaining consent for OTP authentication, sending transaction alerts to the registered mobile number, and limiting the aggregate balance to one lakh rupees [E2]. The RE has the ultimate responsibility for customer due diligence and undertaking enhanced due diligence measures [E1]. The RE shall rely on the CDD done by a third party, subject to certain conditions, including the third party being regulated, supervised, and having compliance measures in place [E1]. The third party shall not be based in a country or jurisdiction assessed as high risk [E1].

## Conditions and exceptions

No additional conditions or exceptions were established by the supplied evidence.

## Sources

- [E1] Master Direction - Know Your Customer (KYC) Direction, 2016 — Customer Identification Procedure (CIP) — Customer Identification Procedure (CIP) — pages 22–23 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc7__chunk_0094`
- [E2] Master Direction - Know Your Customer (KYC) Direction, 2016 — Part I - Customer Due Diligence (CDD) Procedure in case of Individuals — Part I — pages 26–27 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc7__chunk_0109`
- [E3] Master Direction - Know Your Customer (KYC) Direction, 2016 — A. Enhanced Due Diligence — A. Enhanced Due Diligence — pages 45–46 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc7__chunk_0201`
- [E4] Master Direction - Know Your Customer (KYC) Direction, 2016 — Part I - Customer Due Diligence (CDD) Procedure in case of Individuals — Part I — page 26 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc7__chunk_0107`
- [E5] Master Direction - Know Your Customer (KYC) Direction, 2016 — Part V - On-going Due Diligence — Part V — pages 38–39 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc7__chunk_0168`
- [E6] Master Direction - Know Your Customer (KYC) Direction, 2016 — 42.  Client accounts opened by professional intermediaries: — 42.  Client accounts opened by professional intermediaries: — page 47 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc7__chunk_0205`
- [E7] Master Direction - Know Your Customer (KYC) Direction, 2016 — Part I - Customer Due Diligence (CDD) Procedure in case of Individuals — Part I — pages 24–25 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc7__chunk_0100`

## Claim-to-chunk mapping

### ANS-001 — answer_summary

The customer due diligence requirements, as outlined in [E1], involve obtaining the following information from an individual: 

*   Aadhaar number if the individual is desirous of receiving a subsidy or voluntarily submits it, or proof of possession of Aadhaar number where offline verification can be carried out, or proof of possession of Aadhaar number where offline verification cannot be carried out or any OVD or the equivalent e-document thereof containing the details of his identity and address; or KYC Identifier with an explicit consent to download records from CKYCR.
*   Permanent Account Number or the equivalent e-document thereof or Form No. 60 as defined in Income-tax Rules, 1962.
*   Such other documents including in respect of the nature of business and financial status of the customer, or the equivalent e-documents, as may be required by the RE.

Specifically, if a customer has submitted an Aadhaar number to a bank or RE, the bank or RE shall carry out authentication of the Aadhaar number using the e-KYC authentication facility provided by the Unique Identification Authority of India [E1]. The RE must also obtain the aggregate balance of all deposit accounts and the aggregate of all credits in a financial year, in all the deposit accounts taken together, shall not exceed rupees two lakh. [E2]. Enhanced due diligence measures are required for PEPs, including obtaining approval from senior management and monitoring transactions [E6]. Accounts opened using Aadhaar OTP based e-KYC, in non-face-to-face mode, are subject to specific conditions, such as obtaining consent for OTP authentication, sending transaction alerts to the registered mobile number, and limiting the aggregate balance to one lakh rupees [E2]. The RE has the ultimate responsibility for customer due diligence and undertaking enhanced due diligence measures [E1]. The RE shall rely on the CDD done by a third party, subject to certain conditions, including the third party being regulated, supervised, and having compliance measures in place [E1]. The third party shall not be based in a country or jurisdiction assessed as high risk [E1].

Supporting chunks: `rbi_doc7__chunk_0094`, `rbi_doc7__chunk_0109`, `rbi_doc7__chunk_0205`

### CLM-001 — material_claim

Aadhaar number if the individual is desirous of receiving a subsidy or voluntarily submits it, or proof of possession of Aadhaar number where offline verification can be carried out, or proof of possession of Aadhaar number where offline verification cannot be carried out or any OVD or the equivalent e-document thereof containing the details of his identity and address; or KYC Identifier with an explicit consent to download records from CKYCR.

Supporting chunks: `rbi_doc7__chunk_0094`

### CLM-002 — material_claim

Permanent Account Number or the equivalent e-document thereof or Form No. 60 as defined in Income-tax Rules, 1962.

Supporting chunks: `rbi_doc7__chunk_0094`

### CLM-003 — material_claim

The RE must carry out authentication of the Aadhaar number using the e-KYC authentication facility provided by the Unique Identification Authority of India.

Supporting chunks: `rbi_doc7__chunk_0094`

### CLM-004 — material_claim

The RE must also obtain the aggregate balance of all deposit accounts and the aggregate of all credits in a financial year, in all the deposit accounts taken together, shall not exceed rupees two lakh.

Supporting chunks: `rbi_doc7__chunk_0109`

### CLM-005 — material_claim

Enhanced due diligence measures are required for PEPs, including obtaining approval from senior management and monitoring transactions.

Supporting chunks: `rbi_doc7__chunk_0205`

### CLM-006 — material_claim

Accounts opened using Aadhaar OTP based e-KYC, in non-face-to-face mode, are subject to specific conditions, such as obtaining consent for OTP authentication, sending transaction alerts to the registered mobile number, and limiting the aggregate balance to one lakh rupees.

Supporting chunks: `rbi_doc7__chunk_0109`

### CLM-007 — material_claim

The RE has the ultimate responsibility for customer due diligence and undertaking enhanced due diligence measures.

Supporting chunks: `rbi_doc7__chunk_0094`

### CLM-008 — material_claim

The RE shall rely on the CDD done by a third party, subject to certain conditions, including the third party being regulated, supervised, and having compliance measures in place.

Supporting chunks: `rbi_doc7__chunk_0094`

### CLM-009 — material_claim

The third party shall not be based in a country or jurisdiction assessed as high risk.

Supporting chunks: `rbi_doc7__chunk_0094`

### STAT-001 — regulatory_status_note

current status is established by [E1]

Supporting chunks: `rbi_doc7__chunk_0094`, `rbi_doc7__chunk_0109`, `rbi_doc7__chunk_0201`, `rbi_doc7__chunk_0107`, `rbi_doc7__chunk_0168`, `rbi_doc7__chunk_0205`, `rbi_doc7__chunk_0100`
