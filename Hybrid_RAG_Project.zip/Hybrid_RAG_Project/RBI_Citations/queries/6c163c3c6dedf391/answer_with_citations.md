# Answer with verified citations

REs shall maintain all necessary records of transactions between the RE and the customer, both domestic and international, for at least five years from the date of transaction [E8][E2]

## Conditions and exceptions

No additional conditions or exceptions were established by the supplied evidence.

## Sources

- [E8] Master Direction - Know Your Customer (KYC) Direction, 2016 — Record Management — Record Management — page 49 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc7__chunk_0212`
- [E2] Master Direction - Know Your Customer (KYC) Direction, 2016 — 45.  S — 45.  S — pages 48–49 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc7__chunk_0209`

## Claim-to-chunk mapping

### ANS-001 — answer_summary

REs shall maintain all necessary records of transactions between the RE and the customer, both domestic and international, for at least five years from the date of transaction [E8][E2]

Supporting chunks: `rbi_doc7__chunk_0212`, `rbi_doc7__chunk_0209`

### CLM-001 — material_claim

REs shall maintain all necessary records of transactions between the RE and the customer, both domestic and international, for at least five years from the date of transaction

Supporting chunks: `rbi_doc7__chunk_0212`, `rbi_doc7__chunk_0209`

### STAT-001 — regulatory_status_note

The current regulatory status is established by [E1: Master Direction - Know Your Customer (KYC) Direction, 2016] as of 2019-05-29.

Supporting chunks: `rbi_doc7__chunk_0212`, `rbi_doc7__chunk_0209`
