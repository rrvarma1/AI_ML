# Answer with verified citations

Banks may accept collateral for an MSE loan of ₹15 lakh based on the evidence.

[E1] states that banks are mandated not to accept collateral security in the case of loans up to ₹20 lakh extended to units in the MSE sector. Banks are also advised to extend collateral-free loans up to ₹20 lakh to all units financed under the Prime Minister Employment Generation Programme (PMEGP) administered by KVIC.

[E2] and [E3] outline provisions for granting loans to MSE units, including the possibility of dispensing with collateral requirements for loans up to ₹25 lakh based on a good track record and financial position of the MSE units. Specifically, [E1] and [E3] mention that banks may increase the limit to dispense with the collateral requirement for loans up to ₹25 lakh as per their internal policy. [E7] further states that banks shall grant fresh crop loans to affected farmers without collateral if the existing security has been eroded due to natural calamities.

[E8] clarifies that credit shall not be denied for want of a personal guarantee alone, and banks shall not insist on third-party guarantees for providing conversion facilities. However, [E8] also specifies that investments in securitised assets originated by NBFCs are not eligible for priority sector status.

## Conditions and exceptions

No additional conditions or exceptions were established by the supplied evidence.

## Sources

- [E1] Master Direction - Lending to Micro, Small & Medium Enterprises (MSME) Sector — 4. C — 4. C — page 4 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc4__chunk_0016`
- [E2] Master Direction - Lending to Micro, Small & Medium Enterprises (MSME) Sector — 4.1 Collateral 1 — 4.1 Collateral 1 — page 4 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc4__chunk_0017`
- [E3] Master Direction - Lending to Micro, Small & Medium Enterprises (MSME) Sector — Appendix — Appendix — page 15 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc4__chunk_0090`
- [E7] Master Direction – Priority Sector Lending – Small Finance Banks – Targets and Classification — 15. Investments by banks in securitised assets — 15. Investments by banks in securitised assets — pages 12–13 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc10__chunk_0087`
- [E8] Master Direction – Reserve Bank of India (Relief Measures by Banks in Areas affected by Natural Calamities) Directions 2018 – SCBs — 5.1 Sanctioning of Fresh Loans — 5.1 Sanctioning of Fresh Loans — page 8 — [RBI source](https://rbi.org.in/commonman/English/scripts/masterdirection.aspx) — chunk `rbi_doc6__chunk_0061`

## Claim-to-chunk mapping

### ANS-001 — answer_summary

Banks may accept collateral for an MSE loan of ₹15 lakh based on the evidence.

[E1] states that banks are mandated not to accept collateral security in the case of loans up to ₹20 lakh extended to units in the MSE sector. Banks are also advised to extend collateral-free loans up to ₹20 lakh to all units financed under the Prime Minister Employment Generation Programme (PMEGP) administered by KVIC.

[E2] and [E3] outline provisions for granting loans to MSE units, including the possibility of dispensing with collateral requirements for loans up to ₹25 lakh based on a good track record and financial position of the MSE units. Specifically, [E1] and [E3] mention that banks may increase the limit to dispense with the collateral requirement for loans up to ₹25 lakh as per their internal policy. [E7] further states that banks shall grant fresh crop loans to affected farmers without collateral if the existing security has been eroded due to natural calamities.

[E8] clarifies that credit shall not be denied for want of a personal guarantee alone, and banks shall not insist on third-party guarantees for providing conversion facilities. However, [E8] also specifies that investments in securitised assets originated by NBFCs are not eligible for priority sector status.

Supporting chunks: `rbi_doc4__chunk_0016`, `rbi_doc4__chunk_0017`, `rbi_doc4__chunk_0090`, `rbi_doc10__chunk_0087`, `rbi_doc6__chunk_0061`

### CLM-001 — material_claim

Banks are mandated not to accept collateral security in the case of loans up to ₹ 20 lakh extended to units in the MSE sector.

Supporting chunks: `rbi_doc4__chunk_0016`

### CLM-002 — material_claim

Banks may, on the basis of good track record and financial position of the MSE units, increase the limit to dispense with the collateral requirement for loans up to ₹25 lakh as per their internal policy.

Supporting chunks: `rbi_doc4__chunk_0016`, `rbi_doc4__chunk_0017`, `rbi_doc4__chunk_0090`

### CLM-003 — material_claim

Credit shall not be denied for want of a personal guarantee alone.

Supporting chunks: `rbi_doc6__chunk_0061`

### CLM-004 — material_claim

Banks shall not insist on third-party guarantee for providing conversion facilities.

Supporting chunks: `rbi_doc6__chunk_0061`

### STAT-001 — regulatory_status_note

The evidence is from 2017. Current regulatory status is not established.

Supporting chunks: `rbi_doc4__chunk_0016`, `rbi_doc4__chunk_0017`, `rbi_doc4__chunk_0090`, `rbi_doc10__chunk_0087`, `rbi_doc6__chunk_0061`
